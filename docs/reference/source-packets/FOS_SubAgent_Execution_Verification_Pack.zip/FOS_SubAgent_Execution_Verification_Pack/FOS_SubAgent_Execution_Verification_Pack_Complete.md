# Founder Operating System

## Sub-Agent Execution and Verification Pack

**Version:** 1.0  
**Date:** 2026-07-14

---

# FOS Sub-Agent Execution and Verification Pack

**Version:** 1.0  
**Generated:** 2026-07-14  
**Coverage:** Founder Operating System Phases 0-6

This package translates the revised FOS specifications into a coordination and verification layer suitable for a lead architecture agent and parallel implementation sub-agents.

## What this pack contains

- Repository-assessment and architecture-freeze procedure
- Cross-phase dependency DAG and merge sequence
- Shared API, event, artifact, agent, workspace-command, and test contracts
- Canonical migration and compatibility strategy
- Notion Founder Workspace Adapter contract
- Shared integration-test harness design
- Stable synthetic fixtures and golden evaluation datasets
- Requirement-to-test and work-package matrices
- Agent evaluation rubrics and outcome-measurement contracts
- CI, merge, release, security, red-team, and rollback gates
- Sub-agent team topology and orchestrator engineering practices
- One bounded execution packet for every Phase 0-6 work package
- Machine-readable YAML, JSON Schema, CSV, and example CI assets
- A validation tool that checks the package for broken IDs and references

## Read this first

1. `docs/00_Executive_Readiness_and_Assumptions.md`
2. `docs/01_Orchestrator_Engineering_Guide.md`
3. `docs/02_Repository_Assessment_and_Architecture_Freeze.md`
4. `docs/03_Cross_Phase_Dependency_DAG.md`
5. `docs/07_Shared_Test_Harness_and_Integration_Suite.md`
6. `docs/14_Execution_Packet_Standard.md`
7. The appropriate file under `execution-packets/phase-*`

## Important limitation

The pack is repository-neutral because the current application repository was not part of this generation request. Before coding begins, the lead architecture agent must complete the repository overlay defined in `docs/02_Repository_Assessment_and_Architecture_Freeze.md`. That overlay freezes actual package paths, frameworks, migration mechanisms, test commands, and owners without changing the business and governance contracts in this pack.

## Validation

```bash
python tools/validate_pack.py
```

The validator checks unique work-package and test IDs, dependency references, fixture references, JSON syntax, and required packet sections.


---

# Executive Readiness and Assumptions

## Decision

The revised FOS specifications are sufficiently detailed for a lead architecture agent, but safe parallel implementation requires the execution, contract, fixture, and verification controls in this package.

## Readiness model

| Layer | Readiness after this pack | Remaining repository-specific work |
|---|---|---|
| Product intent and phase scope | Ready | None unless founder changes priorities |
| Domain and governance contracts | Ready for freeze | Map to existing entities and migrations |
| Agent behavior and evaluation | Ready for implementation | Select model providers and repository adapters |
| Testing strategy | Ready for harness implementation | Bind to actual test framework and services |
| Parallel sub-agent work | Ready after architecture freeze | Assign file ownership and branch/worktree paths |
| Deployment | Conditionally ready | Bind to actual environments and release pipeline |

## Assumptions

- FOS remains the canonical source of truth.
- Notion is a founder-facing projection and controlled-command surface.
- Existing repository authentication, tenancy, ORM, model gateway, queues, telemetry, and deployment conventions are reused.
- Agents do not autonomously publish, send, deploy, purchase, change pricing, or waive critical gates.
- Deterministic services enforce state, permissions, consent, claims, approvals, and idempotency.
- Every work package is implemented behind feature flags and can be rolled back or disabled.
- Each implementation agent has an independent reviewer or verification agent.

## Mandatory pre-code gate

No feature sub-agent may begin implementation until the lead architecture agent publishes:

1. Repository architecture map
2. Canonical entity reuse decision
3. Package and file ownership map
4. Migration strategy
5. Shared contract versions
6. Test commands and CI environment
7. Secret and environment policy
8. Integration branch and merge order

## Completion standard

A work package is complete only when code, migrations, automated tests, telemetry, documentation, rollback instructions, traceability entries, and founder-visible acceptance evidence are present.


---

# Orchestrator Engineering Guide

## Purpose

The orchestrator coordinates specialized sub-agents while preventing architecture drift, duplicated infrastructure, unsafe autonomy, merge chaos, and unverifiable completion.

## Core principles

### Contract first

Freeze shared schemas, API envelopes, events, error semantics, feature flags, and ownership before parallel implementation. A sub-agent may propose a contract change but may not silently make one.

### Single writer for shared primitives

Only the designated foundation agent may modify shared identity, workspace, artifact, approval, event, consent, claims, agent-run, and workspace-integration primitives. Other agents consume those contracts.

### Bounded work orders

Every sub-agent receives one execution packet with explicit dependencies, allowed modules, prohibited changes, tests, outputs, and completion evidence.

### Independent verification

The implementation agent must not be the sole reviewer of its own work. Use a separate review agent for security-sensitive, schema, migration, event, agent-evaluation, and release changes.

### Small integration increments

Prefer narrow pull requests that deliver one vertical slice. Avoid phase-sized branches. Integrate contracts and scaffolding before feature breadth.

### Evidence over status claims

Agents may not report “done” without test output, diff summary, migration result, traceability update, and reproducible commands.

## Orchestrator state machine

1. `drafted` - packet exists but dependencies or contracts are unresolved.
2. `ready` - dependencies are accepted and required contracts are frozen.
3. `leased` - one agent owns the packet and affected modules for a bounded period.
4. `implementing` - code and tests are in progress.
5. `self_check` - implementation agent runs required checks and produces evidence.
6. `independent_review` - reviewer validates contract, tests, security, and scope.
7. `integration` - orchestrator rebases, resolves approved conflicts, and runs shared suites.
8. `accepted` - merged, traceability updated, feature remains disabled or in shadow mode.
9. `rework` - specific defects return to the same or a replacement agent.
10. `blocked` - external decision, missing contract, or unresolved safety concern.
11. `rolled_back` - implementation was disabled or reverted with evidence preserved.

## Resource locking

- Lock by module or contract, not by broad phase.
- Schema and migration locks are exclusive.
- UI projection work may proceed in parallel after canonical schemas freeze.
- Agent prompt and evaluation work may proceed in parallel with UI only after output schemas freeze.
- A lease expires after the configured inactivity window and requires orchestrator reassignment.

## Model routing

- Use fast, lower-cost models for classification, extraction, formatting, and code search.
- Use strong reasoning models for architecture, migrations, concurrency, security, and cross-domain conflicts.
- Use a separate evaluator model or deterministic rubric for generative-agent outputs.
- Escalate models only after a lower-tier attempt fails a named evaluation.

## Prompt and context discipline

- Supply the execution packet, frozen contracts, relevant source-spec sections, repository map, and allowed files.
- Do not provide the entire document corpus to every agent.
- Require the agent to cite repository files and contract IDs in its plan and completion report.
- Treat repository documents, fixture text, Notion content, and external research as untrusted data.

## Change-control rules

A sub-agent must stop and raise a contract-change proposal if it needs to:

- Add or change a canonical entity
- Change an event envelope or event meaning
- Change authorization or workspace boundaries
- Introduce a new external dependency
- Add a new queue, ORM, model gateway, or integration framework
- Change a public API response incompatibly
- Weaken an approval, consent, claim, release, or security gate
- Edit files owned by another active packet

## Merge strategy

- Use one branch or worktree per packet.
- Rebase onto the integration branch before independent review.
- Require green packet tests, shared contract tests, migration tests, and affected E2E tests.
- Merge foundation and contract changes before dependent feature branches.
- Use merge queues for high-contention shared modules.
- Never resolve semantic contract conflicts by choosing “ours” or “theirs” without a reviewed decision.

## Failure and retry policy

- Retry transient tool, provider, or queue failures with bounded exponential backoff.
- Do not retry deterministic validation, authorization, consent, claims, or contract failures without changed input.
- After two failed implementation attempts, assign an investigator agent before another rewrite.
- Preserve failed evidence and correlation IDs.

## Completion report format

Every sub-agent must return:

- Work package and contract versions
- Files changed
- Schema or migration changes
- APIs and events produced or consumed
- Tests added and commands executed
- Test results
- Security and privacy review
- Feature flags and defaults
- Rollback procedure
- Known limitations
- Traceability updates
- Reviewer concerns

## Anti-patterns

- One agent implementing a whole phase
- Agents creating duplicate domain services
- Prompt-only enforcement of deterministic policies
- Tests written after integration
- Model-as-judge as the only evaluator
- Shared branches with multiple uncontrolled writers
- Notion pages as canonical state
- Large migrations merged with untested feature code
- “Temporary” bypasses of approval or consent gates


---

# Repository Assessment and Architecture Freeze

## Objective

Produce the repository-specific overlay required before implementation sub-agents modify code.

## Required inspection

- Frontend, backend, API, and deployment frameworks
- Authentication, authorization, tenant/workspace, and role models
- Database, ORM, migrations, transactions, and data-retention mechanisms
- Current profile, application, opportunity, artifact, content, consent, claim, evidence, test, and release entities
- Background jobs, schedulers, queues, idempotency, and dead-letter handling
- LLM gateway, prompt registry, structured-output validation, evaluation, and cost tracking
- Email, calendar, Notion, GitHub, analytics, storage, and publication integrations
- Logging, metrics, traces, error reporting, security scanning, and feature flags
- Unit, integration, E2E, contract, and load-test frameworks

## Deliverables

### Architecture map

List each relevant repository module, responsibility, owner, dependencies, and whether it is reused, extended, migrated, deprecated, or replaced.

### Entity reuse matrix

For each canonical FOS entity, identify the existing entity or migration decision. Duplicate person, workspace, artifact, approval, event, consent, claim, and agent-run systems are prohibited without an architecture decision record.

### File ownership map

Assign one primary owner to shared modules. Work packets receive allowlists and denylists based on this map.

### Contract freeze manifest

Record versions and locations for:

- API envelope
- Error envelope
- Event envelope
- Artifact and version schema
- Approval and command schema
- Agent-run and output schema
- Workspace projection schema
- Test and evaluation schemas

### Command registry

Record actual commands for install, lint, type-check, migrate, seed, unit test, integration test, E2E test, security test, build, and deploy.

## Architecture decision record template

```text
ADR ID:
Title:
Status:
Context:
Decision:
Alternatives:
Consequences:
Migration:
Rollback:
Affected contracts:
Approvers:
```

## Exit gate

No feature packet enters `ready` until the architecture map, file ownership map, and contract freeze manifest have been approved by the lead architecture and security reviewers.


---

# Cross-Phase Dependency DAG

```mermaid
flowchart TD
  subgraph P0[Phase 0: Founder Workspace and Operating Foundation]
    WP0A["WP0A Compatibility refactor and architecture contracts"]
    WP0_1["WP0.1 Canonical schema and migrations"]
    WP0_2["WP0.2 Domain services and event system"]
    WP0_3["WP0.3 Workspace provider interface and Notion adapter"]
    WP0_4["WP0.4 Collection bootstrap and mappings"]
    WP0_5["WP0.5 Read-only projections"]
    WP0_6["WP0.6 Webhooks, edit capture, and controlled commands"]
    WP0_7["WP0.7 Approval bridge and action boundaries"]
    WP0_8["WP0.8 Communications and campaign foundation"]
    WP0_9["WP0.9 Integration health, reconciliation, and metrics"]
    WP0_10["WP0.10 Test suite, deployment, and handoff"]
  end
  subgraph P1[Phase 1: Enrollment Revenue and Beta Launch Communications]
    WP1_0["WP1.0 Phase 0 contract verification and migration"]
    WP1_1["WP1.1 Opportunity and attribution extensions"]
    WP1_2["WP1.2 Enrollment agent runtime and assessments"]
    WP1_3["WP1.3 Call and post-call workflows"]
    WP1_4["WP1.4 Follow-up, objections, and next actions"]
    WP1_5["WP1.5 Enrollment Pipeline and Founder Inbox projections"]
    WP1_6["WP1.6 Beta launch campaign model and source brief"]
    WP1_7["WP1.7 LinkedIn, Substack, email, webinar, and landing-page artifacts"]
    WP1_8["WP1.8 Claims, consent, and platform-draft gates"]
    WP1_9["WP1.9 Funnel, campaign attribution, founder-time dashboards"]
    WP1_10["WP1.10 Evaluation, shadow mode, and production activation"]
  end
  subgraph P2[Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence]
    WP2_0["WP2.0 Phase 1 enrollment-to-beta handoff"]
    WP2_1["WP2.1 Beta domain schema and migration"]
    WP2_2["WP2.2 Onboarding artifacts and milestones"]
    WP2_3["WP2.3 Product activity and first-value instrumentation"]
    WP2_4["WP2.4 Explainable health engine"]
    WP2_5["WP2.5 Support queue and triage"]
    WP2_6["WP2.6 Outcome, consent, testimonial, and referral workflows"]
    WP2_7["WP2.7 Weekly editorial-cycle model"]
    WP2_8["WP2.8 LinkedIn and Substack agents and workspaces"]
    WP2_9["WP2.9 Engagement intelligence and question clustering"]
    WP2_10["WP2.10 Metrics, evaluation, and activation"]
  end
  subgraph P3[Phase 3: Product Learning, QA, Release, and Customer Proof]
    WP3_0["WP3.0 Phase 2 signal and outcome handoff"]
    WP3_1["WP3.1 Signal and cluster registry"]
    WP3_2["WP3.2 Change proposals and decisions"]
    WP3_3["WP3.3 Specification artifacts and canonical requirements"]
    WP3_4["WP3.4 Synthetic personas and test registry"]
    WP3_5["WP3.5 Test execution and evidence"]
    WP3_6["WP3.6 Security, memory, and injection suites"]
    WP3_7["WP3.7 Defects and regression investigation"]
    WP3_8["WP3.8 Release candidates and readiness"]
    WP3_9["WP3.9 Claim impact and revalidation"]
    WP3_10["WP3.10 Release communications and customer proof"]
    WP3_11["WP3.11 Product, QA, and Release Notion workspaces"]
  end
  subgraph P4[Phase 4: Scaled Marketing and Communications Operations]
    WP4_0["WP4.0 Phase 1-3 source and attribution migration"]
    WP4_1["WP4.1 Source brief and evidence eligibility"]
    WP4_2["WP4.2 Positioning and campaign planning"]
    WP4_3["WP4.3 LinkedIn production and carousel workflow"]
    WP4_4["WP4.4 Substack research and publishing workflow"]
    WP4_5["WP4.5 Email, webinar, landing page, and release packages"]
    WP4_6["WP4.6 Multi-channel repurposing"]
    WP4_7["WP4.7 Claims, consent, and pricing verification"]
    WP4_8["WP4.8 Platform draft adapters and publication records"]
    WP4_9["WP4.9 Performance ingestion and attribution"]
    WP4_10["WP4.10 Founder voice learning and experiments"]
    WP4_11["WP4.11 Communications Calendar and Campaign Center"]
  end
  subgraph P5[Phase 5: Competitive, Pricing, and Market Intelligence]
    WP5_0["WP5.0 Competitor taxonomy and approved-source policy"]
    WP5_1["WP5.1 Competitor, offering, and source registry"]
    WP5_2["WP5.2 Retrieval, hashing, and snapshots"]
    WP5_3["WP5.3 Observation extraction and verification"]
    WP5_4["WP5.4 Material change detection"]
    WP5_5["WP5.5 Pricing and offer intelligence"]
    WP5_6["WP5.6 Job-based comparison"]
    WP5_7["WP5.7 Strategic alerts and market briefs"]
    WP5_8["WP5.8 Notion intelligence workspace and decision commands"]
    WP5_9["WP5.9 Evaluation, freshness, and noise tuning"]
  end
  subgraph P6[Phase 6: Founder Chief of Staff, Command Center, and Automation Governance]
    WP6_0["WP6.0 Cross-phase data quality and metric readiness audit"]
    WP6_1["WP6.1 Strategic priority registry"]
    WP6_2["WP6.2 Unified canonical decision queue"]
    WP6_3["WP6.3 Notion Founder Command Center"]
    WP6_4["WP6.4 Cross-domain conflict detection"]
    WP6_5["WP6.5 Daily founder brief"]
    WP6_6["WP6.6 Weekly and monthly operating reviews"]
    WP6_7["WP6.7 Full specification compiler and critic"]
    WP6_8["WP6.8 Automation opportunity detection"]
    WP6_9["WP6.9 Autonomy governance and rollback"]
    WP6_10["WP6.10 Evaluation, tuning, and native-UI decision gate"]
  end
  WP0A --> WP0_1
  WP0_1 --> WP0_2
  WP0A --> WP0_3
  WP0_2 --> WP0_3
  WP0_3 --> WP0_4
  WP0_2 --> WP0_5
  WP0_4 --> WP0_5
  WP0_2 --> WP0_6
  WP0_5 --> WP0_6
  WP0_2 --> WP0_7
  WP0_6 --> WP0_7
  WP0_1 --> WP0_8
  WP0_2 --> WP0_8
  WP0_7 --> WP0_8
  WP0_3 --> WP0_9
  WP0_4 --> WP0_9
  WP0_5 --> WP0_9
  WP0_6 --> WP0_9
  WP0_7 --> WP0_9
  WP0_8 --> WP0_9
  WP0_1 --> WP0_10
  WP0_2 --> WP0_10
  WP0_3 --> WP0_10
  WP0_4 --> WP0_10
  WP0_5 --> WP0_10
  WP0_6 --> WP0_10
  WP0_7 --> WP0_10
  WP0_8 --> WP0_10
  WP0_9 --> WP0_10
  WP0_10 --> WP1_0
  WP1_0 --> WP1_1
  WP1_0 --> WP1_2
  WP1_1 --> WP1_2
  WP1_2 --> WP1_3
  WP1_2 --> WP1_4
  WP1_3 --> WP1_4
  WP1_1 --> WP1_5
  WP1_4 --> WP1_5
  WP1_0 --> WP1_6
  WP0_8 --> WP1_6
  WP1_6 --> WP1_7
  WP1_7 --> WP1_8
  WP0_7 --> WP1_8
  WP0_8 --> WP1_8
  WP1_1 --> WP1_9
  WP1_5 --> WP1_9
  WP1_6 --> WP1_9
  WP1_7 --> WP1_9
  WP1_2 --> WP1_10
  WP1_3 --> WP1_10
  WP1_4 --> WP1_10
  WP1_5 --> WP1_10
  WP1_6 --> WP1_10
  WP1_7 --> WP1_10
  WP1_8 --> WP1_10
  WP1_9 --> WP1_10
  WP1_10 --> WP2_0
  WP2_0 --> WP2_1
  WP2_1 --> WP2_2
  WP2_1 --> WP2_3
  WP2_3 --> WP2_4
  WP2_1 --> WP2_5
  WP2_2 --> WP2_6
  WP2_5 --> WP2_6
  WP2_0 --> WP2_7
  WP0_8 --> WP2_7
  WP2_7 --> WP2_8
  WP2_8 --> WP2_9
  WP2_2 --> WP2_10
  WP2_3 --> WP2_10
  WP2_4 --> WP2_10
  WP2_5 --> WP2_10
  WP2_6 --> WP2_10
  WP2_7 --> WP2_10
  WP2_8 --> WP2_10
  WP2_9 --> WP2_10
  WP2_10 --> WP3_0
  WP3_0 --> WP3_1
  WP3_1 --> WP3_2
  WP3_2 --> WP3_3
  WP3_3 --> WP3_4
  WP3_4 --> WP3_5
  WP3_5 --> WP3_6
  WP3_5 --> WP3_7
  WP3_6 --> WP3_7
  WP3_3 --> WP3_8
  WP3_5 --> WP3_8
  WP3_7 --> WP3_8
  WP3_8 --> WP3_9
  WP3_8 --> WP3_10
  WP3_9 --> WP3_10
  WP3_1 --> WP3_11
  WP3_3 --> WP3_11
  WP3_5 --> WP3_11
  WP3_8 --> WP3_11
  WP3_10 --> WP3_11
  WP1_10 --> WP4_0
  WP2_10 --> WP4_0
  WP3_10 --> WP4_0
  WP4_0 --> WP4_1
  WP4_1 --> WP4_2
  WP4_2 --> WP4_3
  WP4_2 --> WP4_4
  WP4_2 --> WP4_5
  WP4_3 --> WP4_6
  WP4_4 --> WP4_6
  WP4_5 --> WP4_6
  WP4_1 --> WP4_7
  WP4_3 --> WP4_7
  WP4_4 --> WP4_7
  WP4_5 --> WP4_7
  WP4_6 --> WP4_7
  WP4_7 --> WP4_8
  WP4_8 --> WP4_9
  WP4_9 --> WP4_10
  WP4_1 --> WP4_11
  WP4_2 --> WP4_11
  WP4_3 --> WP4_11
  WP4_4 --> WP4_11
  WP4_5 --> WP4_11
  WP4_6 --> WP4_11
  WP4_7 --> WP4_11
  WP4_8 --> WP4_11
  WP4_9 --> WP4_11
  WP4_10 --> WP4_11
  WP0_10 --> WP5_0
  WP5_0 --> WP5_1
  WP5_1 --> WP5_2
  WP5_2 --> WP5_3
  WP5_3 --> WP5_4
  WP5_3 --> WP5_5
  WP5_3 --> WP5_6
  WP5_5 --> WP5_6
  WP5_4 --> WP5_7
  WP5_5 --> WP5_7
  WP5_6 --> WP5_7
  WP5_7 --> WP5_8
  WP5_2 --> WP5_9
  WP5_3 --> WP5_9
  WP5_4 --> WP5_9
  WP5_5 --> WP5_9
  WP5_6 --> WP5_9
  WP5_7 --> WP5_9
  WP5_8 --> WP5_9
  WP1_10 --> WP6_0
  WP2_10 --> WP6_0
  WP3_10 --> WP6_0
  WP4_10 --> WP6_0
  WP5_9 --> WP6_0
  WP6_0 --> WP6_1
  WP6_0 --> WP6_2
  WP6_1 --> WP6_2
  WP6_2 --> WP6_3
  WP6_2 --> WP6_4
  WP6_2 --> WP6_5
  WP6_4 --> WP6_5
  WP6_5 --> WP6_6
  WP3_3 --> WP6_7
  WP6_1 --> WP6_7
  WP6_6 --> WP6_8
  WP6_8 --> WP6_9
  WP6_3 --> WP6_10
  WP6_4 --> WP6_10
  WP6_5 --> WP6_10
  WP6_6 --> WP6_10
  WP6_7 --> WP6_10
  WP6_8 --> WP6_10
  WP6_9 --> WP6_10
```

## Scheduling rules

- Phase gates indicate contract readiness, not necessarily completion of every UI refinement.
- Market-intelligence work may begin after Phase 0, but its strategic integration into Phase 6 waits for Phase 5 acceptance.
- Phase 4 source migration requires accepted evidence and attribution contracts from Phases 1-3.
- Phase 6 begins only after data-quality and metric readiness from all operational phases.
- Work packages without direct dependencies may run in parallel only after file ownership is assigned.


---

# Interface, Event, and Agent Contracts

## Shared API conventions

- Version APIs explicitly or through compatible additive evolution.
- Validate request and response bodies with repository-native typed schemas.
- Use stable machine-readable error codes.
- Require idempotency keys for intake, commands, external drafts, publication records, test execution, and webhooks.
- Use optimistic concurrency for founder-editable and lifecycle records.
- Paginate collection endpoints.
- Enforce authorization server-side.

## Error envelope

```json
{
  "error": {
    "code": "FOS_VERSION_CONFLICT",
    "message": "The record changed after the workspace projection was loaded.",
    "correlation_id": "uuid",
    "retryable": false,
    "details": {}
  }
}
```

## Event envelope

Every event includes:

- `event_id`
- `event_type`
- `schema_version`
- `workspace_id`
- `entity_type`
- `entity_id`
- `occurred_at`
- `actor_type`
- `actor_id`
- `correlation_id`
- `causation_id`
- `idempotency_key`
- `payload`

Events are append-only. Consumers must be idempotent. Breaking event changes require a new schema version.

## Artifact contract

Artifacts separate identity from immutable versions. Working-copy edits create new versions after validation. Approval targets a specific version. Published or executed artifacts retain a final snapshot.

## Workspace command contract

Notion and future workspace providers never directly change protected state. A workspace action creates a command that is authenticated, deduplicated, version-checked, policy-checked, executed through domain services, audited, and projected back.

## Agent contract

Each agent definition includes:

- Stable key and version
- Bounded objective
- Trigger and input schema
- Allowed context scopes
- Allowed tools
- Prohibited actions
- Structured output schema
- Required evidence
- Deterministic validation
- Evaluation rubric
- Escalation rules
- Maximum autonomy
- Timeout and cost limits

## Compatibility rules

- Additive fields default safely.
- Removing or changing meaning requires migration and dual-read or dual-write where needed.
- Prompts and model changes are versioned independently of output schemas.
- Agent output schema changes require evaluation-set reruns.


---

# Canonical Schema and Migration Plan

## Migration principles

- Reuse existing identity, user, and workspace records when stable identifiers exist.
- Introduce generic `ArtifactRecord` and `ArtifactVersion` primitives before phase-specific document workflows.
- Keep raw source events immutable and summaries versioned.
- Use forward-only migrations in production unless the repository has a tested rollback mechanism.
- Separate schema migration, data backfill, and feature activation.
- Make backfills restartable, idempotent, observable, and bounded.

## Migration stages

1. Inventory and compatibility analysis
2. Additive schema creation
3. Dual-read or compatibility adapters
4. Idempotent data backfill
5. Data-quality verification
6. Shadow reads and comparison
7. Canonical cutover
8. Legacy write disablement
9. Cleanup after retention window

## Required migration tests

- Empty database migration
- Production-like snapshot migration
- Restart after partial backfill
- Duplicate and malformed legacy records
- Workspace-isolation validation
- Referential integrity
- Version and timestamp preservation
- Rollback or forward-fix rehearsal

## Data-quality checks

- Orphaned foreign keys
- Duplicate canonical identities
- Missing workspace IDs
- Invalid consent or claim states
- Artifact versions without records
- Approval targets without immutable snapshots
- Events without correlation IDs
- Notion projections without canonical links

## Schema ownership

Only the foundation schema owner may merge changes to shared canonical primitives. Phase agents may add phase-owned tables after contract review.


---

# Notion Founder Workspace Adapter Contract

## Architectural role

Notion is a human-editable projection, planning, and command surface. FOS owns canonical state, authorization, evidence, claims, consent, agent runs, metrics, and audit.

## Field ownership classes

- `canonical_read_only` - shown in Notion; changed only by FOS.
- `working_copy_editable` - founder may edit prose or notes; changes become versioned artifacts.
- `controlled_command` - a property or button creates a validated command.
- `not_projectable` - secrets, private raw data, full traces, and sensitive evidence.

## Required hidden properties

- FOS Record ID
- FOS Entity Type
- FOS Version
- FOS Workspace ID
- Projection Version
- Last Synced At

## Synchronization flow

FOS events create or update projections. Notion webhooks create deduplicated `WorkspaceCommand` records. The command service validates identity, current version, consent, claims, authorization, and action policy before calling domain services.

## Conflict behavior

If projected and canonical versions differ, do not overwrite. Create a conflict record, preserve both snapshots, and require resolution.

## Rate-limit and resilience behavior

- Queue provider operations.
- Use exponential backoff for retryable provider errors.
- Reconcile periodically using hashes and version stamps.
- Keep FOS fully operational while Notion is unavailable.
- Mark projections out of sync after retry exhaustion.

## Security

- Use minimum integration scopes.
- Store credentials in secret management.
- Do not project raw prompts, secrets, payment data, unrestricted transcripts, or exploitable security details.
- Revalidate claims and consent after founder edits.


---

# Shared Test Harness and Integration Suite

## Objective

Provide one reusable harness so feature agents do not invent incompatible mocks, clocks, provider adapters, identity fixtures, or event assertions.

## Required harness components

- Ephemeral relational database and migration runner
- Transaction and cleanup helpers
- Stable fixture loader
- Fake clock and timezone control
- Queue and scheduler test adapter
- Deterministic model stub and recorded-output mode
- Fake Notion provider and webhook simulator
- Fake email, calendar, GitHub, object-storage, analytics, and publication adapters
- Identity, role, and workspace fixtures
- Event collector and correlation assertions
- Cost, latency, and telemetry collector
- Failure injection for timeouts, duplicates, stale versions, partial writes, and provider outages

## Test layers

### Unit

Pure validation, state machines, calculations, policies, mappers, and evaluators.

### Contract

Request/response schemas, event schemas, provider adapter behavior, structured agent output, and migration compatibility.

### Integration

Database, domain service, event, queue, provider adapter, claims, consent, approval, and audit interactions.

### Agent evaluation

Grounding, completeness, policy, privacy, product consistency, escalation, and founder usefulness.

### End-to-end

Founder-visible workflows across UI or workspace, canonical services, agents, approvals, adapters, and metrics.

### Security and resilience

Workspace isolation, prompt injection, malicious documents, stale claims, revoked consent, replayed webhooks, privilege escalation, timeout, retry, and rollback.

## Mandatory cross-system scenarios

1. Application -> person -> opportunity -> enrollment brief -> approval.
2. Founder edit in Notion -> command -> version check -> claims revalidation -> canonical artifact.
3. Approval -> downstream email or platform draft; no autonomous send.
4. Enrollment -> onboarding -> first value -> outcome evidence.
5. Support case -> triage -> product signal -> change proposal.
6. Specification -> requirements -> tests -> release candidate.
7. Release -> capability update -> claim-impact scan.
8. Evidence -> LinkedIn/Substack asset -> approval -> publication record.
9. Consent revocation -> pending and future public-use assets blocked.
10. Competitor change -> observation -> strategic alert.
11. Cross-domain conflict -> Founder Inbox -> resolution.
12. Provider failure -> retry -> dead letter -> reconciliation.

## Determinism

Agent tests use fixed fixtures, frozen model outputs or deterministic stubs, and explicit evaluator versions. Live-model smoke tests are separate and non-blocking until calibrated.


---

# Fixture and Golden Dataset Catalog

## Rules

- Fixtures use fictional people and organizations.
- Stable fixture IDs never change meaning.
- Sensitive traits are excluded unless needed for an explicit safety test.
- One fixture may be reused across unit, integration, E2E, and agent-evaluation tests.
- Expected outcomes are versioned.

## Domains

### Enrollment

Strong fit, ambiguous fit, incomplete application, contradictory history, price objection, time objection, unresponsive lead, revoked consent, prompt injection, and out-of-scope request.

### Beta operations

Healthy active user, scheduled pause, product-defect block, onboarding confusion, first-value achievement, withdrawal, referral readiness, and unverified outcome.

### Product and QA

Repeated product signal, memory leak, malformed output, tool timeout, duplicate event, version conflict, regression, and release rollback.

### Marketing

Approved release, named consent, anonymous consent, no consent, expired claim, planned capability, comparative claim, long-form paper, and derivative adding an unsupported claim.

### Market intelligence

Verified pricing change, unchanged page, removed feature, company claim, low-confidence rumor, and malicious source instruction.

The concrete JSON fixtures are under `fixtures/` and referenced by the machine-readable test catalogs.


---

# Agent Evaluation Framework

## Evaluation dimensions

| Dimension | Question | Primary method |
|---|---|---|
| Grounding | Are factual statements supported by allowed evidence? | Deterministic source resolution plus evaluator |
| Completeness | Are required fields and material risks present? | Schema and rubric |
| Policy | Were approvals, consent, claims, and autonomy boundaries followed? | Deterministic checks |
| Privacy | Was unrelated or sensitive information excluded? | Rule-based and adversarial tests |
| Product consistency | Does output match current capabilities, offer, release, and strategy? | Canonical lookups |
| Usefulness | Does it reduce founder work and support a sound decision? | Founder sample scoring |
| Stability | Does behavior remain acceptable across model or prompt changes? | Regression set |
| Efficiency | Is cost and latency proportionate to business value? | Telemetry |

## Scoring

Use a 100-point rubric with hard gates. A high overall score cannot compensate for a hard failure in authorization, consent, unsupported claims, cross-user leakage, or unauthorized external action.

Suggested weights:

- Grounding 25
- Completeness 15
- Policy 20
- Privacy 15
- Product consistency 10
- Usefulness 10
- Efficiency 5

## Evaluation release gate

- All hard-gate cases pass.
- Mean score meets agent-specific threshold.
- No material regression against the prior accepted agent version.
- Founder reviews a calibrated sample before production activation.
- Prompt, model, tools, output schema, and evaluator versions are recorded.

## Live monitoring

Sample accepted outputs, founder edits, rejections, failures, and outcome effectiveness. Do not train or update durable founder preferences from a single edit.


---

# Business Outcome Measurement Contracts

## Phase 0 - Founder Workspace and Operating Foundation

| Metric | Definition | Initial target |
|---|---|---|
| FOS foundation readiness | percentage of mandatory shared contracts passing validation | 100% |
| Workspace sync reliability | successful projection and command operations | >=99% |
| Canonical ownership compliance | protected fields updated only through FOS commands | 100% |
| Audit completeness | consequential actions with complete event lineage | 100% |

## Phase 1 - Enrollment Revenue and Beta Launch Communications

| Metric | Definition | Initial target |
|---|---|---|
| Lead-to-enrollment conversion | enrolled opportunities divided by qualified leads | baseline + measurable uplift |
| Median first response time | application received to approved first response | <1 business day |
| Founder time per qualified lead | measured preparation and follow-up minutes | >=50% reduction |
| Launch-assisted enrollments | enrollments with attributable campaign touches | reported with confidence |

## Phase 2 - Beta Activation, Retention, Support, and Founder Editorial Cadence

| Metric | Definition | Initial target |
|---|---|---|
| Onboarding completion | active beta users completing required onboarding | >=80% |
| Time to first value | activation to verified first-value milestone | decreasing by cohort |
| At-risk recovery | at-risk users returning to healthy/watch | tracked |
| Founder support time | founder minutes per active beta user | >=50% reduction |
| Editorial cadence | approved LinkedIn and Substack assets per cycle | meets configured cadence |

## Phase 3 - Product Learning, QA, Release, and Customer Proof

| Metric | Definition | Initial target |
|---|---|---|
| Requirement-to-test coverage | approved requirements with linked automated tests | >=90% |
| Defect escape rate | production defects not detected pre-release | decreasing |
| Release evidence completeness | release candidates with full readiness dossier | 100% |
| Critical isolation failures | cross-user memory leaks | 0 |
| Signal-to-decision time | validated signal cluster to founder decision | decreasing |

## Phase 4 - Scaled Marketing and Communications Operations

| Metric | Definition | Initial target |
|---|---|---|
| Content production time | founder minutes per approved asset | >=50% reduction |
| Qualified demand | qualified leads generated by content | increasing |
| Content-assisted enrollment | attributed assisted conversions | reported by model |
| Unsupported claim rate | published assets with unsupported claims | 0 |
| Repurposing leverage | approved derivatives per source asset | >=3 |

## Phase 5 - Competitive, Pricing, and Market Intelligence

| Metric | Definition | Initial target |
|---|---|---|
| Material alert precision | alerts accepted as decision-relevant | target >=70% |
| Pricing freshness | active competitor price observations within policy window | >=90% |
| Duplicate alert rate | duplicate or unchanged alerts | <5% |
| Founder research time | hours spent on routine monitoring | decreasing |

## Phase 6 - Founder Chief of Staff, Command Center, and Automation Governance

| Metric | Definition | Initial target |
|---|---|---|
| Founder decision time | median time from surfaced decision to disposition | decreasing |
| Unresolved critical items | critical items beyond SLA | 0 |
| Recommendation acceptance | accepted or accepted-with-edit recommendations | increasing |
| Founder hours saved | measured against documented baselines | target 8-14 hours/week |
| Conflict prevention | conflicts resolved before external impact | tracked |

## Measurement rules

- Every metric names its source events, calculation, timezone, attribution window, exclusions, owner, and data-quality check.
- Founder-time savings require a documented baseline and measured or explicitly labeled estimated duration.
- Content attribution reports first-touch, last-touch, and assisted models separately.
- User outcomes distinguish observation, self-report, verified evidence, and causal inference.
- Targets are configuration, not hard-coded application logic.


---

# CI/CD, Merge, and Release Gates

## Pull-request gates

- Formatting and lint
- Type checking
- Unit tests
- Changed contract validation
- Changed migration validation
- Packet-specific integration tests
- Secret and dependency scanning
- Traceability entry present

## Merge gates

- Independent reviewer approval
- Shared contract suite
- Workspace-isolation suite for affected data paths
- Claims and consent suite for external-content paths
- Event and audit assertions
- Feature flag defaults safe
- Migration compatibility and restart test

## Release gates

- Affected E2E journeys
- Agent evaluation regression
- Prompt-injection and malicious-source suite
- Memory-isolation suite
- Performance and cost budgets
- Release-readiness report
- Rollback rehearsal
- Founder approval for consequential activation

## Branching

Use short-lived packet branches or worktrees and an integration branch. Protect shared primitives with code owners. Use a merge queue for migration, event, agent-runtime, and workspace-adapter modules.

## Feature activation

Progress through disabled, test, shadow, founder-only, limited cohort, and full activation. Publishing, sending, deployment, pricing, and autonomy increases require separate approvals.


---

# Security, Red-Team, and Resilience Plan

## Threat classes

- Cross-workspace and cross-user data leakage
- Prompt injection in applications, resumes, support messages, Notion pages, webpages, and tool output
- Unauthorized command or webhook replay
- Privilege escalation
- Consent or claims bypass
- Stale version overwrite
- External action without approval
- Secret leakage in prompts, logs, or projections
- Malicious file or URL processing
- Model hallucination presented as evidence
- Supply-chain and dependency compromise
- Queue duplication, partial workflow, and retry storms

## Required controls

- Least privilege and server-side authorization
- Provider webhook verification and idempotency
- Context minimization and source manifests
- Untrusted-content delimiters and tool allowlists
- Deterministic consent, claims, price, release, and approval gates
- Encrypted secrets and sensitive fields
- Structured logs without raw private content
- Rate limits and cost ceilings
- Dead-letter queues and reconciliation
- Immutable audit and versioned artifacts

## Release-blocking tests

Any confirmed cross-user leak, unauthorized external action, consent bypass, critical injection exploit, or inability to reconstruct a consequential action blocks release.


---

# Sub-Agent Team Topology and RACI

## Teams

### Foundation

Architecture and contracts, database and migration, workspace integration, security and authorization.

### Enrollment

Opportunity workflow, enrollment intelligence, launch communications, enrollment verification.

### Beta operations

Onboarding and milestones, health and intervention, support and outcomes, editorial cadence.

### Product quality

Signals and specifications, test platform, red team, regression and release readiness.

### Communications

Evidence and positioning, LinkedIn and repurposing, Substack and research, claims and attribution.

### Market and founder operations

Market intelligence, conflict detection, chief of staff, operating reviews, autonomy governance.

## RACI rule

- One Responsible implementation agent per packet.
- One Accountable orchestrator or lead per phase gate.
- At least one Consulted domain or security reviewer for shared-contract changes.
- Founder is Informed for reversible internal changes and Accountable for strategic, public, pricing, deployment, and autonomy decisions.

## Reviewer independence

The reviewer should use the packet, contracts, diff, and test evidence, not the implementation agent's narrative alone.


---

# Execution Packet Standard

Every packet includes:

1. Objective and business value
2. Scope and explicit non-scope
3. Dependencies and contract versions
4. Inputs and fixtures
5. Deliverables
6. Interfaces consumed and produced
7. Allowed and prohibited changes
8. Functional requirements
9. Security, privacy, and governance constraints
10. Required tests and gates
11. Observability and cost requirements
12. Migration and rollout
13. Definition of done
14. Completion evidence
15. Independent-review checklist
16. Escalation conditions

## Repository overlay

Before leasing a packet, the orchestrator adds:

- Assigned agent and reviewer
- Branch or worktree
- Allowed file globs
- Prohibited file globs
- Actual commands
- Environment and fixture set
- Contract commit hashes
- Lease expiration

## Scope discipline

A packet agent may make necessary local implementation choices but may not change cross-packet contracts, security posture, or architecture without an approved change proposal.


---

# Implementation Sequence and Release Trains

## Release Train A - Foundation

WP0A through WP0.10. Exit requires canonical contracts, workspace adapter, test harness, CI gates, and founder-only shadow operation.

## Release Train B - Revenue

WP1.0 through WP1.10. Exit requires enrollment and launch communication workflows in shadow mode, then controlled founder use.

## Release Train C - Beta operations

WP2.0 through WP2.10. Exit requires onboarding, first value, support, outcomes, and editorial cadence.

## Release Train D - Product quality

WP3.0 through WP3.11. Exit requires signal-to-release traceability, security suites, and release readiness.

## Release Train E - Marketing scale

WP4.0 through WP4.11. Exit requires evidence-driven multi-channel campaigns and reliable attribution.

## Release Train F - Market intelligence

WP5.0 through WP5.9. May overlap late Release Train E after Phase 0 contracts are stable.

## Release Train G - Founder coordination

WP6.0 through WP6.10. Begins only after operational data-quality readiness. Native UI remains deferred until measured Notion limitations justify it.


---

# Work Package Registry

| Work package | Phase | Deliverable | Dependencies | Risk | Team |
|---|---:|---|---|---|---|
| WP0A | 0 | Compatibility refactor and architecture contracts | - | medium | foundation |
| WP0.1 | 0 | Canonical schema and migrations | WP0A | critical | foundation |
| WP0.2 | 0 | Domain services and event system | WP0.1 | critical | foundation |
| WP0.3 | 0 | Workspace provider interface and Notion adapter | WP0A;WP0.2 | medium | foundation |
| WP0.4 | 0 | Collection bootstrap and mappings | WP0.3 | medium | foundation |
| WP0.5 | 0 | Read-only projections | WP0.2;WP0.4 | medium | foundation |
| WP0.6 | 0 | Webhooks, edit capture, and controlled commands | WP0.2;WP0.5 | high | foundation |
| WP0.7 | 0 | Approval bridge and action boundaries | WP0.2;WP0.6 | critical | foundation |
| WP0.8 | 0 | Communications and campaign foundation | WP0.1;WP0.2;WP0.7 | medium | foundation |
| WP0.9 | 0 | Integration health, reconciliation, and metrics | WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8 | high | foundation |
| WP0.10 | 0 | Test suite, deployment, and handoff | WP0.1;WP0.2;WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8;WP0.9 | medium | foundation |
| WP1.0 | 1 | Phase 0 contract verification and migration | WP0.10 | critical | enrollment |
| WP1.1 | 1 | Opportunity and attribution extensions | WP1.0 | high | enrollment |
| WP1.2 | 1 | Enrollment agent runtime and assessments | WP1.0;WP1.1 | high | enrollment |
| WP1.3 | 1 | Call and post-call workflows | WP1.2 | medium | enrollment |
| WP1.4 | 1 | Follow-up, objections, and next actions | WP1.2;WP1.3 | medium | enrollment |
| WP1.5 | 1 | Enrollment Pipeline and Founder Inbox projections | WP1.1;WP1.4 | medium | enrollment |
| WP1.6 | 1 | Beta launch campaign model and source brief | WP1.0;WP0.8 | medium | enrollment |
| WP1.7 | 1 | LinkedIn, Substack, email, webinar, and landing-page artifacts | WP1.6 | medium | enrollment |
| WP1.8 | 1 | Claims, consent, and platform-draft gates | WP1.7;WP0.7;WP0.8 | critical | enrollment |
| WP1.9 | 1 | Funnel, campaign attribution, founder-time dashboards | WP1.1;WP1.5;WP1.6;WP1.7 | high | enrollment |
| WP1.10 | 1 | Evaluation, shadow mode, and production activation | WP1.2;WP1.3;WP1.4;WP1.5;WP1.6;WP1.7;WP1.8;WP1.9 | medium | enrollment |
| WP2.0 | 2 | Phase 1 enrollment-to-beta handoff | WP1.10 | medium | beta_operations |
| WP2.1 | 2 | Beta domain schema and migration | WP2.0 | critical | beta_operations |
| WP2.2 | 2 | Onboarding artifacts and milestones | WP2.1 | medium | beta_operations |
| WP2.3 | 2 | Product activity and first-value instrumentation | WP2.1 | medium | beta_operations |
| WP2.4 | 2 | Explainable health engine | WP2.3 | high | beta_operations |
| WP2.5 | 2 | Support queue and triage | WP2.1 | medium | beta_operations |
| WP2.6 | 2 | Outcome, consent, testimonial, and referral workflows | WP2.2;WP2.5 | critical | beta_operations |
| WP2.7 | 2 | Weekly editorial-cycle model | WP2.0;WP0.8 | medium | beta_operations |
| WP2.8 | 2 | LinkedIn and Substack agents and workspaces | WP2.7 | high | beta_operations |
| WP2.9 | 2 | Engagement intelligence and question clustering | WP2.8 | medium | beta_operations |
| WP2.10 | 2 | Metrics, evaluation, and activation | WP2.2;WP2.3;WP2.4;WP2.5;WP2.6;WP2.7;WP2.8;WP2.9 | medium | beta_operations |
| WP3.0 | 3 | Phase 2 signal and outcome handoff | WP2.10 | medium | product_quality |
| WP3.1 | 3 | Signal and cluster registry | WP3.0 | medium | product_quality |
| WP3.2 | 3 | Change proposals and decisions | WP3.1 | medium | product_quality |
| WP3.3 | 3 | Specification artifacts and canonical requirements | WP3.2 | medium | product_quality |
| WP3.4 | 3 | Synthetic personas and test registry | WP3.3 | medium | product_quality |
| WP3.5 | 3 | Test execution and evidence | WP3.4 | medium | product_quality |
| WP3.6 | 3 | Security, memory, and injection suites | WP3.5 | critical | product_quality |
| WP3.7 | 3 | Defects and regression investigation | WP3.5;WP3.6 | medium | product_quality |
| WP3.8 | 3 | Release candidates and readiness | WP3.3;WP3.5;WP3.7 | critical | product_quality |
| WP3.9 | 3 | Claim impact and revalidation | WP3.8 | medium | product_quality |
| WP3.10 | 3 | Release communications and customer proof | WP3.8;WP3.9 | critical | product_quality |
| WP3.11 | 3 | Product, QA, and Release Notion workspaces | WP3.1;WP3.3;WP3.5;WP3.8;WP3.10 | critical | product_quality |
| WP4.0 | 4 | Phase 1-3 source and attribution migration | WP1.10;WP2.10;WP3.10 | critical | communications |
| WP4.1 | 4 | Source brief and evidence eligibility | WP4.0 | medium | communications |
| WP4.2 | 4 | Positioning and campaign planning | WP4.1 | medium | communications |
| WP4.3 | 4 | LinkedIn production and carousel workflow | WP4.2 | medium | communications |
| WP4.4 | 4 | Substack research and publishing workflow | WP4.2 | medium | communications |
| WP4.5 | 4 | Email, webinar, landing page, and release packages | WP4.2 | critical | communications |
| WP4.6 | 4 | Multi-channel repurposing | WP4.3;WP4.4;WP4.5 | medium | communications |
| WP4.7 | 4 | Claims, consent, and pricing verification | WP4.1;WP4.3;WP4.4;WP4.5;WP4.6 | critical | communications |
| WP4.8 | 4 | Platform draft adapters and publication records | WP4.7 | medium | communications |
| WP4.9 | 4 | Performance ingestion and attribution | WP4.8 | high | communications |
| WP4.10 | 4 | Founder voice learning and experiments | WP4.9 | medium | communications |
| WP4.11 | 4 | Communications Calendar and Campaign Center | WP4.1;WP4.2;WP4.3;WP4.4;WP4.5;WP4.6;WP4.7;WP4.8;WP4.9;WP4.10 | medium | communications |
| WP5.0 | 5 | Competitor taxonomy and approved-source policy | WP0.10 | medium | market_intelligence |
| WP5.1 | 5 | Competitor, offering, and source registry | WP5.0 | medium | market_intelligence |
| WP5.2 | 5 | Retrieval, hashing, and snapshots | WP5.1 | medium | market_intelligence |
| WP5.3 | 5 | Observation extraction and verification | WP5.2 | medium | market_intelligence |
| WP5.4 | 5 | Material change detection | WP5.3 | medium | market_intelligence |
| WP5.5 | 5 | Pricing and offer intelligence | WP5.3 | high | market_intelligence |
| WP5.6 | 5 | Job-based comparison | WP5.3;WP5.5 | medium | market_intelligence |
| WP5.7 | 5 | Strategic alerts and market briefs | WP5.4;WP5.5;WP5.6 | medium | market_intelligence |
| WP5.8 | 5 | Notion intelligence workspace and decision commands | WP5.7 | high | market_intelligence |
| WP5.9 | 5 | Evaluation, freshness, and noise tuning | WP5.2;WP5.3;WP5.4;WP5.5;WP5.6;WP5.7;WP5.8 | medium | market_intelligence |
| WP6.0 | 6 | Cross-phase data quality and metric readiness audit | WP1.10;WP2.10;WP3.10;WP4.10;WP5.9 | medium | founder_coordination |
| WP6.1 | 6 | Strategic priority registry | WP6.0 | medium | founder_coordination |
| WP6.2 | 6 | Unified canonical decision queue | WP6.0;WP6.1 | medium | founder_coordination |
| WP6.3 | 6 | Notion Founder Command Center | WP6.2 | high | founder_coordination |
| WP6.4 | 6 | Cross-domain conflict detection | WP6.2 | medium | founder_coordination |
| WP6.5 | 6 | Daily founder brief | WP6.2;WP6.4 | medium | founder_coordination |
| WP6.6 | 6 | Weekly and monthly operating reviews | WP6.5 | medium | founder_coordination |
| WP6.7 | 6 | Full specification compiler and critic | WP3.3;WP6.1 | medium | founder_coordination |
| WP6.8 | 6 | Automation opportunity detection | WP6.6 | medium | founder_coordination |
| WP6.9 | 6 | Autonomy governance and rollback | WP6.8 | critical | founder_coordination |
| WP6.10 | 6 | Evaluation, tuning, and native-UI decision gate | WP6.3;WP6.4;WP6.5;WP6.6;WP6.7;WP6.8;WP6.9 | medium | founder_coordination |

## Verification volume

- Work packages: 78
- Execution requirements: 468
- Packet tests: 390
- Golden fixtures: 29


---

# Appendix: Execution Packet Index

Detailed packets are provided as separate files under `execution-packets/`.

- **WP0A** - Compatibility refactor and architecture contracts (`execution-packets/phase-0/wp0a_compatibility_refactor_and_architecture_contracts.md`)
- **WP0.1** - Canonical schema and migrations (`execution-packets/phase-0/wp0-1_canonical_schema_and_migrations.md`)
- **WP0.2** - Domain services and event system (`execution-packets/phase-0/wp0-2_domain_services_and_event_system.md`)
- **WP0.3** - Workspace provider interface and Notion adapter (`execution-packets/phase-0/wp0-3_workspace_provider_interface_and_notion_adapter.md`)
- **WP0.4** - Collection bootstrap and mappings (`execution-packets/phase-0/wp0-4_collection_bootstrap_and_mappings.md`)
- **WP0.5** - Read-only projections (`execution-packets/phase-0/wp0-5_read_only_projections.md`)
- **WP0.6** - Webhooks, edit capture, and controlled commands (`execution-packets/phase-0/wp0-6_webhooks_edit_capture_and_controlled_commands.md`)
- **WP0.7** - Approval bridge and action boundaries (`execution-packets/phase-0/wp0-7_approval_bridge_and_action_boundaries.md`)
- **WP0.8** - Communications and campaign foundation (`execution-packets/phase-0/wp0-8_communications_and_campaign_foundation.md`)
- **WP0.9** - Integration health, reconciliation, and metrics (`execution-packets/phase-0/wp0-9_integration_health_reconciliation_and_metrics.md`)
- **WP0.10** - Test suite, deployment, and handoff (`execution-packets/phase-0/wp0-10_test_suite_deployment_and_handoff.md`)
- **WP1.0** - Phase 0 contract verification and migration (`execution-packets/phase-1/wp1-0_phase_0_contract_verification_and_migration.md`)
- **WP1.1** - Opportunity and attribution extensions (`execution-packets/phase-1/wp1-1_opportunity_and_attribution_extensions.md`)
- **WP1.2** - Enrollment agent runtime and assessments (`execution-packets/phase-1/wp1-2_enrollment_agent_runtime_and_assessments.md`)
- **WP1.3** - Call and post-call workflows (`execution-packets/phase-1/wp1-3_call_and_post_call_workflows.md`)
- **WP1.4** - Follow-up, objections, and next actions (`execution-packets/phase-1/wp1-4_follow_up_objections_and_next_actions.md`)
- **WP1.5** - Enrollment Pipeline and Founder Inbox projections (`execution-packets/phase-1/wp1-5_enrollment_pipeline_and_founder_inbox_projections.md`)
- **WP1.6** - Beta launch campaign model and source brief (`execution-packets/phase-1/wp1-6_beta_launch_campaign_model_and_source_brief.md`)
- **WP1.7** - LinkedIn, Substack, email, webinar, and landing-page artifacts (`execution-packets/phase-1/wp1-7_linkedin_substack_email_webinar_and_landing_page_artifacts.md`)
- **WP1.8** - Claims, consent, and platform-draft gates (`execution-packets/phase-1/wp1-8_claims_consent_and_platform_draft_gates.md`)
- **WP1.9** - Funnel, campaign attribution, founder-time dashboards (`execution-packets/phase-1/wp1-9_funnel_campaign_attribution_founder_time_dashboards.md`)
- **WP1.10** - Evaluation, shadow mode, and production activation (`execution-packets/phase-1/wp1-10_evaluation_shadow_mode_and_production_activation.md`)
- **WP2.0** - Phase 1 enrollment-to-beta handoff (`execution-packets/phase-2/wp2-0_phase_1_enrollment_to_beta_handoff.md`)
- **WP2.1** - Beta domain schema and migration (`execution-packets/phase-2/wp2-1_beta_domain_schema_and_migration.md`)
- **WP2.2** - Onboarding artifacts and milestones (`execution-packets/phase-2/wp2-2_onboarding_artifacts_and_milestones.md`)
- **WP2.3** - Product activity and first-value instrumentation (`execution-packets/phase-2/wp2-3_product_activity_and_first_value_instrumentation.md`)
- **WP2.4** - Explainable health engine (`execution-packets/phase-2/wp2-4_explainable_health_engine.md`)
- **WP2.5** - Support queue and triage (`execution-packets/phase-2/wp2-5_support_queue_and_triage.md`)
- **WP2.6** - Outcome, consent, testimonial, and referral workflows (`execution-packets/phase-2/wp2-6_outcome_consent_testimonial_and_referral_workflows.md`)
- **WP2.7** - Weekly editorial-cycle model (`execution-packets/phase-2/wp2-7_weekly_editorial_cycle_model.md`)
- **WP2.8** - LinkedIn and Substack agents and workspaces (`execution-packets/phase-2/wp2-8_linkedin_and_substack_agents_and_workspaces.md`)
- **WP2.9** - Engagement intelligence and question clustering (`execution-packets/phase-2/wp2-9_engagement_intelligence_and_question_clustering.md`)
- **WP2.10** - Metrics, evaluation, and activation (`execution-packets/phase-2/wp2-10_metrics_evaluation_and_activation.md`)
- **WP3.0** - Phase 2 signal and outcome handoff (`execution-packets/phase-3/wp3-0_phase_2_signal_and_outcome_handoff.md`)
- **WP3.1** - Signal and cluster registry (`execution-packets/phase-3/wp3-1_signal_and_cluster_registry.md`)
- **WP3.2** - Change proposals and decisions (`execution-packets/phase-3/wp3-2_change_proposals_and_decisions.md`)
- **WP3.3** - Specification artifacts and canonical requirements (`execution-packets/phase-3/wp3-3_specification_artifacts_and_canonical_requirements.md`)
- **WP3.4** - Synthetic personas and test registry (`execution-packets/phase-3/wp3-4_synthetic_personas_and_test_registry.md`)
- **WP3.5** - Test execution and evidence (`execution-packets/phase-3/wp3-5_test_execution_and_evidence.md`)
- **WP3.6** - Security, memory, and injection suites (`execution-packets/phase-3/wp3-6_security_memory_and_injection_suites.md`)
- **WP3.7** - Defects and regression investigation (`execution-packets/phase-3/wp3-7_defects_and_regression_investigation.md`)
- **WP3.8** - Release candidates and readiness (`execution-packets/phase-3/wp3-8_release_candidates_and_readiness.md`)
- **WP3.9** - Claim impact and revalidation (`execution-packets/phase-3/wp3-9_claim_impact_and_revalidation.md`)
- **WP3.10** - Release communications and customer proof (`execution-packets/phase-3/wp3-10_release_communications_and_customer_proof.md`)
- **WP3.11** - Product, QA, and Release Notion workspaces (`execution-packets/phase-3/wp3-11_product_qa_and_release_notion_workspaces.md`)
- **WP4.0** - Phase 1-3 source and attribution migration (`execution-packets/phase-4/wp4-0_phase_1_3_source_and_attribution_migration.md`)
- **WP4.1** - Source brief and evidence eligibility (`execution-packets/phase-4/wp4-1_source_brief_and_evidence_eligibility.md`)
- **WP4.2** - Positioning and campaign planning (`execution-packets/phase-4/wp4-2_positioning_and_campaign_planning.md`)
- **WP4.3** - LinkedIn production and carousel workflow (`execution-packets/phase-4/wp4-3_linkedin_production_and_carousel_workflow.md`)
- **WP4.4** - Substack research and publishing workflow (`execution-packets/phase-4/wp4-4_substack_research_and_publishing_workflow.md`)
- **WP4.5** - Email, webinar, landing page, and release packages (`execution-packets/phase-4/wp4-5_email_webinar_landing_page_and_release_packages.md`)
- **WP4.6** - Multi-channel repurposing (`execution-packets/phase-4/wp4-6_multi_channel_repurposing.md`)
- **WP4.7** - Claims, consent, and pricing verification (`execution-packets/phase-4/wp4-7_claims_consent_and_pricing_verification.md`)
- **WP4.8** - Platform draft adapters and publication records (`execution-packets/phase-4/wp4-8_platform_draft_adapters_and_publication_records.md`)
- **WP4.9** - Performance ingestion and attribution (`execution-packets/phase-4/wp4-9_performance_ingestion_and_attribution.md`)
- **WP4.10** - Founder voice learning and experiments (`execution-packets/phase-4/wp4-10_founder_voice_learning_and_experiments.md`)
- **WP4.11** - Communications Calendar and Campaign Center (`execution-packets/phase-4/wp4-11_communications_calendar_and_campaign_center.md`)
- **WP5.0** - Competitor taxonomy and approved-source policy (`execution-packets/phase-5/wp5-0_competitor_taxonomy_and_approved_source_policy.md`)
- **WP5.1** - Competitor, offering, and source registry (`execution-packets/phase-5/wp5-1_competitor_offering_and_source_registry.md`)
- **WP5.2** - Retrieval, hashing, and snapshots (`execution-packets/phase-5/wp5-2_retrieval_hashing_and_snapshots.md`)
- **WP5.3** - Observation extraction and verification (`execution-packets/phase-5/wp5-3_observation_extraction_and_verification.md`)
- **WP5.4** - Material change detection (`execution-packets/phase-5/wp5-4_material_change_detection.md`)
- **WP5.5** - Pricing and offer intelligence (`execution-packets/phase-5/wp5-5_pricing_and_offer_intelligence.md`)
- **WP5.6** - Job-based comparison (`execution-packets/phase-5/wp5-6_job_based_comparison.md`)
- **WP5.7** - Strategic alerts and market briefs (`execution-packets/phase-5/wp5-7_strategic_alerts_and_market_briefs.md`)
- **WP5.8** - Notion intelligence workspace and decision commands (`execution-packets/phase-5/wp5-8_notion_intelligence_workspace_and_decision_commands.md`)
- **WP5.9** - Evaluation, freshness, and noise tuning (`execution-packets/phase-5/wp5-9_evaluation_freshness_and_noise_tuning.md`)
- **WP6.0** - Cross-phase data quality and metric readiness audit (`execution-packets/phase-6/wp6-0_cross_phase_data_quality_and_metric_readiness_audit.md`)
- **WP6.1** - Strategic priority registry (`execution-packets/phase-6/wp6-1_strategic_priority_registry.md`)
- **WP6.2** - Unified canonical decision queue (`execution-packets/phase-6/wp6-2_unified_canonical_decision_queue.md`)
- **WP6.3** - Notion Founder Command Center (`execution-packets/phase-6/wp6-3_notion_founder_command_center.md`)
- **WP6.4** - Cross-domain conflict detection (`execution-packets/phase-6/wp6-4_cross_domain_conflict_detection.md`)
- **WP6.5** - Daily founder brief (`execution-packets/phase-6/wp6-5_daily_founder_brief.md`)
- **WP6.6** - Weekly and monthly operating reviews (`execution-packets/phase-6/wp6-6_weekly_and_monthly_operating_reviews.md`)
- **WP6.7** - Full specification compiler and critic (`execution-packets/phase-6/wp6-7_full_specification_compiler_and_critic.md`)
- **WP6.8** - Automation opportunity detection (`execution-packets/phase-6/wp6-8_automation_opportunity_detection.md`)
- **WP6.9** - Autonomy governance and rollback (`execution-packets/phase-6/wp6-9_autonomy_governance_and_rollback.md`)
- **WP6.10** - Evaluation, tuning, and native-UI decision gate (`execution-packets/phase-6/wp6-10_evaluation_tuning_and_native_ui_decision_gate.md`)
