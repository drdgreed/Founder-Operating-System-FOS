---
title: "Founder Operating System"
subtitle: "Sub-Agent Execution and Verification Pack"
author: "Implementation Handoff"
date: "2026-07-14"
toc: true
---

# Purpose

This pack converts the revised Founder Operating System Phase 0-6 specifications into bounded sub-agent work orders, frozen shared contracts, test and evaluation controls, outcome measurements, and orchestrator engineering practices.

**Package scope:** 78 work packages, 468 execution requirements, 390 packet tests, 29 golden fixtures, and one execution packet per work package.

**Repository-specific gate:** Complete the architecture overlay before leasing implementation packets.

# Executive Readiness and Assumptions

## Decision

The revised FOS specifications are sufficiently detailed for a lead architecture agent. Safe parallel implementation requires the execution, contract, fixture, and verification controls in this package.

## Readiness model

- **Product intent and phase scope:** Ready. No remaining work unless the founder changes priorities.
- **Domain and governance contracts:** Ready for freeze. Map them to existing entities and migrations.
- **Agent behavior and evaluation:** Ready for implementation. Select model providers and repository adapters.
- **Testing strategy:** Ready for harness implementation. Bind it to the actual test framework and services.
- **Parallel sub-agent work:** Ready after architecture freeze. Assign file ownership and worktree paths.
- **Deployment:** Conditionally ready. Bind the controls to actual environments and the release pipeline.

## Assumptions

- FOS remains the canonical source of truth.
- Notion is a founder-facing projection and controlled-command surface.
- Existing repository authentication, tenancy, ORM, model gateway, queues, telemetry, and deployment conventions are reused.
- Agents do not autonomously publish, send, deploy, purchase, change pricing, or waive critical gates.
- Deterministic services enforce state, permissions, consent, claims, approvals, and idempotency.
- Every work package is implemented behind feature flags and can be rolled back or disabled.
- Each implementation agent has an independent reviewer or verification agent.

## Mandatory pre-code gate

No feature sub-agent may begin implementation until the lead architecture agent publishes the repository architecture map, canonical entity reuse decision, package and file ownership map, migration strategy, shared contract versions, test commands, secret policy, and integration branch order.

## Completion standard

A work package is complete only when code, migrations, automated tests, telemetry, documentation, rollback instructions, traceability entries, and founder-visible acceptance evidence are present.


---

# Orchestrator Engineering Guide

## Purpose

The orchestrator coordinates specialized sub-agents while preventing architecture drift, duplicated infrastructure, unsafe autonomy, merge chaos, and unverifiable completion.

## Core principles

### Contract first

Freeze shared schemas, API envelopes, events, error semantics, feature flags, and ownership before parallel implementation. A sub-agent may propose a contract change but may not silently make one.

### Single writer for shared primitives

Only the designated foundation agent may modify shared identity, workspace, artifact, approval, event, consent, claims, agent-run, and workspace-integration primitives. Other agents consume those contracts.

### Bounded work orders

Every sub-agent receives one execution packet with explicit dependencies, allowed modules, prohibited changes, tests, outputs, and completion evidence.

### Independent verification

The implementation agent must not be the sole reviewer of its own work. Use a separate review agent for security-sensitive, schema, migration, event, agent-evaluation, and release changes.

### Small integration increments

Prefer narrow pull requests that deliver one vertical slice. Avoid phase-sized branches. Integrate contracts and scaffolding before feature breadth.

### Evidence over status claims

Agents may not report “done” without test output, diff summary, migration result, traceability update, and reproducible commands.

## Orchestrator state machine

1. `drafted` - packet exists but dependencies or contracts are unresolved.
2. `ready` - dependencies are accepted and required contracts are frozen.
3. `leased` - one agent owns the packet and affected modules for a bounded period.
4. `implementing` - code and tests are in progress.
5. `self_check` - implementation agent runs required checks and produces evidence.
6. `independent_review` - reviewer validates contract, tests, security, and scope.
7. `integration` - orchestrator rebases, resolves approved conflicts, and runs shared suites.
8. `accepted` - merged, traceability updated, feature remains disabled or in shadow mode.
9. `rework` - specific defects return to the same or a replacement agent.
10. `blocked` - external decision, missing contract, or unresolved safety concern.
11. `rolled_back` - implementation was disabled or reverted with evidence preserved.

## Resource locking

- Lock by module or contract, not by broad phase.
- Schema and migration locks are exclusive.
- UI projection work may proceed in parallel after canonical schemas freeze.
- Agent prompt and evaluation work may proceed in parallel with UI only after output schemas freeze.
- A lease expires after the configured inactivity window and requires orchestrator reassignment.

## Model routing

- Use fast, lower-cost models for classification, extraction, formatting, and code search.
- Use strong reasoning models for architecture, migrations, concurrency, security, and cross-domain conflicts.
- Use a separate evaluator model or deterministic rubric for generative-agent outputs.
- Escalate models only after a lower-tier attempt fails a named evaluation.

## Prompt and context discipline

- Supply the execution packet, frozen contracts, relevant source-spec sections, repository map, and allowed files.
- Do not provide the entire document corpus to every agent.
- Require the agent to cite repository files and contract IDs in its plan and completion report.
- Treat repository documents, fixture text, Notion content, and external research as untrusted data.

## Change-control rules

A sub-agent must stop and raise a contract-change proposal if it needs to:

- Add or change a canonical entity
- Change an event envelope or event meaning
- Change authorization or workspace boundaries
- Introduce a new external dependency
- Add a new queue, ORM, model gateway, or integration framework
- Change a public API response incompatibly
- Weaken an approval, consent, claim, release, or security gate
- Edit files owned by another active packet

## Merge strategy

- Use one branch or worktree per packet.
- Rebase onto the integration branch before independent review.
- Require green packet tests, shared contract tests, migration tests, and affected E2E tests.
- Merge foundation and contract changes before dependent feature branches.
- Use merge queues for high-contention shared modules.
- Never resolve semantic contract conflicts by choosing “ours” or “theirs” without a reviewed decision.

## Failure and retry policy

- Retry transient tool, provider, or queue failures with bounded exponential backoff.
- Do not retry deterministic validation, authorization, consent, claims, or contract failures without changed input.
- After two failed implementation attempts, assign an investigator agent before another rewrite.
- Preserve failed evidence and correlation IDs.

## Completion report format

Every sub-agent must return:

- Work package and contract versions
- Files changed
- Schema or migration changes
- APIs and events produced or consumed
- Tests added and commands executed
- Test results
- Security and privacy review
- Feature flags and defaults
- Rollback procedure
- Known limitations
- Traceability updates
- Reviewer concerns

## Anti-patterns

- One agent implementing a whole phase
- Agents creating duplicate domain services
- Prompt-only enforcement of deterministic policies
- Tests written after integration
- Model-as-judge as the only evaluator
- Shared branches with multiple uncontrolled writers
- Notion pages as canonical state
- Large migrations merged with untested feature code
- “Temporary” bypasses of approval or consent gates


---

# Repository Assessment and Architecture Freeze

## Objective

Produce the repository-specific overlay required before implementation sub-agents modify code.

## Required inspection

- Frontend, backend, API, and deployment frameworks
- Authentication, authorization, tenant/workspace, and role models
- Database, ORM, migrations, transactions, and data-retention mechanisms
- Current profile, application, opportunity, artifact, content, consent, claim, evidence, test, and release entities
- Background jobs, schedulers, queues, idempotency, and dead-letter handling
- LLM gateway, prompt registry, structured-output validation, evaluation, and cost tracking
- Email, calendar, Notion, GitHub, analytics, storage, and publication integrations
- Logging, metrics, traces, error reporting, security scanning, and feature flags
- Unit, integration, E2E, contract, and load-test frameworks

## Deliverables

### Architecture map

List each relevant repository module, responsibility, owner, dependencies, and whether it is reused, extended, migrated, deprecated, or replaced.

### Entity reuse matrix

For each canonical FOS entity, identify the existing entity or migration decision. Duplicate person, workspace, artifact, approval, event, consent, claim, and agent-run systems are prohibited without an architecture decision record.

### File ownership map

Assign one primary owner to shared modules. Work packets receive allowlists and denylists based on this map.

### Contract freeze manifest

Record versions and locations for:

- API envelope
- Error envelope
- Event envelope
- Artifact and version schema
- Approval and command schema
- Agent-run and output schema
- Workspace projection schema
- Test and evaluation schemas

### Command registry

Record actual commands for install, lint, type-check, migrate, seed, unit test, integration test, E2E test, security test, build, and deploy.

## Architecture decision record template

```text
ADR ID:
Title:
Status:
Context:
Decision:
Alternatives:
Consequences:
Migration:
Rollback:
Affected contracts:
Approvers:
```

## Exit gate

No feature packet enters `ready` until the architecture map, file ownership map, and contract freeze manifest have been approved by the lead architecture and security reviewers.


---

# Cross-Phase Dependency Summary

- **Phase 0 foundation:** Requires the repository architecture freeze and shared contracts. Nothing runs before the contract freeze.
- **Phase 1 revenue:** Begins after Phase 0 acceptance. Limited Phase 5 taxonomy design may proceed separately.
- **Phase 2 beta operations:** Begins after the Phase 1 enrollment handoff. Phase 1 optimization may continue in parallel.
- **Phase 3 product quality:** Begins after Phase 2 signal and outcome handoff. Late Phase 2 editorial operations may continue.
- **Phase 4 marketing scale:** Requires accepted evidence and attribution from Phases 1-3. Phase 5 monitoring may run in parallel.
- **Phase 5 market intelligence:** Requires Phase 0 source and workspace contracts. It may overlap late Phases 3-4.
- **Phase 6 founder coordination:** Requires cross-phase data-quality readiness from Phases 1-5. Do not implement early beyond design.

The full machine-readable graph is in `matrices/cross_phase_dependencies.csv`, `orchestrator/work_package_registry.yaml`, and `docs/03_Cross_Phase_Dependency_DAG.md`.


---

# Interface, Event, and Agent Contracts

## Shared API conventions

- Version APIs explicitly or through compatible additive evolution.
- Validate request and response bodies with repository-native typed schemas.
- Use stable machine-readable error codes.
- Require idempotency keys for intake, commands, external drafts, publication records, test execution, and webhooks.
- Use optimistic concurrency for founder-editable and lifecycle records.
- Paginate collection endpoints.
- Enforce authorization server-side.

## Error envelope

```json
{
  "error": {
    "code": "FOS_VERSION_CONFLICT",
    "message": "The record changed after the workspace projection was loaded.",
    "correlation_id": "uuid",
    "retryable": false,
    "details": {}
  }
}
```

## Event envelope

Every event includes:

- `event_id`
- `event_type`
- `schema_version`
- `workspace_id`
- `entity_type`
- `entity_id`
- `occurred_at`
- `actor_type`
- `actor_id`
- `correlation_id`
- `causation_id`
- `idempotency_key`
- `payload`

Events are append-only. Consumers must be idempotent. Breaking event changes require a new schema version.

## Artifact contract

Artifacts separate identity from immutable versions. Working-copy edits create new versions after validation. Approval targets a specific version. Published or executed artifacts retain a final snapshot.

## Workspace command contract

Notion and future workspace providers never directly change protected state. A workspace action creates a command that is authenticated, deduplicated, version-checked, policy-checked, executed through domain services, audited, and projected back.

## Agent contract

Each agent definition includes:

- Stable key and version
- Bounded objective
- Trigger and input schema
- Allowed context scopes
- Allowed tools
- Prohibited actions
- Structured output schema
- Required evidence
- Deterministic validation
- Evaluation rubric
- Escalation rules
- Maximum autonomy
- Timeout and cost limits

## Compatibility rules

- Additive fields default safely.
- Removing or changing meaning requires migration and dual-read or dual-write where needed.
- Prompts and model changes are versioned independently of output schemas.
- Agent output schema changes require evaluation-set reruns.


---

# Canonical Schema and Migration Plan

## Migration principles

- Reuse existing identity, user, and workspace records when stable identifiers exist.
- Introduce generic `ArtifactRecord` and `ArtifactVersion` primitives before phase-specific document workflows.
- Keep raw source events immutable and summaries versioned.
- Use forward-only migrations in production unless the repository has a tested rollback mechanism.
- Separate schema migration, data backfill, and feature activation.
- Make backfills restartable, idempotent, observable, and bounded.

## Migration stages

1. Inventory and compatibility analysis
2. Additive schema creation
3. Dual-read or compatibility adapters
4. Idempotent data backfill
5. Data-quality verification
6. Shadow reads and comparison
7. Canonical cutover
8. Legacy write disablement
9. Cleanup after retention window

## Required migration tests

- Empty database migration
- Production-like snapshot migration
- Restart after partial backfill
- Duplicate and malformed legacy records
- Workspace-isolation validation
- Referential integrity
- Version and timestamp preservation
- Rollback or forward-fix rehearsal

## Data-quality checks

- Orphaned foreign keys
- Duplicate canonical identities
- Missing workspace IDs
- Invalid consent or claim states
- Artifact versions without records
- Approval targets without immutable snapshots
- Events without correlation IDs
- Notion projections without canonical links

## Schema ownership

Only the foundation schema owner may merge changes to shared canonical primitives. Phase agents may add phase-owned tables after contract review.


---

# Notion Founder Workspace Adapter Contract

## Architectural role

Notion is a human-editable projection, planning, and command surface. FOS owns canonical state, authorization, evidence, claims, consent, agent runs, metrics, and audit.

## Field ownership classes

- `canonical_read_only` - shown in Notion; changed only by FOS.
- `working_copy_editable` - founder may edit prose or notes; changes become versioned artifacts.
- `controlled_command` - a property or button creates a validated command.
- `not_projectable` - secrets, private raw data, full traces, and sensitive evidence.

## Required hidden properties

- FOS Record ID
- FOS Entity Type
- FOS Version
- FOS Workspace ID
- Projection Version
- Last Synced At

## Synchronization flow

FOS events create or update projections. Notion webhooks create deduplicated `WorkspaceCommand` records. The command service validates identity, current version, consent, claims, authorization, and action policy before calling domain services.

## Conflict behavior

If projected and canonical versions differ, do not overwrite. Create a conflict record, preserve both snapshots, and require resolution.

## Rate-limit and resilience behavior

- Queue provider operations.
- Use exponential backoff for retryable provider errors.
- Reconcile periodically using hashes and version stamps.
- Keep FOS fully operational while Notion is unavailable.
- Mark projections out of sync after retry exhaustion.

## Security

- Use minimum integration scopes.
- Store credentials in secret management.
- Do not project raw prompts, secrets, payment data, unrestricted transcripts, or exploitable security details.
- Revalidate claims and consent after founder edits.


---

# Shared Test Harness and Integration Suite

## Objective

Provide one reusable harness so feature agents do not invent incompatible mocks, clocks, provider adapters, identity fixtures, or event assertions.

## Required harness components

- Ephemeral relational database and migration runner
- Transaction and cleanup helpers
- Stable fixture loader
- Fake clock and timezone control
- Queue and scheduler test adapter
- Deterministic model stub and recorded-output mode
- Fake Notion provider and webhook simulator
- Fake email, calendar, GitHub, object-storage, analytics, and publication adapters
- Identity, role, and workspace fixtures
- Event collector and correlation assertions
- Cost, latency, and telemetry collector
- Failure injection for timeouts, duplicates, stale versions, partial writes, and provider outages

## Test layers

### Unit

Pure validation, state machines, calculations, policies, mappers, and evaluators.

### Contract

Request/response schemas, event schemas, provider adapter behavior, structured agent output, and migration compatibility.

### Integration

Database, domain service, event, queue, provider adapter, claims, consent, approval, and audit interactions.

### Agent evaluation

Grounding, completeness, policy, privacy, product consistency, escalation, and founder usefulness.

### End-to-end

Founder-visible workflows across UI or workspace, canonical services, agents, approvals, adapters, and metrics.

### Security and resilience

Workspace isolation, prompt injection, malicious documents, stale claims, revoked consent, replayed webhooks, privilege escalation, timeout, retry, and rollback.

## Mandatory cross-system scenarios

1. Application -> person -> opportunity -> enrollment brief -> approval.
2. Founder edit in Notion -> command -> version check -> claims revalidation -> canonical artifact.
3. Approval -> downstream email or platform draft; no autonomous send.
4. Enrollment -> onboarding -> first value -> outcome evidence.
5. Support case -> triage -> product signal -> change proposal.
6. Specification -> requirements -> tests -> release candidate.
7. Release -> capability update -> claim-impact scan.
8. Evidence -> LinkedIn/Substack asset -> approval -> publication record.
9. Consent revocation -> pending and future public-use assets blocked.
10. Competitor change -> observation -> strategic alert.
11. Cross-domain conflict -> Founder Inbox -> resolution.
12. Provider failure -> retry -> dead letter -> reconciliation.

## Determinism

Agent tests use fixed fixtures, frozen model outputs or deterministic stubs, and explicit evaluator versions. Live-model smoke tests are separate and non-blocking until calibrated.


---

# Fixture and Golden Dataset Catalog

## Rules

- Fixtures use fictional people and organizations.
- Stable fixture IDs never change meaning.
- Sensitive traits are excluded unless needed for an explicit safety test.
- One fixture may be reused across unit, integration, E2E, and agent-evaluation tests.
- Expected outcomes are versioned.

## Domains

### Enrollment

Strong fit, ambiguous fit, incomplete application, contradictory history, price objection, time objection, unresponsive lead, revoked consent, prompt injection, and out-of-scope request.

### Beta operations

Healthy active user, scheduled pause, product-defect block, onboarding confusion, first-value achievement, withdrawal, referral readiness, and unverified outcome.

### Product and QA

Repeated product signal, memory leak, malformed output, tool timeout, duplicate event, version conflict, regression, and release rollback.

### Marketing

Approved release, named consent, anonymous consent, no consent, expired claim, planned capability, comparative claim, long-form paper, and derivative adding an unsupported claim.

### Market intelligence

Verified pricing change, unchanged page, removed feature, company claim, low-confidence rumor, and malicious source instruction.

The concrete JSON fixtures are under `fixtures/` and referenced by the machine-readable test catalogs.


---

# Agent Evaluation Framework

## Evaluation dimensions

- **Grounding:** Factual statements must resolve to allowed evidence. Use deterministic source resolution plus an evaluator.
- **Completeness:** Required fields and material risks must be present. Use schema validation and a rubric.
- **Policy:** Approvals, consent, claims, and autonomy boundaries must be followed. Use deterministic checks.
- **Privacy:** Unrelated and sensitive information must be excluded. Use rule-based and adversarial tests.
- **Product consistency:** Outputs must match current capabilities, offers, releases, and strategy. Use canonical lookups.
- **Usefulness:** Outputs should reduce founder work and support a sound decision. Use sampled founder scoring.
- **Stability:** Behavior must remain acceptable across model and prompt changes. Use regression cases.
- **Efficiency:** Cost and latency must be proportionate to business value. Use telemetry.

## Scoring

Use a 100-point rubric with hard gates: Grounding 25, Completeness 15, Policy 20, Privacy 15, Product consistency 10, Usefulness 10, and Efficiency 5. A high overall score cannot compensate for authorization, consent, unsupported-claim, cross-user-leak, or unauthorized-action failures.

## Evaluation release gate

All hard-gate cases pass; the mean score meets the agent threshold; no material regression exists; the founder reviews a calibrated sample; and prompt, model, tools, schema, and evaluator versions are recorded.

## Live monitoring

Sample accepted outputs, founder edits, rejections, failures, and outcome effectiveness. Do not update durable founder preferences from a single edit.


---

# Business Outcome Measurement Contracts

## Phase 0

- **FOS foundation readiness:** percentage of mandatory shared contracts passing validation. Initial target: 100%.
- **Workspace sync reliability:** successful projection and command operations. Initial target: >=99%.
- **Canonical ownership compliance:** protected fields updated only through FOS commands. Initial target: 100%.
- **Audit completeness:** consequential actions with complete event lineage. Initial target: 100%.

## Phase 1

- **Lead-to-enrollment conversion:** enrolled opportunities divided by qualified leads. Initial target: baseline + measurable uplift.
- **Median first response time:** application received to approved first response. Initial target: <1 business day.
- **Founder time per qualified lead:** measured preparation and follow-up minutes. Initial target: >=50% reduction.
- **Launch-assisted enrollments:** enrollments with attributable campaign touches. Initial target: reported with confidence.

## Phase 2

- **Onboarding completion:** active beta users completing required onboarding. Initial target: >=80%.
- **Time to first value:** activation to verified first-value milestone. Initial target: decreasing by cohort.
- **At-risk recovery:** at-risk users returning to healthy/watch. Initial target: tracked.
- **Founder support time:** founder minutes per active beta user. Initial target: >=50% reduction.
- **Editorial cadence:** approved LinkedIn and Substack assets per cycle. Initial target: meets configured cadence.

## Phase 3

- **Requirement-to-test coverage:** approved requirements with linked automated tests. Initial target: >=90%.
- **Defect escape rate:** production defects not detected pre-release. Initial target: decreasing.
- **Release evidence completeness:** release candidates with full readiness dossier. Initial target: 100%.
- **Critical isolation failures:** cross-user memory leaks. Initial target: 0.
- **Signal-to-decision time:** validated signal cluster to founder decision. Initial target: decreasing.

## Phase 4

- **Content production time:** founder minutes per approved asset. Initial target: >=50% reduction.
- **Qualified demand:** qualified leads generated by content. Initial target: increasing.
- **Content-assisted enrollment:** attributed assisted conversions. Initial target: reported by model.
- **Unsupported claim rate:** published assets with unsupported claims. Initial target: 0.
- **Repurposing leverage:** approved derivatives per source asset. Initial target: >=3.

## Phase 5

- **Material alert precision:** alerts accepted as decision-relevant. Initial target: target >=70%.
- **Pricing freshness:** active competitor price observations within policy window. Initial target: >=90%.
- **Duplicate alert rate:** duplicate or unchanged alerts. Initial target: <5%.
- **Founder research time:** hours spent on routine monitoring. Initial target: decreasing.

## Phase 6

- **Founder decision time:** median time from surfaced decision to disposition. Initial target: decreasing.
- **Unresolved critical items:** critical items beyond SLA. Initial target: 0.
- **Recommendation acceptance:** accepted or accepted-with-edit recommendations. Initial target: increasing.
- **Founder hours saved:** measured against documented baselines. Initial target: target 8-14 hours/week.
- **Conflict prevention:** conflicts resolved before external impact. Initial target: tracked.

## Measurement rules

Every metric names its source events, calculation, timezone, attribution window, exclusions, owner, and data-quality check. Founder-time savings require a documented baseline. Content attribution reports first-touch, last-touch, and assisted models separately. User outcomes distinguish observation, self-report, verified evidence, and causal inference. Targets are configuration, not hard-coded logic.


---

# CI/CD, Merge, and Release Gates

## Pull-request gates

- Formatting and lint
- Type checking
- Unit tests
- Changed contract validation
- Changed migration validation
- Packet-specific integration tests
- Secret and dependency scanning
- Traceability entry present

## Merge gates

- Independent reviewer approval
- Shared contract suite
- Workspace-isolation suite for affected data paths
- Claims and consent suite for external-content paths
- Event and audit assertions
- Feature flag defaults safe
- Migration compatibility and restart test

## Release gates

- Affected E2E journeys
- Agent evaluation regression
- Prompt-injection and malicious-source suite
- Memory-isolation suite
- Performance and cost budgets
- Release-readiness report
- Rollback rehearsal
- Founder approval for consequential activation

## Branching

Use short-lived packet branches or worktrees and an integration branch. Protect shared primitives with code owners. Use a merge queue for migration, event, agent-runtime, and workspace-adapter modules.

## Feature activation

Progress through disabled, test, shadow, founder-only, limited cohort, and full activation. Publishing, sending, deployment, pricing, and autonomy increases require separate approvals.


---

# Security, Red-Team, and Resilience Plan

## Threat classes

- Cross-workspace and cross-user data leakage
- Prompt injection in applications, resumes, support messages, Notion pages, webpages, and tool output
- Unauthorized command or webhook replay
- Privilege escalation
- Consent or claims bypass
- Stale version overwrite
- External action without approval
- Secret leakage in prompts, logs, or projections
- Malicious file or URL processing
- Model hallucination presented as evidence
- Supply-chain and dependency compromise
- Queue duplication, partial workflow, and retry storms

## Required controls

- Least privilege and server-side authorization
- Provider webhook verification and idempotency
- Context minimization and source manifests
- Untrusted-content delimiters and tool allowlists
- Deterministic consent, claims, price, release, and approval gates
- Encrypted secrets and sensitive fields
- Structured logs without raw private content
- Rate limits and cost ceilings
- Dead-letter queues and reconciliation
- Immutable audit and versioned artifacts

## Release-blocking tests

Any confirmed cross-user leak, unauthorized external action, consent bypass, critical injection exploit, or inability to reconstruct a consequential action blocks release.


---

# Sub-Agent Team Topology and RACI

## Teams

### Foundation

Architecture and contracts, database and migration, workspace integration, security and authorization.

### Enrollment

Opportunity workflow, enrollment intelligence, launch communications, enrollment verification.

### Beta operations

Onboarding and milestones, health and intervention, support and outcomes, editorial cadence.

### Product quality

Signals and specifications, test platform, red team, regression and release readiness.

### Communications

Evidence and positioning, LinkedIn and repurposing, Substack and research, claims and attribution.

### Market and founder operations

Market intelligence, conflict detection, chief of staff, operating reviews, autonomy governance.

## RACI rule

- One Responsible implementation agent per packet.
- One Accountable orchestrator or lead per phase gate.
- At least one Consulted domain or security reviewer for shared-contract changes.
- Founder is Informed for reversible internal changes and Accountable for strategic, public, pricing, deployment, and autonomy decisions.

## Reviewer independence

The reviewer should use the packet, contracts, diff, and test evidence, not the implementation agent's narrative alone.


---

# Execution Packet Standard

Every packet includes:

1. Objective and business value
2. Scope and explicit non-scope
3. Dependencies and contract versions
4. Inputs and fixtures
5. Deliverables
6. Interfaces consumed and produced
7. Allowed and prohibited changes
8. Functional requirements
9. Security, privacy, and governance constraints
10. Required tests and gates
11. Observability and cost requirements
12. Migration and rollout
13. Definition of done
14. Completion evidence
15. Independent-review checklist
16. Escalation conditions

## Repository overlay

Before leasing a packet, the orchestrator adds:

- Assigned agent and reviewer
- Branch or worktree
- Allowed file globs
- Prohibited file globs
- Actual commands
- Environment and fixture set
- Contract commit hashes
- Lease expiration

## Scope discipline

A packet agent may make necessary local implementation choices but may not change cross-packet contracts, security posture, or architecture without an approved change proposal.


---

# Implementation Sequence and Release Trains

## Release Train A - Foundation

WP0A through WP0.10. Exit requires canonical contracts, workspace adapter, test harness, CI gates, and founder-only shadow operation.

## Release Train B - Revenue

WP1.0 through WP1.10. Exit requires enrollment and launch communication workflows in shadow mode, then controlled founder use.

## Release Train C - Beta operations

WP2.0 through WP2.10. Exit requires onboarding, first value, support, outcomes, and editorial cadence.

## Release Train D - Product quality

WP3.0 through WP3.11. Exit requires signal-to-release traceability, security suites, and release readiness.

## Release Train E - Marketing scale

WP4.0 through WP4.11. Exit requires evidence-driven multi-channel campaigns and reliable attribution.

## Release Train F - Market intelligence

WP5.0 through WP5.9. May overlap late Release Train E after Phase 0 contracts are stable.

## Release Train G - Founder coordination

WP6.0 through WP6.10. Begins only after operational data-quality readiness. Native UI remains deferred until measured Notion limitations justify it.


---

# Work Package and Test Registry

## Phase 0

- **WP0A - Compatibility refactor and architecture contracts**. Dependencies: none. Risk: medium. Team: foundation.
- **WP0.1 - Canonical schema and migrations**. Dependencies: WP0A. Risk: critical. Team: foundation.
- **WP0.2 - Domain services and event system**. Dependencies: WP0.1. Risk: critical. Team: foundation.
- **WP0.3 - Workspace provider interface and Notion adapter**. Dependencies: WP0A;WP0.2. Risk: medium. Team: foundation.
- **WP0.4 - Collection bootstrap and mappings**. Dependencies: WP0.3. Risk: medium. Team: foundation.
- **WP0.5 - Read-only projections**. Dependencies: WP0.2;WP0.4. Risk: medium. Team: foundation.
- **WP0.6 - Webhooks, edit capture, and controlled commands**. Dependencies: WP0.2;WP0.5. Risk: high. Team: foundation.
- **WP0.7 - Approval bridge and action boundaries**. Dependencies: WP0.2;WP0.6. Risk: critical. Team: foundation.
- **WP0.8 - Communications and campaign foundation**. Dependencies: WP0.1;WP0.2;WP0.7. Risk: medium. Team: foundation.
- **WP0.9 - Integration health, reconciliation, and metrics**. Dependencies: WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8. Risk: high. Team: foundation.
- **WP0.10 - Test suite, deployment, and handoff**. Dependencies: WP0.1;WP0.2;WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8;WP0.9. Risk: medium. Team: foundation.

## Phase 1

- **WP1.0 - Phase 0 contract verification and migration**. Dependencies: WP0.10. Risk: critical. Team: enrollment.
- **WP1.1 - Opportunity and attribution extensions**. Dependencies: WP1.0. Risk: high. Team: enrollment.
- **WP1.2 - Enrollment agent runtime and assessments**. Dependencies: WP1.0;WP1.1. Risk: high. Team: enrollment.
- **WP1.3 - Call and post-call workflows**. Dependencies: WP1.2. Risk: medium. Team: enrollment.
- **WP1.4 - Follow-up, objections, and next actions**. Dependencies: WP1.2;WP1.3. Risk: medium. Team: enrollment.
- **WP1.5 - Enrollment Pipeline and Founder Inbox projections**. Dependencies: WP1.1;WP1.4. Risk: medium. Team: enrollment.
- **WP1.6 - Beta launch campaign model and source brief**. Dependencies: WP1.0;WP0.8. Risk: medium. Team: enrollment.
- **WP1.7 - LinkedIn, Substack, email, webinar, and landing-page artifacts**. Dependencies: WP1.6. Risk: medium. Team: enrollment.
- **WP1.8 - Claims, consent, and platform-draft gates**. Dependencies: WP1.7;WP0.7;WP0.8. Risk: critical. Team: enrollment.
- **WP1.9 - Funnel, campaign attribution, founder-time dashboards**. Dependencies: WP1.1;WP1.5;WP1.6;WP1.7. Risk: high. Team: enrollment.
- **WP1.10 - Evaluation, shadow mode, and production activation**. Dependencies: WP1.2;WP1.3;WP1.4;WP1.5;WP1.6;WP1.7;WP1.8;WP1.9. Risk: medium. Team: enrollment.

## Phase 2

- **WP2.0 - Phase 1 enrollment-to-beta handoff**. Dependencies: WP1.10. Risk: medium. Team: beta_operations.
- **WP2.1 - Beta domain schema and migration**. Dependencies: WP2.0. Risk: critical. Team: beta_operations.
- **WP2.2 - Onboarding artifacts and milestones**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.3 - Product activity and first-value instrumentation**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.4 - Explainable health engine**. Dependencies: WP2.3. Risk: high. Team: beta_operations.
- **WP2.5 - Support queue and triage**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.6 - Outcome, consent, testimonial, and referral workflows**. Dependencies: WP2.2;WP2.5. Risk: critical. Team: beta_operations.
- **WP2.7 - Weekly editorial-cycle model**. Dependencies: WP2.0;WP0.8. Risk: medium. Team: beta_operations.
- **WP2.8 - LinkedIn and Substack agents and workspaces**. Dependencies: WP2.7. Risk: high. Team: beta_operations.
- **WP2.9 - Engagement intelligence and question clustering**. Dependencies: WP2.8. Risk: medium. Team: beta_operations.
- **WP2.10 - Metrics, evaluation, and activation**. Dependencies: WP2.2;WP2.3;WP2.4;WP2.5;WP2.6;WP2.7;WP2.8;WP2.9. Risk: medium. Team: beta_operations.

## Phase 3

- **WP3.0 - Phase 2 signal and outcome handoff**. Dependencies: WP2.10. Risk: medium. Team: product_quality.
- **WP3.1 - Signal and cluster registry**. Dependencies: WP3.0. Risk: medium. Team: product_quality.
- **WP3.2 - Change proposals and decisions**. Dependencies: WP3.1. Risk: medium. Team: product_quality.
- **WP3.3 - Specification artifacts and canonical requirements**. Dependencies: WP3.2. Risk: medium. Team: product_quality.
- **WP3.4 - Synthetic personas and test registry**. Dependencies: WP3.3. Risk: medium. Team: product_quality.
- **WP3.5 - Test execution and evidence**. Dependencies: WP3.4. Risk: medium. Team: product_quality.
- **WP3.6 - Security, memory, and injection suites**. Dependencies: WP3.5. Risk: critical. Team: product_quality.
- **WP3.7 - Defects and regression investigation**. Dependencies: WP3.5;WP3.6. Risk: medium. Team: product_quality.
- **WP3.8 - Release candidates and readiness**. Dependencies: WP3.3;WP3.5;WP3.7. Risk: critical. Team: product_quality.
- **WP3.9 - Claim impact and revalidation**. Dependencies: WP3.8. Risk: medium. Team: product_quality.
- **WP3.10 - Release communications and customer proof**. Dependencies: WP3.8;WP3.9. Risk: critical. Team: product_quality.
- **WP3.11 - Product, QA, and Release Notion workspaces**. Dependencies: WP3.1;WP3.3;WP3.5;WP3.8;WP3.10. Risk: critical. Team: product_quality.

## Phase 4

- **WP4.0 - Phase 1-3 source and attribution migration**. Dependencies: WP1.10;WP2.10;WP3.10. Risk: critical. Team: communications.
- **WP4.1 - Source brief and evidence eligibility**. Dependencies: WP4.0. Risk: medium. Team: communications.
- **WP4.2 - Positioning and campaign planning**. Dependencies: WP4.1. Risk: medium. Team: communications.
- **WP4.3 - LinkedIn production and carousel workflow**. Dependencies: WP4.2. Risk: medium. Team: communications.
- **WP4.4 - Substack research and publishing workflow**. Dependencies: WP4.2. Risk: medium. Team: communications.
- **WP4.5 - Email, webinar, landing page, and release packages**. Dependencies: WP4.2. Risk: critical. Team: communications.
- **WP4.6 - Multi-channel repurposing**. Dependencies: WP4.3;WP4.4;WP4.5. Risk: medium. Team: communications.
- **WP4.7 - Claims, consent, and pricing verification**. Dependencies: WP4.1;WP4.3;WP4.4;WP4.5;WP4.6. Risk: critical. Team: communications.
- **WP4.8 - Platform draft adapters and publication records**. Dependencies: WP4.7. Risk: medium. Team: communications.
- **WP4.9 - Performance ingestion and attribution**. Dependencies: WP4.8. Risk: high. Team: communications.
- **WP4.10 - Founder voice learning and experiments**. Dependencies: WP4.9. Risk: medium. Team: communications.
- **WP4.11 - Communications Calendar and Campaign Center**. Dependencies: WP4.1;WP4.2;WP4.3;WP4.4;WP4.5;WP4.6;WP4.7;WP4.8;WP4.9;WP4.10. Risk: medium. Team: communications.

## Phase 5

- **WP5.0 - Competitor taxonomy and approved-source policy**. Dependencies: WP0.10. Risk: medium. Team: market_intelligence.
- **WP5.1 - Competitor, offering, and source registry**. Dependencies: WP5.0. Risk: medium. Team: market_intelligence.
- **WP5.2 - Retrieval, hashing, and snapshots**. Dependencies: WP5.1. Risk: medium. Team: market_intelligence.
- **WP5.3 - Observation extraction and verification**. Dependencies: WP5.2. Risk: medium. Team: market_intelligence.
- **WP5.4 - Material change detection**. Dependencies: WP5.3. Risk: medium. Team: market_intelligence.
- **WP5.5 - Pricing and offer intelligence**. Dependencies: WP5.3. Risk: high. Team: market_intelligence.
- **WP5.6 - Job-based comparison**. Dependencies: WP5.3;WP5.5. Risk: medium. Team: market_intelligence.
- **WP5.7 - Strategic alerts and market briefs**. Dependencies: WP5.4;WP5.5;WP5.6. Risk: medium. Team: market_intelligence.
- **WP5.8 - Notion intelligence workspace and decision commands**. Dependencies: WP5.7. Risk: high. Team: market_intelligence.
- **WP5.9 - Evaluation, freshness, and noise tuning**. Dependencies: WP5.2;WP5.3;WP5.4;WP5.5;WP5.6;WP5.7;WP5.8. Risk: medium. Team: market_intelligence.

## Phase 6

- **WP6.0 - Cross-phase data quality and metric readiness audit**. Dependencies: WP1.10;WP2.10;WP3.10;WP4.10;WP5.9. Risk: medium. Team: founder_coordination.
- **WP6.1 - Strategic priority registry**. Dependencies: WP6.0. Risk: medium. Team: founder_coordination.
- **WP6.2 - Unified canonical decision queue**. Dependencies: WP6.0;WP6.1. Risk: medium. Team: founder_coordination.
- **WP6.3 - Notion Founder Command Center**. Dependencies: WP6.2. Risk: high. Team: founder_coordination.
- **WP6.4 - Cross-domain conflict detection**. Dependencies: WP6.2. Risk: medium. Team: founder_coordination.
- **WP6.5 - Daily founder brief**. Dependencies: WP6.2;WP6.4. Risk: medium. Team: founder_coordination.
- **WP6.6 - Weekly and monthly operating reviews**. Dependencies: WP6.5. Risk: medium. Team: founder_coordination.
- **WP6.7 - Full specification compiler and critic**. Dependencies: WP3.3;WP6.1. Risk: medium. Team: founder_coordination.
- **WP6.8 - Automation opportunity detection**. Dependencies: WP6.6. Risk: medium. Team: founder_coordination.
- **WP6.9 - Autonomy governance and rollback**. Dependencies: WP6.8. Risk: critical. Team: founder_coordination.
- **WP6.10 - Evaluation, tuning, and native-UI decision gate**. Dependencies: WP6.3;WP6.4;WP6.5;WP6.6;WP6.7;WP6.8;WP6.9. Risk: medium. Team: founder_coordination.

## Verification volume

- 78 work packages
- 468 execution requirements
- 390 packet tests
- 29 golden fixtures

Detailed matrices are provided as CSV files in `matrices/`.


---

# Appendix: Execution Packet Index

- **WP0A** - Compatibility refactor and architecture contracts (`execution-packets/phase-0/wp0a_compatibility_refactor_and_architecture_contracts.md`)
- **WP0.1** - Canonical schema and migrations (`execution-packets/phase-0/wp0-1_canonical_schema_and_migrations.md`)
- **WP0.2** - Domain services and event system (`execution-packets/phase-0/wp0-2_domain_services_and_event_system.md`)
- **WP0.3** - Workspace provider interface and Notion adapter (`execution-packets/phase-0/wp0-3_workspace_provider_interface_and_notion_adapter.md`)
- **WP0.4** - Collection bootstrap and mappings (`execution-packets/phase-0/wp0-4_collection_bootstrap_and_mappings.md`)
- **WP0.5** - Read-only projections (`execution-packets/phase-0/wp0-5_read_only_projections.md`)
- **WP0.6** - Webhooks, edit capture, and controlled commands (`execution-packets/phase-0/wp0-6_webhooks_edit_capture_and_controlled_commands.md`)
- **WP0.7** - Approval bridge and action boundaries (`execution-packets/phase-0/wp0-7_approval_bridge_and_action_boundaries.md`)
- **WP0.8** - Communications and campaign foundation (`execution-packets/phase-0/wp0-8_communications_and_campaign_foundation.md`)
- **WP0.9** - Integration health, reconciliation, and metrics (`execution-packets/phase-0/wp0-9_integration_health_reconciliation_and_metrics.md`)
- **WP0.10** - Test suite, deployment, and handoff (`execution-packets/phase-0/wp0-10_test_suite_deployment_and_handoff.md`)
- **WP1.0** - Phase 0 contract verification and migration (`execution-packets/phase-1/wp1-0_phase_0_contract_verification_and_migration.md`)
- **WP1.1** - Opportunity and attribution extensions (`execution-packets/phase-1/wp1-1_opportunity_and_attribution_extensions.md`)
- **WP1.2** - Enrollment agent runtime and assessments (`execution-packets/phase-1/wp1-2_enrollment_agent_runtime_and_assessments.md`)
- **WP1.3** - Call and post-call workflows (`execution-packets/phase-1/wp1-3_call_and_post_call_workflows.md`)
- **WP1.4** - Follow-up, objections, and next actions (`execution-packets/phase-1/wp1-4_follow_up_objections_and_next_actions.md`)
- **WP1.5** - Enrollment Pipeline and Founder Inbox projections (`execution-packets/phase-1/wp1-5_enrollment_pipeline_and_founder_inbox_projections.md`)
- **WP1.6** - Beta launch campaign model and source brief (`execution-packets/phase-1/wp1-6_beta_launch_campaign_model_and_source_brief.md`)
- **WP1.7** - LinkedIn, Substack, email, webinar, and landing-page artifacts (`execution-packets/phase-1/wp1-7_linkedin_substack_email_webinar_and_landing_page_artifacts.md`)
- **WP1.8** - Claims, consent, and platform-draft gates (`execution-packets/phase-1/wp1-8_claims_consent_and_platform_draft_gates.md`)
- **WP1.9** - Funnel, campaign attribution, founder-time dashboards (`execution-packets/phase-1/wp1-9_funnel_campaign_attribution_founder_time_dashboards.md`)
- **WP1.10** - Evaluation, shadow mode, and production activation (`execution-packets/phase-1/wp1-10_evaluation_shadow_mode_and_production_activation.md`)
- **WP2.0** - Phase 1 enrollment-to-beta handoff (`execution-packets/phase-2/wp2-0_phase_1_enrollment_to_beta_handoff.md`)
- **WP2.1** - Beta domain schema and migration (`execution-packets/phase-2/wp2-1_beta_domain_schema_and_migration.md`)
- **WP2.2** - Onboarding artifacts and milestones (`execution-packets/phase-2/wp2-2_onboarding_artifacts_and_milestones.md`)
- **WP2.3** - Product activity and first-value instrumentation (`execution-packets/phase-2/wp2-3_product_activity_and_first_value_instrumentation.md`)
- **WP2.4** - Explainable health engine (`execution-packets/phase-2/wp2-4_explainable_health_engine.md`)
- **WP2.5** - Support queue and triage (`execution-packets/phase-2/wp2-5_support_queue_and_triage.md`)
- **WP2.6** - Outcome, consent, testimonial, and referral workflows (`execution-packets/phase-2/wp2-6_outcome_consent_testimonial_and_referral_workflows.md`)
- **WP2.7** - Weekly editorial-cycle model (`execution-packets/phase-2/wp2-7_weekly_editorial_cycle_model.md`)
- **WP2.8** - LinkedIn and Substack agents and workspaces (`execution-packets/phase-2/wp2-8_linkedin_and_substack_agents_and_workspaces.md`)
- **WP2.9** - Engagement intelligence and question clustering (`execution-packets/phase-2/wp2-9_engagement_intelligence_and_question_clustering.md`)
- **WP2.10** - Metrics, evaluation, and activation (`execution-packets/phase-2/wp2-10_metrics_evaluation_and_activation.md`)
- **WP3.0** - Phase 2 signal and outcome handoff (`execution-packets/phase-3/wp3-0_phase_2_signal_and_outcome_handoff.md`)
- **WP3.1** - Signal and cluster registry (`execution-packets/phase-3/wp3-1_signal_and_cluster_registry.md`)
- **WP3.2** - Change proposals and decisions (`execution-packets/phase-3/wp3-2_change_proposals_and_decisions.md`)
- **WP3.3** - Specification artifacts and canonical requirements (`execution-packets/phase-3/wp3-3_specification_artifacts_and_canonical_requirements.md`)
- **WP3.4** - Synthetic personas and test registry (`execution-packets/phase-3/wp3-4_synthetic_personas_and_test_registry.md`)
- **WP3.5** - Test execution and evidence (`execution-packets/phase-3/wp3-5_test_execution_and_evidence.md`)
- **WP3.6** - Security, memory, and injection suites (`execution-packets/phase-3/wp3-6_security_memory_and_injection_suites.md`)
- **WP3.7** - Defects and regression investigation (`execution-packets/phase-3/wp3-7_defects_and_regression_investigation.md`)
- **WP3.8** - Release candidates and readiness (`execution-packets/phase-3/wp3-8_release_candidates_and_readiness.md`)
- **WP3.9** - Claim impact and revalidation (`execution-packets/phase-3/wp3-9_claim_impact_and_revalidation.md`)
- **WP3.10** - Release communications and customer proof (`execution-packets/phase-3/wp3-10_release_communications_and_customer_proof.md`)
- **WP3.11** - Product, QA, and Release Notion workspaces (`execution-packets/phase-3/wp3-11_product_qa_and_release_notion_workspaces.md`)
- **WP4.0** - Phase 1-3 source and attribution migration (`execution-packets/phase-4/wp4-0_phase_1_3_source_and_attribution_migration.md`)
- **WP4.1** - Source brief and evidence eligibility (`execution-packets/phase-4/wp4-1_source_brief_and_evidence_eligibility.md`)
- **WP4.2** - Positioning and campaign planning (`execution-packets/phase-4/wp4-2_positioning_and_campaign_planning.md`)
- **WP4.3** - LinkedIn production and carousel workflow (`execution-packets/phase-4/wp4-3_linkedin_production_and_carousel_workflow.md`)
- **WP4.4** - Substack research and publishing workflow (`execution-packets/phase-4/wp4-4_substack_research_and_publishing_workflow.md`)
- **WP4.5** - Email, webinar, landing page, and release packages (`execution-packets/phase-4/wp4-5_email_webinar_landing_page_and_release_packages.md`)
- **WP4.6** - Multi-channel repurposing (`execution-packets/phase-4/wp4-6_multi_channel_repurposing.md`)
- **WP4.7** - Claims, consent, and pricing verification (`execution-packets/phase-4/wp4-7_claims_consent_and_pricing_verification.md`)
- **WP4.8** - Platform draft adapters and publication records (`execution-packets/phase-4/wp4-8_platform_draft_adapters_and_publication_records.md`)
- **WP4.9** - Performance ingestion and attribution (`execution-packets/phase-4/wp4-9_performance_ingestion_and_attribution.md`)
- **WP4.10** - Founder voice learning and experiments (`execution-packets/phase-4/wp4-10_founder_voice_learning_and_experiments.md`)
- **WP4.11** - Communications Calendar and Campaign Center (`execution-packets/phase-4/wp4-11_communications_calendar_and_campaign_center.md`)
- **WP5.0** - Competitor taxonomy and approved-source policy (`execution-packets/phase-5/wp5-0_competitor_taxonomy_and_approved_source_policy.md`)
- **WP5.1** - Competitor, offering, and source registry (`execution-packets/phase-5/wp5-1_competitor_offering_and_source_registry.md`)
- **WP5.2** - Retrieval, hashing, and snapshots (`execution-packets/phase-5/wp5-2_retrieval_hashing_and_snapshots.md`)
- **WP5.3** - Observation extraction and verification (`execution-packets/phase-5/wp5-3_observation_extraction_and_verification.md`)
- **WP5.4** - Material change detection (`execution-packets/phase-5/wp5-4_material_change_detection.md`)
- **WP5.5** - Pricing and offer intelligence (`execution-packets/phase-5/wp5-5_pricing_and_offer_intelligence.md`)
- **WP5.6** - Job-based comparison (`execution-packets/phase-5/wp5-6_job_based_comparison.md`)
- **WP5.7** - Strategic alerts and market briefs (`execution-packets/phase-5/wp5-7_strategic_alerts_and_market_briefs.md`)
- **WP5.8** - Notion intelligence workspace and decision commands (`execution-packets/phase-5/wp5-8_notion_intelligence_workspace_and_decision_commands.md`)
- **WP5.9** - Evaluation, freshness, and noise tuning (`execution-packets/phase-5/wp5-9_evaluation_freshness_and_noise_tuning.md`)
- **WP6.0** - Cross-phase data quality and metric readiness audit (`execution-packets/phase-6/wp6-0_cross_phase_data_quality_and_metric_readiness_audit.md`)
- **WP6.1** - Strategic priority registry (`execution-packets/phase-6/wp6-1_strategic_priority_registry.md`)
- **WP6.2** - Unified canonical decision queue (`execution-packets/phase-6/wp6-2_unified_canonical_decision_queue.md`)
- **WP6.3** - Notion Founder Command Center (`execution-packets/phase-6/wp6-3_notion_founder_command_center.md`)
- **WP6.4** - Cross-domain conflict detection (`execution-packets/phase-6/wp6-4_cross_domain_conflict_detection.md`)
- **WP6.5** - Daily founder brief (`execution-packets/phase-6/wp6-5_daily_founder_brief.md`)
- **WP6.6** - Weekly and monthly operating reviews (`execution-packets/phase-6/wp6-6_weekly_and_monthly_operating_reviews.md`)
- **WP6.7** - Full specification compiler and critic (`execution-packets/phase-6/wp6-7_full_specification_compiler_and_critic.md`)
- **WP6.8** - Automation opportunity detection (`execution-packets/phase-6/wp6-8_automation_opportunity_detection.md`)
- **WP6.9** - Autonomy governance and rollback (`execution-packets/phase-6/wp6-9_autonomy_governance_and_rollback.md`)
- **WP6.10** - Evaluation, tuning, and native-UI decision gate (`execution-packets/phase-6/wp6-10_evaluation_tuning_and_native_ui_decision_gate.md`)
