# FOS Sub-Agent Execution and Verification Pack

**Version:** 1.0  
**Generated:** 2026-07-14  
**Coverage:** Founder Operating System Phases 0-6

This package translates the revised FOS specifications into a coordination and verification layer suitable for a lead architecture agent and parallel implementation sub-agents.

## What this pack contains

- Repository-assessment and architecture-freeze procedure
- Cross-phase dependency DAG and merge sequence
- Shared API, event, artifact, agent, workspace-command, and test contracts
- Canonical migration and compatibility strategy
- Notion Founder Workspace Adapter contract
- Shared integration-test harness design
- Stable synthetic fixtures and golden evaluation datasets
- Requirement-to-test and work-package matrices
- Agent evaluation rubrics and outcome-measurement contracts
- CI, merge, release, security, red-team, and rollback gates
- Sub-agent team topology and orchestrator engineering practices
- One bounded execution packet for every Phase 0-6 work package
- Machine-readable YAML, JSON Schema, CSV, and example CI assets
- A validation tool that checks the package for broken IDs and references

## Read this first

1. `docs/00_Executive_Readiness_and_Assumptions.md`
2. `docs/01_Orchestrator_Engineering_Guide.md`
3. `docs/02_Repository_Assessment_and_Architecture_Freeze.md`
4. `docs/03_Cross_Phase_Dependency_DAG.md`
5. `docs/07_Shared_Test_Harness_and_Integration_Suite.md`
6. `docs/14_Execution_Packet_Standard.md`
7. The appropriate file under `execution-packets/phase-*`

## Important limitation

The pack is repository-neutral because the current application repository was not part of this generation request. Before coding begins, the lead architecture agent must complete the repository overlay defined in `docs/02_Repository_Assessment_and_Architecture_Freeze.md`. That overlay freezes actual package paths, frameworks, migration mechanisms, test commands, and owners without changing the business and governance contracts in this pack.

## Validation

```bash
python tools/validate_pack.py
```

The validator checks unique work-package and test IDs, dependency references, fixture references, JSON syntax, and required packet sections.
