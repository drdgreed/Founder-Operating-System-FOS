# Branch Protection

Protect `main`, `integration`, shared-contract directories, migrations, authorization, workspace adapter, event registry, and CI configuration. Require code-owner review, green checks, signed commits if supported, and no direct pushes. Use a merge queue for shared primitives.
