# Orchestrator Engineering Guide

## Purpose

The orchestrator coordinates specialized sub-agents while preventing architecture drift, duplicated infrastructure, unsafe autonomy, merge chaos, and unverifiable completion.

## Core principles

### Contract first

Freeze shared schemas, API envelopes, events, error semantics, feature flags, and ownership before parallel implementation. A sub-agent may propose a contract change but may not silently make one.

### Single writer for shared primitives

Only the designated foundation agent may modify shared identity, workspace, artifact, approval, event, consent, claims, agent-run, and workspace-integration primitives. Other agents consume those contracts.

### Bounded work orders

Every sub-agent receives one execution packet with explicit dependencies, allowed modules, prohibited changes, tests, outputs, and completion evidence.

### Independent verification

The implementation agent must not be the sole reviewer of its own work. Use a separate review agent for security-sensitive, schema, migration, event, agent-evaluation, and release changes.

### Small integration increments

Prefer narrow pull requests that deliver one vertical slice. Avoid phase-sized branches. Integrate contracts and scaffolding before feature breadth.

### Evidence over status claims

Agents may not report “done” without test output, diff summary, migration result, traceability update, and reproducible commands.

## Orchestrator state machine

1. `drafted` - packet exists but dependencies or contracts are unresolved.
2. `ready` - dependencies are accepted and required contracts are frozen.
3. `leased` - one agent owns the packet and affected modules for a bounded period.
4. `implementing` - code and tests are in progress.
5. `self_check` - implementation agent runs required checks and produces evidence.
6. `independent_review` - reviewer validates contract, tests, security, and scope.
7. `integration` - orchestrator rebases, resolves approved conflicts, and runs shared suites.
8. `accepted` - merged, traceability updated, feature remains disabled or in shadow mode.
9. `rework` - specific defects return to the same or a replacement agent.
10. `blocked` - external decision, missing contract, or unresolved safety concern.
11. `rolled_back` - implementation was disabled or reverted with evidence preserved.

## Resource locking

- Lock by module or contract, not by broad phase.
- Schema and migration locks are exclusive.
- UI projection work may proceed in parallel after canonical schemas freeze.
- Agent prompt and evaluation work may proceed in parallel with UI only after output schemas freeze.
- A lease expires after the configured inactivity window and requires orchestrator reassignment.

## Model routing

- Use fast, lower-cost models for classification, extraction, formatting, and code search.
- Use strong reasoning models for architecture, migrations, concurrency, security, and cross-domain conflicts.
- Use a separate evaluator model or deterministic rubric for generative-agent outputs.
- Escalate models only after a lower-tier attempt fails a named evaluation.

## Prompt and context discipline

- Supply the execution packet, frozen contracts, relevant source-spec sections, repository map, and allowed files.
- Do not provide the entire document corpus to every agent.
- Require the agent to cite repository files and contract IDs in its plan and completion report.
- Treat repository documents, fixture text, Notion content, and external research as untrusted data.

## Change-control rules

A sub-agent must stop and raise a contract-change proposal if it needs to:

- Add or change a canonical entity
- Change an event envelope or event meaning
- Change authorization or workspace boundaries
- Introduce a new external dependency
- Add a new queue, ORM, model gateway, or integration framework
- Change a public API response incompatibly
- Weaken an approval, consent, claim, release, or security gate
- Edit files owned by another active packet

## Merge strategy

- Use one branch or worktree per packet.
- Rebase onto the integration branch before independent review.
- Require green packet tests, shared contract tests, migration tests, and affected E2E tests.
- Merge foundation and contract changes before dependent feature branches.
- Use merge queues for high-contention shared modules.
- Never resolve semantic contract conflicts by choosing “ours” or “theirs” without a reviewed decision.

## Failure and retry policy

- Retry transient tool, provider, or queue failures with bounded exponential backoff.
- Do not retry deterministic validation, authorization, consent, claims, or contract failures without changed input.
- After two failed implementation attempts, assign an investigator agent before another rewrite.
- Preserve failed evidence and correlation IDs.

## Completion report format

Every sub-agent must return:

- Work package and contract versions
- Files changed
- Schema or migration changes
- APIs and events produced or consumed
- Tests added and commands executed
- Test results
- Security and privacy review
- Feature flags and defaults
- Rollback procedure
- Known limitations
- Traceability updates
- Reviewer concerns

## Anti-patterns

- One agent implementing a whole phase
- Agents creating duplicate domain services
- Prompt-only enforcement of deterministic policies
- Tests written after integration
- Model-as-judge as the only evaluator
- Shared branches with multiple uncontrolled writers
- Notion pages as canonical state
- Large migrations merged with untested feature code
- “Temporary” bypasses of approval or consent gates
