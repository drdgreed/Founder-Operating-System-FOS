# Repository Assessment and Architecture Freeze

## Objective

Produce the repository-specific overlay required before implementation sub-agents modify code.

## Required inspection

- Frontend, backend, API, and deployment frameworks
- Authentication, authorization, tenant/workspace, and role models
- Database, ORM, migrations, transactions, and data-retention mechanisms
- Current profile, application, opportunity, artifact, content, consent, claim, evidence, test, and release entities
- Background jobs, schedulers, queues, idempotency, and dead-letter handling
- LLM gateway, prompt registry, structured-output validation, evaluation, and cost tracking
- Email, calendar, Notion, GitHub, analytics, storage, and publication integrations
- Logging, metrics, traces, error reporting, security scanning, and feature flags
- Unit, integration, E2E, contract, and load-test frameworks

## Deliverables

### Architecture map

List each relevant repository module, responsibility, owner, dependencies, and whether it is reused, extended, migrated, deprecated, or replaced.

### Entity reuse matrix

For each canonical FOS entity, identify the existing entity or migration decision. Duplicate person, workspace, artifact, approval, event, consent, claim, and agent-run systems are prohibited without an architecture decision record.

### File ownership map

Assign one primary owner to shared modules. Work packets receive allowlists and denylists based on this map.

### Contract freeze manifest

Record versions and locations for:

- API envelope
- Error envelope
- Event envelope
- Artifact and version schema
- Approval and command schema
- Agent-run and output schema
- Workspace projection schema
- Test and evaluation schemas

### Command registry

Record actual commands for install, lint, type-check, migrate, seed, unit test, integration test, E2E test, security test, build, and deploy.

## Architecture decision record template

```text
ADR ID:
Title:
Status:
Context:
Decision:
Alternatives:
Consequences:
Migration:
Rollback:
Affected contracts:
Approvers:
```

## Exit gate

No feature packet enters `ready` until the architecture map, file ownership map, and contract freeze manifest have been approved by the lead architecture and security reviewers.
