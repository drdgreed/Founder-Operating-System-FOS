# Cross-Phase Dependency DAG

```mermaid
flowchart TD
  subgraph P0[Phase 0: Founder Workspace and Operating Foundation]
    WP0A["WP0A Compatibility refactor and architecture contracts"]
    WP0_1["WP0.1 Canonical schema and migrations"]
    WP0_2["WP0.2 Domain services and event system"]
    WP0_3["WP0.3 Workspace provider interface and Notion adapter"]
    WP0_4["WP0.4 Collection bootstrap and mappings"]
    WP0_5["WP0.5 Read-only projections"]
    WP0_6["WP0.6 Webhooks, edit capture, and controlled commands"]
    WP0_7["WP0.7 Approval bridge and action boundaries"]
    WP0_8["WP0.8 Communications and campaign foundation"]
    WP0_9["WP0.9 Integration health, reconciliation, and metrics"]
    WP0_10["WP0.10 Test suite, deployment, and handoff"]
  end
  subgraph P1[Phase 1: Enrollment Revenue and Beta Launch Communications]
    WP1_0["WP1.0 Phase 0 contract verification and migration"]
    WP1_1["WP1.1 Opportunity and attribution extensions"]
    WP1_2["WP1.2 Enrollment agent runtime and assessments"]
    WP1_3["WP1.3 Call and post-call workflows"]
    WP1_4["WP1.4 Follow-up, objections, and next actions"]
    WP1_5["WP1.5 Enrollment Pipeline and Founder Inbox projections"]
    WP1_6["WP1.6 Beta launch campaign model and source brief"]
    WP1_7["WP1.7 LinkedIn, Substack, email, webinar, and landing-page artifacts"]
    WP1_8["WP1.8 Claims, consent, and platform-draft gates"]
    WP1_9["WP1.9 Funnel, campaign attribution, founder-time dashboards"]
    WP1_10["WP1.10 Evaluation, shadow mode, and production activation"]
  end
  subgraph P2[Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence]
    WP2_0["WP2.0 Phase 1 enrollment-to-beta handoff"]
    WP2_1["WP2.1 Beta domain schema and migration"]
    WP2_2["WP2.2 Onboarding artifacts and milestones"]
    WP2_3["WP2.3 Product activity and first-value instrumentation"]
    WP2_4["WP2.4 Explainable health engine"]
    WP2_5["WP2.5 Support queue and triage"]
    WP2_6["WP2.6 Outcome, consent, testimonial, and referral workflows"]
    WP2_7["WP2.7 Weekly editorial-cycle model"]
    WP2_8["WP2.8 LinkedIn and Substack agents and workspaces"]
    WP2_9["WP2.9 Engagement intelligence and question clustering"]
    WP2_10["WP2.10 Metrics, evaluation, and activation"]
  end
  subgraph P3[Phase 3: Product Learning, QA, Release, and Customer Proof]
    WP3_0["WP3.0 Phase 2 signal and outcome handoff"]
    WP3_1["WP3.1 Signal and cluster registry"]
    WP3_2["WP3.2 Change proposals and decisions"]
    WP3_3["WP3.3 Specification artifacts and canonical requirements"]
    WP3_4["WP3.4 Synthetic personas and test registry"]
    WP3_5["WP3.5 Test execution and evidence"]
    WP3_6["WP3.6 Security, memory, and injection suites"]
    WP3_7["WP3.7 Defects and regression investigation"]
    WP3_8["WP3.8 Release candidates and readiness"]
    WP3_9["WP3.9 Claim impact and revalidation"]
    WP3_10["WP3.10 Release communications and customer proof"]
    WP3_11["WP3.11 Product, QA, and Release Notion workspaces"]
  end
  subgraph P4[Phase 4: Scaled Marketing and Communications Operations]
    WP4_0["WP4.0 Phase 1-3 source and attribution migration"]
    WP4_1["WP4.1 Source brief and evidence eligibility"]
    WP4_2["WP4.2 Positioning and campaign planning"]
    WP4_3["WP4.3 LinkedIn production and carousel workflow"]
    WP4_4["WP4.4 Substack research and publishing workflow"]
    WP4_5["WP4.5 Email, webinar, landing page, and release packages"]
    WP4_6["WP4.6 Multi-channel repurposing"]
    WP4_7["WP4.7 Claims, consent, and pricing verification"]
    WP4_8["WP4.8 Platform draft adapters and publication records"]
    WP4_9["WP4.9 Performance ingestion and attribution"]
    WP4_10["WP4.10 Founder voice learning and experiments"]
    WP4_11["WP4.11 Communications Calendar and Campaign Center"]
  end
  subgraph P5[Phase 5: Competitive, Pricing, and Market Intelligence]
    WP5_0["WP5.0 Competitor taxonomy and approved-source policy"]
    WP5_1["WP5.1 Competitor, offering, and source registry"]
    WP5_2["WP5.2 Retrieval, hashing, and snapshots"]
    WP5_3["WP5.3 Observation extraction and verification"]
    WP5_4["WP5.4 Material change detection"]
    WP5_5["WP5.5 Pricing and offer intelligence"]
    WP5_6["WP5.6 Job-based comparison"]
    WP5_7["WP5.7 Strategic alerts and market briefs"]
    WP5_8["WP5.8 Notion intelligence workspace and decision commands"]
    WP5_9["WP5.9 Evaluation, freshness, and noise tuning"]
  end
  subgraph P6[Phase 6: Founder Chief of Staff, Command Center, and Automation Governance]
    WP6_0["WP6.0 Cross-phase data quality and metric readiness audit"]
    WP6_1["WP6.1 Strategic priority registry"]
    WP6_2["WP6.2 Unified canonical decision queue"]
    WP6_3["WP6.3 Notion Founder Command Center"]
    WP6_4["WP6.4 Cross-domain conflict detection"]
    WP6_5["WP6.5 Daily founder brief"]
    WP6_6["WP6.6 Weekly and monthly operating reviews"]
    WP6_7["WP6.7 Full specification compiler and critic"]
    WP6_8["WP6.8 Automation opportunity detection"]
    WP6_9["WP6.9 Autonomy governance and rollback"]
    WP6_10["WP6.10 Evaluation, tuning, and native-UI decision gate"]
  end
  WP0A --> WP0_1
  WP0_1 --> WP0_2
  WP0A --> WP0_3
  WP0_2 --> WP0_3
  WP0_3 --> WP0_4
  WP0_2 --> WP0_5
  WP0_4 --> WP0_5
  WP0_2 --> WP0_6
  WP0_5 --> WP0_6
  WP0_2 --> WP0_7
  WP0_6 --> WP0_7
  WP0_1 --> WP0_8
  WP0_2 --> WP0_8
  WP0_7 --> WP0_8
  WP0_3 --> WP0_9
  WP0_4 --> WP0_9
  WP0_5 --> WP0_9
  WP0_6 --> WP0_9
  WP0_7 --> WP0_9
  WP0_8 --> WP0_9
  WP0_1 --> WP0_10
  WP0_2 --> WP0_10
  WP0_3 --> WP0_10
  WP0_4 --> WP0_10
  WP0_5 --> WP0_10
  WP0_6 --> WP0_10
  WP0_7 --> WP0_10
  WP0_8 --> WP0_10
  WP0_9 --> WP0_10
  WP0_10 --> WP1_0
  WP1_0 --> WP1_1
  WP1_0 --> WP1_2
  WP1_1 --> WP1_2
  WP1_2 --> WP1_3
  WP1_2 --> WP1_4
  WP1_3 --> WP1_4
  WP1_1 --> WP1_5
  WP1_4 --> WP1_5
  WP1_0 --> WP1_6
  WP0_8 --> WP1_6
  WP1_6 --> WP1_7
  WP1_7 --> WP1_8
  WP0_7 --> WP1_8
  WP0_8 --> WP1_8
  WP1_1 --> WP1_9
  WP1_5 --> WP1_9
  WP1_6 --> WP1_9
  WP1_7 --> WP1_9
  WP1_2 --> WP1_10
  WP1_3 --> WP1_10
  WP1_4 --> WP1_10
  WP1_5 --> WP1_10
  WP1_6 --> WP1_10
  WP1_7 --> WP1_10
  WP1_8 --> WP1_10
  WP1_9 --> WP1_10
  WP1_10 --> WP2_0
  WP2_0 --> WP2_1
  WP2_1 --> WP2_2
  WP2_1 --> WP2_3
  WP2_3 --> WP2_4
  WP2_1 --> WP2_5
  WP2_2 --> WP2_6
  WP2_5 --> WP2_6
  WP2_0 --> WP2_7
  WP0_8 --> WP2_7
  WP2_7 --> WP2_8
  WP2_8 --> WP2_9
  WP2_2 --> WP2_10
  WP2_3 --> WP2_10
  WP2_4 --> WP2_10
  WP2_5 --> WP2_10
  WP2_6 --> WP2_10
  WP2_7 --> WP2_10
  WP2_8 --> WP2_10
  WP2_9 --> WP2_10
  WP2_10 --> WP3_0
  WP3_0 --> WP3_1
  WP3_1 --> WP3_2
  WP3_2 --> WP3_3
  WP3_3 --> WP3_4
  WP3_4 --> WP3_5
  WP3_5 --> WP3_6
  WP3_5 --> WP3_7
  WP3_6 --> WP3_7
  WP3_3 --> WP3_8
  WP3_5 --> WP3_8
  WP3_7 --> WP3_8
  WP3_8 --> WP3_9
  WP3_8 --> WP3_10
  WP3_9 --> WP3_10
  WP3_1 --> WP3_11
  WP3_3 --> WP3_11
  WP3_5 --> WP3_11
  WP3_8 --> WP3_11
  WP3_10 --> WP3_11
  WP1_10 --> WP4_0
  WP2_10 --> WP4_0
  WP3_10 --> WP4_0
  WP4_0 --> WP4_1
  WP4_1 --> WP4_2
  WP4_2 --> WP4_3
  WP4_2 --> WP4_4
  WP4_2 --> WP4_5
  WP4_3 --> WP4_6
  WP4_4 --> WP4_6
  WP4_5 --> WP4_6
  WP4_1 --> WP4_7
  WP4_3 --> WP4_7
  WP4_4 --> WP4_7
  WP4_5 --> WP4_7
  WP4_6 --> WP4_7
  WP4_7 --> WP4_8
  WP4_8 --> WP4_9
  WP4_9 --> WP4_10
  WP4_1 --> WP4_11
  WP4_2 --> WP4_11
  WP4_3 --> WP4_11
  WP4_4 --> WP4_11
  WP4_5 --> WP4_11
  WP4_6 --> WP4_11
  WP4_7 --> WP4_11
  WP4_8 --> WP4_11
  WP4_9 --> WP4_11
  WP4_10 --> WP4_11
  WP0_10 --> WP5_0
  WP5_0 --> WP5_1
  WP5_1 --> WP5_2
  WP5_2 --> WP5_3
  WP5_3 --> WP5_4
  WP5_3 --> WP5_5
  WP5_3 --> WP5_6
  WP5_5 --> WP5_6
  WP5_4 --> WP5_7
  WP5_5 --> WP5_7
  WP5_6 --> WP5_7
  WP5_7 --> WP5_8
  WP5_2 --> WP5_9
  WP5_3 --> WP5_9
  WP5_4 --> WP5_9
  WP5_5 --> WP5_9
  WP5_6 --> WP5_9
  WP5_7 --> WP5_9
  WP5_8 --> WP5_9
  WP1_10 --> WP6_0
  WP2_10 --> WP6_0
  WP3_10 --> WP6_0
  WP4_10 --> WP6_0
  WP5_9 --> WP6_0
  WP6_0 --> WP6_1
  WP6_0 --> WP6_2
  WP6_1 --> WP6_2
  WP6_2 --> WP6_3
  WP6_2 --> WP6_4
  WP6_2 --> WP6_5
  WP6_4 --> WP6_5
  WP6_5 --> WP6_6
  WP3_3 --> WP6_7
  WP6_1 --> WP6_7
  WP6_6 --> WP6_8
  WP6_8 --> WP6_9
  WP6_3 --> WP6_10
  WP6_4 --> WP6_10
  WP6_5 --> WP6_10
  WP6_6 --> WP6_10
  WP6_7 --> WP6_10
  WP6_8 --> WP6_10
  WP6_9 --> WP6_10
```

## Scheduling rules

- Phase gates indicate contract readiness, not necessarily completion of every UI refinement.
- Market-intelligence work may begin after Phase 0, but its strategic integration into Phase 6 waits for Phase 5 acceptance.
- Phase 4 source migration requires accepted evidence and attribution contracts from Phases 1-3.
- Phase 6 begins only after data-quality and metric readiness from all operational phases.
- Work packages without direct dependencies may run in parallel only after file ownership is assigned.
