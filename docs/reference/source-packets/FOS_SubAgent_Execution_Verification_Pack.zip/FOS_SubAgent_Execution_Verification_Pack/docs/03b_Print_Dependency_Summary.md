# Cross-Phase Dependency Summary

| Release train | Primary gate | May run in parallel with |
|---|---|---|
| Phase 0 foundation | Repository architecture freeze and shared contracts | None before contract freeze |
| Phase 1 revenue | Phase 0 accepted | Limited Phase 5 taxonomy design |
| Phase 2 beta operations | Phase 1 enrollment handoff accepted | Phase 1 optimization |
| Phase 3 product quality | Phase 2 signal and outcome handoff | Late Phase 2 editorial operations |
| Phase 4 marketing scale | Accepted evidence and attribution from Phases 1-3 | Phase 5 monitoring |
| Phase 5 market intelligence | Phase 0 source and workspace contracts | Late Phases 3-4 |
| Phase 6 founder coordination | Cross-phase data-quality readiness from Phases 1-5 | No early start beyond design |

The full machine-readable dependency graph is provided in `matrices/cross_phase_dependencies.csv`, `orchestrator/work_package_registry.yaml`, and `docs/03_Cross_Phase_Dependency_DAG.md`.
