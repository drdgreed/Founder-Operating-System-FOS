# Cross-Phase Dependency Summary

- **Phase 0 foundation:** Requires the repository architecture freeze and shared contracts. Nothing runs before the contract freeze.
- **Phase 1 revenue:** Begins after Phase 0 acceptance. Limited Phase 5 taxonomy design may proceed separately.
- **Phase 2 beta operations:** Begins after the Phase 1 enrollment handoff. Phase 1 optimization may continue in parallel.
- **Phase 3 product quality:** Begins after Phase 2 signal and outcome handoff. Late Phase 2 editorial operations may continue.
- **Phase 4 marketing scale:** Requires accepted evidence and attribution from Phases 1-3. Phase 5 monitoring may run in parallel.
- **Phase 5 market intelligence:** Requires Phase 0 source and workspace contracts. It may overlap late Phases 3-4.
- **Phase 6 founder coordination:** Requires cross-phase data-quality readiness from Phases 1-5. Do not implement early beyond design.

The full machine-readable graph is in `matrices/cross_phase_dependencies.csv`, `orchestrator/work_package_registry.yaml`, and `docs/03_Cross_Phase_Dependency_DAG.md`.
