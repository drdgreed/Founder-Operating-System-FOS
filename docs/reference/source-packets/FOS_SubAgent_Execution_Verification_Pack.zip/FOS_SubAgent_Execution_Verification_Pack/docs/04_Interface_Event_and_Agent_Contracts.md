# Interface, Event, and Agent Contracts

## Shared API conventions

- Version APIs explicitly or through compatible additive evolution.
- Validate request and response bodies with repository-native typed schemas.
- Use stable machine-readable error codes.
- Require idempotency keys for intake, commands, external drafts, publication records, test execution, and webhooks.
- Use optimistic concurrency for founder-editable and lifecycle records.
- Paginate collection endpoints.
- Enforce authorization server-side.

## Error envelope

```json
{
  "error": {
    "code": "FOS_VERSION_CONFLICT",
    "message": "The record changed after the workspace projection was loaded.",
    "correlation_id": "uuid",
    "retryable": false,
    "details": {}
  }
}
```

## Event envelope

Every event includes:

- `event_id`
- `event_type`
- `schema_version`
- `workspace_id`
- `entity_type`
- `entity_id`
- `occurred_at`
- `actor_type`
- `actor_id`
- `correlation_id`
- `causation_id`
- `idempotency_key`
- `payload`

Events are append-only. Consumers must be idempotent. Breaking event changes require a new schema version.

## Artifact contract

Artifacts separate identity from immutable versions. Working-copy edits create new versions after validation. Approval targets a specific version. Published or executed artifacts retain a final snapshot.

## Workspace command contract

Notion and future workspace providers never directly change protected state. A workspace action creates a command that is authenticated, deduplicated, version-checked, policy-checked, executed through domain services, audited, and projected back.

## Agent contract

Each agent definition includes:

- Stable key and version
- Bounded objective
- Trigger and input schema
- Allowed context scopes
- Allowed tools
- Prohibited actions
- Structured output schema
- Required evidence
- Deterministic validation
- Evaluation rubric
- Escalation rules
- Maximum autonomy
- Timeout and cost limits

## Compatibility rules

- Additive fields default safely.
- Removing or changing meaning requires migration and dual-read or dual-write where needed.
- Prompts and model changes are versioned independently of output schemas.
- Agent output schema changes require evaluation-set reruns.
