# Canonical Schema and Migration Plan

## Migration principles

- Reuse existing identity, user, and workspace records when stable identifiers exist.
- Introduce generic `ArtifactRecord` and `ArtifactVersion` primitives before phase-specific document workflows.
- Keep raw source events immutable and summaries versioned.
- Use forward-only migrations in production unless the repository has a tested rollback mechanism.
- Separate schema migration, data backfill, and feature activation.
- Make backfills restartable, idempotent, observable, and bounded.

## Migration stages

1. Inventory and compatibility analysis
2. Additive schema creation
3. Dual-read or compatibility adapters
4. Idempotent data backfill
5. Data-quality verification
6. Shadow reads and comparison
7. Canonical cutover
8. Legacy write disablement
9. Cleanup after retention window

## Required migration tests

- Empty database migration
- Production-like snapshot migration
- Restart after partial backfill
- Duplicate and malformed legacy records
- Workspace-isolation validation
- Referential integrity
- Version and timestamp preservation
- Rollback or forward-fix rehearsal

## Data-quality checks

- Orphaned foreign keys
- Duplicate canonical identities
- Missing workspace IDs
- Invalid consent or claim states
- Artifact versions without records
- Approval targets without immutable snapshots
- Events without correlation IDs
- Notion projections without canonical links

## Schema ownership

Only the foundation schema owner may merge changes to shared canonical primitives. Phase agents may add phase-owned tables after contract review.
