# Notion Founder Workspace Adapter Contract

## Architectural role

Notion is a human-editable projection, planning, and command surface. FOS owns canonical state, authorization, evidence, claims, consent, agent runs, metrics, and audit.

## Field ownership classes

- `canonical_read_only` - shown in Notion; changed only by FOS.
- `working_copy_editable` - founder may edit prose or notes; changes become versioned artifacts.
- `controlled_command` - a property or button creates a validated command.
- `not_projectable` - secrets, private raw data, full traces, and sensitive evidence.

## Required hidden properties

- FOS Record ID
- FOS Entity Type
- FOS Version
- FOS Workspace ID
- Projection Version
- Last Synced At

## Synchronization flow

FOS events create or update projections. Notion webhooks create deduplicated `WorkspaceCommand` records. The command service validates identity, current version, consent, claims, authorization, and action policy before calling domain services.

## Conflict behavior

If projected and canonical versions differ, do not overwrite. Create a conflict record, preserve both snapshots, and require resolution.

## Rate-limit and resilience behavior

- Queue provider operations.
- Use exponential backoff for retryable provider errors.
- Reconcile periodically using hashes and version stamps.
- Keep FOS fully operational while Notion is unavailable.
- Mark projections out of sync after retry exhaustion.

## Security

- Use minimum integration scopes.
- Store credentials in secret management.
- Do not project raw prompts, secrets, payment data, unrestricted transcripts, or exploitable security details.
- Revalidate claims and consent after founder edits.
