# Shared Test Harness and Integration Suite

## Objective

Provide one reusable harness so feature agents do not invent incompatible mocks, clocks, provider adapters, identity fixtures, or event assertions.

## Required harness components

- Ephemeral relational database and migration runner
- Transaction and cleanup helpers
- Stable fixture loader
- Fake clock and timezone control
- Queue and scheduler test adapter
- Deterministic model stub and recorded-output mode
- Fake Notion provider and webhook simulator
- Fake email, calendar, GitHub, object-storage, analytics, and publication adapters
- Identity, role, and workspace fixtures
- Event collector and correlation assertions
- Cost, latency, and telemetry collector
- Failure injection for timeouts, duplicates, stale versions, partial writes, and provider outages

## Test layers

### Unit

Pure validation, state machines, calculations, policies, mappers, and evaluators.

### Contract

Request/response schemas, event schemas, provider adapter behavior, structured agent output, and migration compatibility.

### Integration

Database, domain service, event, queue, provider adapter, claims, consent, approval, and audit interactions.

### Agent evaluation

Grounding, completeness, policy, privacy, product consistency, escalation, and founder usefulness.

### End-to-end

Founder-visible workflows across UI or workspace, canonical services, agents, approvals, adapters, and metrics.

### Security and resilience

Workspace isolation, prompt injection, malicious documents, stale claims, revoked consent, replayed webhooks, privilege escalation, timeout, retry, and rollback.

## Mandatory cross-system scenarios

1. Application -> person -> opportunity -> enrollment brief -> approval.
2. Founder edit in Notion -> command -> version check -> claims revalidation -> canonical artifact.
3. Approval -> downstream email or platform draft; no autonomous send.
4. Enrollment -> onboarding -> first value -> outcome evidence.
5. Support case -> triage -> product signal -> change proposal.
6. Specification -> requirements -> tests -> release candidate.
7. Release -> capability update -> claim-impact scan.
8. Evidence -> LinkedIn/Substack asset -> approval -> publication record.
9. Consent revocation -> pending and future public-use assets blocked.
10. Competitor change -> observation -> strategic alert.
11. Cross-domain conflict -> Founder Inbox -> resolution.
12. Provider failure -> retry -> dead letter -> reconciliation.

## Determinism

Agent tests use fixed fixtures, frozen model outputs or deterministic stubs, and explicit evaluator versions. Live-model smoke tests are separate and non-blocking until calibrated.
