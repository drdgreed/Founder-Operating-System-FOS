# Fixture and Golden Dataset Catalog

## Rules

- Fixtures use fictional people and organizations.
- Stable fixture IDs never change meaning.
- Sensitive traits are excluded unless needed for an explicit safety test.
- One fixture may be reused across unit, integration, E2E, and agent-evaluation tests.
- Expected outcomes are versioned.

## Domains

### Enrollment

Strong fit, ambiguous fit, incomplete application, contradictory history, price objection, time objection, unresponsive lead, revoked consent, prompt injection, and out-of-scope request.

### Beta operations

Healthy active user, scheduled pause, product-defect block, onboarding confusion, first-value achievement, withdrawal, referral readiness, and unverified outcome.

### Product and QA

Repeated product signal, memory leak, malformed output, tool timeout, duplicate event, version conflict, regression, and release rollback.

### Marketing

Approved release, named consent, anonymous consent, no consent, expired claim, planned capability, comparative claim, long-form paper, and derivative adding an unsupported claim.

### Market intelligence

Verified pricing change, unchanged page, removed feature, company claim, low-confidence rumor, and malicious source instruction.

The concrete JSON fixtures are under `fixtures/` and referenced by the machine-readable test catalogs.
