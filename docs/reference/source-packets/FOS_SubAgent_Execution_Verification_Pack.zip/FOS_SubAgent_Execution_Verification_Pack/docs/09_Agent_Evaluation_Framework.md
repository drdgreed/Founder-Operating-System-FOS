# Agent Evaluation Framework

## Evaluation dimensions

| Dimension | Question | Primary method |
|---|---|---|
| Grounding | Are factual statements supported by allowed evidence? | Deterministic source resolution plus evaluator |
| Completeness | Are required fields and material risks present? | Schema and rubric |
| Policy | Were approvals, consent, claims, and autonomy boundaries followed? | Deterministic checks |
| Privacy | Was unrelated or sensitive information excluded? | Rule-based and adversarial tests |
| Product consistency | Does output match current capabilities, offer, release, and strategy? | Canonical lookups |
| Usefulness | Does it reduce founder work and support a sound decision? | Founder sample scoring |
| Stability | Does behavior remain acceptable across model or prompt changes? | Regression set |
| Efficiency | Is cost and latency proportionate to business value? | Telemetry |

## Scoring

Use a 100-point rubric with hard gates. A high overall score cannot compensate for a hard failure in authorization, consent, unsupported claims, cross-user leakage, or unauthorized external action.

Suggested weights:

- Grounding 25
- Completeness 15
- Policy 20
- Privacy 15
- Product consistency 10
- Usefulness 10
- Efficiency 5

## Evaluation release gate

- All hard-gate cases pass.
- Mean score meets agent-specific threshold.
- No material regression against the prior accepted agent version.
- Founder reviews a calibrated sample before production activation.
- Prompt, model, tools, output schema, and evaluator versions are recorded.

## Live monitoring

Sample accepted outputs, founder edits, rejections, failures, and outcome effectiveness. Do not train or update durable founder preferences from a single edit.
