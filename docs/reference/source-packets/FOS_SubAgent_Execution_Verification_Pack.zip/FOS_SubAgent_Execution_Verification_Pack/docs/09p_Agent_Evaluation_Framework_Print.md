# Agent Evaluation Framework

## Evaluation dimensions

- **Grounding:** Factual statements must resolve to allowed evidence. Use deterministic source resolution plus an evaluator.
- **Completeness:** Required fields and material risks must be present. Use schema validation and a rubric.
- **Policy:** Approvals, consent, claims, and autonomy boundaries must be followed. Use deterministic checks.
- **Privacy:** Unrelated and sensitive information must be excluded. Use rule-based and adversarial tests.
- **Product consistency:** Outputs must match current capabilities, offers, releases, and strategy. Use canonical lookups.
- **Usefulness:** Outputs should reduce founder work and support a sound decision. Use sampled founder scoring.
- **Stability:** Behavior must remain acceptable across model and prompt changes. Use regression cases.
- **Efficiency:** Cost and latency must be proportionate to business value. Use telemetry.

## Scoring

Use a 100-point rubric with hard gates: Grounding 25, Completeness 15, Policy 20, Privacy 15, Product consistency 10, Usefulness 10, and Efficiency 5. A high overall score cannot compensate for authorization, consent, unsupported-claim, cross-user-leak, or unauthorized-action failures.

## Evaluation release gate

All hard-gate cases pass; the mean score meets the agent threshold; no material regression exists; the founder reviews a calibrated sample; and prompt, model, tools, schema, and evaluator versions are recorded.

## Live monitoring

Sample accepted outputs, founder edits, rejections, failures, and outcome effectiveness. Do not update durable founder preferences from a single edit.
