# CI/CD, Merge, and Release Gates

## Pull-request gates

- Formatting and lint
- Type checking
- Unit tests
- Changed contract validation
- Changed migration validation
- Packet-specific integration tests
- Secret and dependency scanning
- Traceability entry present

## Merge gates

- Independent reviewer approval
- Shared contract suite
- Workspace-isolation suite for affected data paths
- Claims and consent suite for external-content paths
- Event and audit assertions
- Feature flag defaults safe
- Migration compatibility and restart test

## Release gates

- Affected E2E journeys
- Agent evaluation regression
- Prompt-injection and malicious-source suite
- Memory-isolation suite
- Performance and cost budgets
- Release-readiness report
- Rollback rehearsal
- Founder approval for consequential activation

## Branching

Use short-lived packet branches or worktrees and an integration branch. Protect shared primitives with code owners. Use a merge queue for migration, event, agent-runtime, and workspace-adapter modules.

## Feature activation

Progress through disabled, test, shadow, founder-only, limited cohort, and full activation. Publishing, sending, deployment, pricing, and autonomy increases require separate approvals.
