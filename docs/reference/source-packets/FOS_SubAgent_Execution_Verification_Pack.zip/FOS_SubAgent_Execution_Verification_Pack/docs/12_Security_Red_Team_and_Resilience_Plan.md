# Security, Red-Team, and Resilience Plan

## Threat classes

- Cross-workspace and cross-user data leakage
- Prompt injection in applications, resumes, support messages, Notion pages, webpages, and tool output
- Unauthorized command or webhook replay
- Privilege escalation
- Consent or claims bypass
- Stale version overwrite
- External action without approval
- Secret leakage in prompts, logs, or projections
- Malicious file or URL processing
- Model hallucination presented as evidence
- Supply-chain and dependency compromise
- Queue duplication, partial workflow, and retry storms

## Required controls

- Least privilege and server-side authorization
- Provider webhook verification and idempotency
- Context minimization and source manifests
- Untrusted-content delimiters and tool allowlists
- Deterministic consent, claims, price, release, and approval gates
- Encrypted secrets and sensitive fields
- Structured logs without raw private content
- Rate limits and cost ceilings
- Dead-letter queues and reconciliation
- Immutable audit and versioned artifacts

## Release-blocking tests

Any confirmed cross-user leak, unauthorized external action, consent bypass, critical injection exploit, or inability to reconstruct a consequential action blocks release.
