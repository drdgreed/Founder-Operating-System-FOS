# Sub-Agent Team Topology and RACI

## Teams

### Foundation

Architecture and contracts, database and migration, workspace integration, security and authorization.

### Enrollment

Opportunity workflow, enrollment intelligence, launch communications, enrollment verification.

### Beta operations

Onboarding and milestones, health and intervention, support and outcomes, editorial cadence.

### Product quality

Signals and specifications, test platform, red team, regression and release readiness.

### Communications

Evidence and positioning, LinkedIn and repurposing, Substack and research, claims and attribution.

### Market and founder operations

Market intelligence, conflict detection, chief of staff, operating reviews, autonomy governance.

## RACI rule

- One Responsible implementation agent per packet.
- One Accountable orchestrator or lead per phase gate.
- At least one Consulted domain or security reviewer for shared-contract changes.
- Founder is Informed for reversible internal changes and Accountable for strategic, public, pricing, deployment, and autonomy decisions.

## Reviewer independence

The reviewer should use the packet, contracts, diff, and test evidence, not the implementation agent's narrative alone.
