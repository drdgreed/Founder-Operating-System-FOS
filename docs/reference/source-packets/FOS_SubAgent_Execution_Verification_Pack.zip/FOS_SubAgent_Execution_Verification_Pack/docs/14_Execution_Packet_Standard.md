# Execution Packet Standard

Every packet includes:

1. Objective and business value
2. Scope and explicit non-scope
3. Dependencies and contract versions
4. Inputs and fixtures
5. Deliverables
6. Interfaces consumed and produced
7. Allowed and prohibited changes
8. Functional requirements
9. Security, privacy, and governance constraints
10. Required tests and gates
11. Observability and cost requirements
12. Migration and rollout
13. Definition of done
14. Completion evidence
15. Independent-review checklist
16. Escalation conditions

## Repository overlay

Before leasing a packet, the orchestrator adds:

- Assigned agent and reviewer
- Branch or worktree
- Allowed file globs
- Prohibited file globs
- Actual commands
- Environment and fixture set
- Contract commit hashes
- Lease expiration

## Scope discipline

A packet agent may make necessary local implementation choices but may not change cross-packet contracts, security posture, or architecture without an approved change proposal.
