# Work Package Registry

| Work package | Phase | Deliverable | Dependencies | Risk | Team |
|---|---:|---|---|---|---|
| WP0A | 0 | Compatibility refactor and architecture contracts | - | medium | foundation |
| WP0.1 | 0 | Canonical schema and migrations | WP0A | critical | foundation |
| WP0.2 | 0 | Domain services and event system | WP0.1 | critical | foundation |
| WP0.3 | 0 | Workspace provider interface and Notion adapter | WP0A;WP0.2 | medium | foundation |
| WP0.4 | 0 | Collection bootstrap and mappings | WP0.3 | medium | foundation |
| WP0.5 | 0 | Read-only projections | WP0.2;WP0.4 | medium | foundation |
| WP0.6 | 0 | Webhooks, edit capture, and controlled commands | WP0.2;WP0.5 | high | foundation |
| WP0.7 | 0 | Approval bridge and action boundaries | WP0.2;WP0.6 | critical | foundation |
| WP0.8 | 0 | Communications and campaign foundation | WP0.1;WP0.2;WP0.7 | medium | foundation |
| WP0.9 | 0 | Integration health, reconciliation, and metrics | WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8 | high | foundation |
| WP0.10 | 0 | Test suite, deployment, and handoff | WP0.1;WP0.2;WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8;WP0.9 | medium | foundation |
| WP1.0 | 1 | Phase 0 contract verification and migration | WP0.10 | critical | enrollment |
| WP1.1 | 1 | Opportunity and attribution extensions | WP1.0 | high | enrollment |
| WP1.2 | 1 | Enrollment agent runtime and assessments | WP1.0;WP1.1 | high | enrollment |
| WP1.3 | 1 | Call and post-call workflows | WP1.2 | medium | enrollment |
| WP1.4 | 1 | Follow-up, objections, and next actions | WP1.2;WP1.3 | medium | enrollment |
| WP1.5 | 1 | Enrollment Pipeline and Founder Inbox projections | WP1.1;WP1.4 | medium | enrollment |
| WP1.6 | 1 | Beta launch campaign model and source brief | WP1.0;WP0.8 | medium | enrollment |
| WP1.7 | 1 | LinkedIn, Substack, email, webinar, and landing-page artifacts | WP1.6 | medium | enrollment |
| WP1.8 | 1 | Claims, consent, and platform-draft gates | WP1.7;WP0.7;WP0.8 | critical | enrollment |
| WP1.9 | 1 | Funnel, campaign attribution, founder-time dashboards | WP1.1;WP1.5;WP1.6;WP1.7 | high | enrollment |
| WP1.10 | 1 | Evaluation, shadow mode, and production activation | WP1.2;WP1.3;WP1.4;WP1.5;WP1.6;WP1.7;WP1.8;WP1.9 | medium | enrollment |
| WP2.0 | 2 | Phase 1 enrollment-to-beta handoff | WP1.10 | medium | beta_operations |
| WP2.1 | 2 | Beta domain schema and migration | WP2.0 | critical | beta_operations |
| WP2.2 | 2 | Onboarding artifacts and milestones | WP2.1 | medium | beta_operations |
| WP2.3 | 2 | Product activity and first-value instrumentation | WP2.1 | medium | beta_operations |
| WP2.4 | 2 | Explainable health engine | WP2.3 | high | beta_operations |
| WP2.5 | 2 | Support queue and triage | WP2.1 | medium | beta_operations |
| WP2.6 | 2 | Outcome, consent, testimonial, and referral workflows | WP2.2;WP2.5 | critical | beta_operations |
| WP2.7 | 2 | Weekly editorial-cycle model | WP2.0;WP0.8 | medium | beta_operations |
| WP2.8 | 2 | LinkedIn and Substack agents and workspaces | WP2.7 | high | beta_operations |
| WP2.9 | 2 | Engagement intelligence and question clustering | WP2.8 | medium | beta_operations |
| WP2.10 | 2 | Metrics, evaluation, and activation | WP2.2;WP2.3;WP2.4;WP2.5;WP2.6;WP2.7;WP2.8;WP2.9 | medium | beta_operations |
| WP3.0 | 3 | Phase 2 signal and outcome handoff | WP2.10 | medium | product_quality |
| WP3.1 | 3 | Signal and cluster registry | WP3.0 | medium | product_quality |
| WP3.2 | 3 | Change proposals and decisions | WP3.1 | medium | product_quality |
| WP3.3 | 3 | Specification artifacts and canonical requirements | WP3.2 | medium | product_quality |
| WP3.4 | 3 | Synthetic personas and test registry | WP3.3 | medium | product_quality |
| WP3.5 | 3 | Test execution and evidence | WP3.4 | medium | product_quality |
| WP3.6 | 3 | Security, memory, and injection suites | WP3.5 | critical | product_quality |
| WP3.7 | 3 | Defects and regression investigation | WP3.5;WP3.6 | medium | product_quality |
| WP3.8 | 3 | Release candidates and readiness | WP3.3;WP3.5;WP3.7 | critical | product_quality |
| WP3.9 | 3 | Claim impact and revalidation | WP3.8 | medium | product_quality |
| WP3.10 | 3 | Release communications and customer proof | WP3.8;WP3.9 | critical | product_quality |
| WP3.11 | 3 | Product, QA, and Release Notion workspaces | WP3.1;WP3.3;WP3.5;WP3.8;WP3.10 | critical | product_quality |
| WP4.0 | 4 | Phase 1-3 source and attribution migration | WP1.10;WP2.10;WP3.10 | critical | communications |
| WP4.1 | 4 | Source brief and evidence eligibility | WP4.0 | medium | communications |
| WP4.2 | 4 | Positioning and campaign planning | WP4.1 | medium | communications |
| WP4.3 | 4 | LinkedIn production and carousel workflow | WP4.2 | medium | communications |
| WP4.4 | 4 | Substack research and publishing workflow | WP4.2 | medium | communications |
| WP4.5 | 4 | Email, webinar, landing page, and release packages | WP4.2 | critical | communications |
| WP4.6 | 4 | Multi-channel repurposing | WP4.3;WP4.4;WP4.5 | medium | communications |
| WP4.7 | 4 | Claims, consent, and pricing verification | WP4.1;WP4.3;WP4.4;WP4.5;WP4.6 | critical | communications |
| WP4.8 | 4 | Platform draft adapters and publication records | WP4.7 | medium | communications |
| WP4.9 | 4 | Performance ingestion and attribution | WP4.8 | high | communications |
| WP4.10 | 4 | Founder voice learning and experiments | WP4.9 | medium | communications |
| WP4.11 | 4 | Communications Calendar and Campaign Center | WP4.1;WP4.2;WP4.3;WP4.4;WP4.5;WP4.6;WP4.7;WP4.8;WP4.9;WP4.10 | medium | communications |
| WP5.0 | 5 | Competitor taxonomy and approved-source policy | WP0.10 | medium | market_intelligence |
| WP5.1 | 5 | Competitor, offering, and source registry | WP5.0 | medium | market_intelligence |
| WP5.2 | 5 | Retrieval, hashing, and snapshots | WP5.1 | medium | market_intelligence |
| WP5.3 | 5 | Observation extraction and verification | WP5.2 | medium | market_intelligence |
| WP5.4 | 5 | Material change detection | WP5.3 | medium | market_intelligence |
| WP5.5 | 5 | Pricing and offer intelligence | WP5.3 | high | market_intelligence |
| WP5.6 | 5 | Job-based comparison | WP5.3;WP5.5 | medium | market_intelligence |
| WP5.7 | 5 | Strategic alerts and market briefs | WP5.4;WP5.5;WP5.6 | medium | market_intelligence |
| WP5.8 | 5 | Notion intelligence workspace and decision commands | WP5.7 | high | market_intelligence |
| WP5.9 | 5 | Evaluation, freshness, and noise tuning | WP5.2;WP5.3;WP5.4;WP5.5;WP5.6;WP5.7;WP5.8 | medium | market_intelligence |
| WP6.0 | 6 | Cross-phase data quality and metric readiness audit | WP1.10;WP2.10;WP3.10;WP4.10;WP5.9 | medium | founder_coordination |
| WP6.1 | 6 | Strategic priority registry | WP6.0 | medium | founder_coordination |
| WP6.2 | 6 | Unified canonical decision queue | WP6.0;WP6.1 | medium | founder_coordination |
| WP6.3 | 6 | Notion Founder Command Center | WP6.2 | high | founder_coordination |
| WP6.4 | 6 | Cross-domain conflict detection | WP6.2 | medium | founder_coordination |
| WP6.5 | 6 | Daily founder brief | WP6.2;WP6.4 | medium | founder_coordination |
| WP6.6 | 6 | Weekly and monthly operating reviews | WP6.5 | medium | founder_coordination |
| WP6.7 | 6 | Full specification compiler and critic | WP3.3;WP6.1 | medium | founder_coordination |
| WP6.8 | 6 | Automation opportunity detection | WP6.6 | medium | founder_coordination |
| WP6.9 | 6 | Autonomy governance and rollback | WP6.8 | critical | founder_coordination |
| WP6.10 | 6 | Evaluation, tuning, and native-UI decision gate | WP6.3;WP6.4;WP6.5;WP6.6;WP6.7;WP6.8;WP6.9 | medium | founder_coordination |

## Verification volume

- Work packages: 78
- Execution requirements: 468
- Packet tests: 390
- Golden fixtures: 29
