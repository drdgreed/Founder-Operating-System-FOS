# Work Package and Test Registry

## Phase 0

- **WP0A - Compatibility refactor and architecture contracts**. Dependencies: none. Risk: medium. Team: foundation.
- **WP0.1 - Canonical schema and migrations**. Dependencies: WP0A. Risk: critical. Team: foundation.
- **WP0.2 - Domain services and event system**. Dependencies: WP0.1. Risk: critical. Team: foundation.
- **WP0.3 - Workspace provider interface and Notion adapter**. Dependencies: WP0A;WP0.2. Risk: medium. Team: foundation.
- **WP0.4 - Collection bootstrap and mappings**. Dependencies: WP0.3. Risk: medium. Team: foundation.
- **WP0.5 - Read-only projections**. Dependencies: WP0.2;WP0.4. Risk: medium. Team: foundation.
- **WP0.6 - Webhooks, edit capture, and controlled commands**. Dependencies: WP0.2;WP0.5. Risk: high. Team: foundation.
- **WP0.7 - Approval bridge and action boundaries**. Dependencies: WP0.2;WP0.6. Risk: critical. Team: foundation.
- **WP0.8 - Communications and campaign foundation**. Dependencies: WP0.1;WP0.2;WP0.7. Risk: medium. Team: foundation.
- **WP0.9 - Integration health, reconciliation, and metrics**. Dependencies: WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8. Risk: high. Team: foundation.
- **WP0.10 - Test suite, deployment, and handoff**. Dependencies: WP0.1;WP0.2;WP0.3;WP0.4;WP0.5;WP0.6;WP0.7;WP0.8;WP0.9. Risk: medium. Team: foundation.

## Phase 1

- **WP1.0 - Phase 0 contract verification and migration**. Dependencies: WP0.10. Risk: critical. Team: enrollment.
- **WP1.1 - Opportunity and attribution extensions**. Dependencies: WP1.0. Risk: high. Team: enrollment.
- **WP1.2 - Enrollment agent runtime and assessments**. Dependencies: WP1.0;WP1.1. Risk: high. Team: enrollment.
- **WP1.3 - Call and post-call workflows**. Dependencies: WP1.2. Risk: medium. Team: enrollment.
- **WP1.4 - Follow-up, objections, and next actions**. Dependencies: WP1.2;WP1.3. Risk: medium. Team: enrollment.
- **WP1.5 - Enrollment Pipeline and Founder Inbox projections**. Dependencies: WP1.1;WP1.4. Risk: medium. Team: enrollment.
- **WP1.6 - Beta launch campaign model and source brief**. Dependencies: WP1.0;WP0.8. Risk: medium. Team: enrollment.
- **WP1.7 - LinkedIn, Substack, email, webinar, and landing-page artifacts**. Dependencies: WP1.6. Risk: medium. Team: enrollment.
- **WP1.8 - Claims, consent, and platform-draft gates**. Dependencies: WP1.7;WP0.7;WP0.8. Risk: critical. Team: enrollment.
- **WP1.9 - Funnel, campaign attribution, founder-time dashboards**. Dependencies: WP1.1;WP1.5;WP1.6;WP1.7. Risk: high. Team: enrollment.
- **WP1.10 - Evaluation, shadow mode, and production activation**. Dependencies: WP1.2;WP1.3;WP1.4;WP1.5;WP1.6;WP1.7;WP1.8;WP1.9. Risk: medium. Team: enrollment.

## Phase 2

- **WP2.0 - Phase 1 enrollment-to-beta handoff**. Dependencies: WP1.10. Risk: medium. Team: beta_operations.
- **WP2.1 - Beta domain schema and migration**. Dependencies: WP2.0. Risk: critical. Team: beta_operations.
- **WP2.2 - Onboarding artifacts and milestones**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.3 - Product activity and first-value instrumentation**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.4 - Explainable health engine**. Dependencies: WP2.3. Risk: high. Team: beta_operations.
- **WP2.5 - Support queue and triage**. Dependencies: WP2.1. Risk: medium. Team: beta_operations.
- **WP2.6 - Outcome, consent, testimonial, and referral workflows**. Dependencies: WP2.2;WP2.5. Risk: critical. Team: beta_operations.
- **WP2.7 - Weekly editorial-cycle model**. Dependencies: WP2.0;WP0.8. Risk: medium. Team: beta_operations.
- **WP2.8 - LinkedIn and Substack agents and workspaces**. Dependencies: WP2.7. Risk: high. Team: beta_operations.
- **WP2.9 - Engagement intelligence and question clustering**. Dependencies: WP2.8. Risk: medium. Team: beta_operations.
- **WP2.10 - Metrics, evaluation, and activation**. Dependencies: WP2.2;WP2.3;WP2.4;WP2.5;WP2.6;WP2.7;WP2.8;WP2.9. Risk: medium. Team: beta_operations.

## Phase 3

- **WP3.0 - Phase 2 signal and outcome handoff**. Dependencies: WP2.10. Risk: medium. Team: product_quality.
- **WP3.1 - Signal and cluster registry**. Dependencies: WP3.0. Risk: medium. Team: product_quality.
- **WP3.2 - Change proposals and decisions**. Dependencies: WP3.1. Risk: medium. Team: product_quality.
- **WP3.3 - Specification artifacts and canonical requirements**. Dependencies: WP3.2. Risk: medium. Team: product_quality.
- **WP3.4 - Synthetic personas and test registry**. Dependencies: WP3.3. Risk: medium. Team: product_quality.
- **WP3.5 - Test execution and evidence**. Dependencies: WP3.4. Risk: medium. Team: product_quality.
- **WP3.6 - Security, memory, and injection suites**. Dependencies: WP3.5. Risk: critical. Team: product_quality.
- **WP3.7 - Defects and regression investigation**. Dependencies: WP3.5;WP3.6. Risk: medium. Team: product_quality.
- **WP3.8 - Release candidates and readiness**. Dependencies: WP3.3;WP3.5;WP3.7. Risk: critical. Team: product_quality.
- **WP3.9 - Claim impact and revalidation**. Dependencies: WP3.8. Risk: medium. Team: product_quality.
- **WP3.10 - Release communications and customer proof**. Dependencies: WP3.8;WP3.9. Risk: critical. Team: product_quality.
- **WP3.11 - Product, QA, and Release Notion workspaces**. Dependencies: WP3.1;WP3.3;WP3.5;WP3.8;WP3.10. Risk: critical. Team: product_quality.

## Phase 4

- **WP4.0 - Phase 1-3 source and attribution migration**. Dependencies: WP1.10;WP2.10;WP3.10. Risk: critical. Team: communications.
- **WP4.1 - Source brief and evidence eligibility**. Dependencies: WP4.0. Risk: medium. Team: communications.
- **WP4.2 - Positioning and campaign planning**. Dependencies: WP4.1. Risk: medium. Team: communications.
- **WP4.3 - LinkedIn production and carousel workflow**. Dependencies: WP4.2. Risk: medium. Team: communications.
- **WP4.4 - Substack research and publishing workflow**. Dependencies: WP4.2. Risk: medium. Team: communications.
- **WP4.5 - Email, webinar, landing page, and release packages**. Dependencies: WP4.2. Risk: critical. Team: communications.
- **WP4.6 - Multi-channel repurposing**. Dependencies: WP4.3;WP4.4;WP4.5. Risk: medium. Team: communications.
- **WP4.7 - Claims, consent, and pricing verification**. Dependencies: WP4.1;WP4.3;WP4.4;WP4.5;WP4.6. Risk: critical. Team: communications.
- **WP4.8 - Platform draft adapters and publication records**. Dependencies: WP4.7. Risk: medium. Team: communications.
- **WP4.9 - Performance ingestion and attribution**. Dependencies: WP4.8. Risk: high. Team: communications.
- **WP4.10 - Founder voice learning and experiments**. Dependencies: WP4.9. Risk: medium. Team: communications.
- **WP4.11 - Communications Calendar and Campaign Center**. Dependencies: WP4.1;WP4.2;WP4.3;WP4.4;WP4.5;WP4.6;WP4.7;WP4.8;WP4.9;WP4.10. Risk: medium. Team: communications.

## Phase 5

- **WP5.0 - Competitor taxonomy and approved-source policy**. Dependencies: WP0.10. Risk: medium. Team: market_intelligence.
- **WP5.1 - Competitor, offering, and source registry**. Dependencies: WP5.0. Risk: medium. Team: market_intelligence.
- **WP5.2 - Retrieval, hashing, and snapshots**. Dependencies: WP5.1. Risk: medium. Team: market_intelligence.
- **WP5.3 - Observation extraction and verification**. Dependencies: WP5.2. Risk: medium. Team: market_intelligence.
- **WP5.4 - Material change detection**. Dependencies: WP5.3. Risk: medium. Team: market_intelligence.
- **WP5.5 - Pricing and offer intelligence**. Dependencies: WP5.3. Risk: high. Team: market_intelligence.
- **WP5.6 - Job-based comparison**. Dependencies: WP5.3;WP5.5. Risk: medium. Team: market_intelligence.
- **WP5.7 - Strategic alerts and market briefs**. Dependencies: WP5.4;WP5.5;WP5.6. Risk: medium. Team: market_intelligence.
- **WP5.8 - Notion intelligence workspace and decision commands**. Dependencies: WP5.7. Risk: high. Team: market_intelligence.
- **WP5.9 - Evaluation, freshness, and noise tuning**. Dependencies: WP5.2;WP5.3;WP5.4;WP5.5;WP5.6;WP5.7;WP5.8. Risk: medium. Team: market_intelligence.

## Phase 6

- **WP6.0 - Cross-phase data quality and metric readiness audit**. Dependencies: WP1.10;WP2.10;WP3.10;WP4.10;WP5.9. Risk: medium. Team: founder_coordination.
- **WP6.1 - Strategic priority registry**. Dependencies: WP6.0. Risk: medium. Team: founder_coordination.
- **WP6.2 - Unified canonical decision queue**. Dependencies: WP6.0;WP6.1. Risk: medium. Team: founder_coordination.
- **WP6.3 - Notion Founder Command Center**. Dependencies: WP6.2. Risk: high. Team: founder_coordination.
- **WP6.4 - Cross-domain conflict detection**. Dependencies: WP6.2. Risk: medium. Team: founder_coordination.
- **WP6.5 - Daily founder brief**. Dependencies: WP6.2;WP6.4. Risk: medium. Team: founder_coordination.
- **WP6.6 - Weekly and monthly operating reviews**. Dependencies: WP6.5. Risk: medium. Team: founder_coordination.
- **WP6.7 - Full specification compiler and critic**. Dependencies: WP3.3;WP6.1. Risk: medium. Team: founder_coordination.
- **WP6.8 - Automation opportunity detection**. Dependencies: WP6.6. Risk: medium. Team: founder_coordination.
- **WP6.9 - Autonomy governance and rollback**. Dependencies: WP6.8. Risk: critical. Team: founder_coordination.
- **WP6.10 - Evaluation, tuning, and native-UI decision gate**. Dependencies: WP6.3;WP6.4;WP6.5;WP6.6;WP6.7;WP6.8;WP6.9. Risk: medium. Team: founder_coordination.

## Verification volume

- 78 work packages
- 468 execution requirements
- 390 packet tests
- 29 golden fixtures

Detailed matrices are provided as CSV files in `matrices/`.
