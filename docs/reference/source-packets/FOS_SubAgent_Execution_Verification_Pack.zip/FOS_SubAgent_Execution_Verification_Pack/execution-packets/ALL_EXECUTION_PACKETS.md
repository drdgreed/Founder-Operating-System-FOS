# All Execution Packets

---
work_package: WP0A
phase: 0
title: "Compatibility refactor and architecture contracts"
status: drafted
dependencies: []
primary_team: foundation
risk: medium
---

# WP0A - Compatibility refactor and architecture contracts

## Objective

Implement compatibility refactor and architecture contracts as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- None beyond the repository architecture freeze and shared contract baseline.

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for compatibility refactor and architecture contracts
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0A-REQ-001:** The system shall implement compatibility refactor and architecture contracts using existing repository conventions and shared FOS contracts.
- **0A-REQ-002:** The implementation shall expose versioned, validated interfaces for compatibility refactor and architecture contracts and preserve backward compatibility or provide an explicit migration.
- **0A-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to compatibility refactor and architecture contracts shall be enforced deterministically.
- **0A-REQ-004:** All consequential operations in compatibility refactor and architecture contracts shall be auditable through correlation-aware events and immutable or versioned records.
- **0A-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for compatibility refactor and architecture contracts.
- **0A-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for compatibility refactor and architecture contracts.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-0A-001 | unit | Validate core rules and schemas for compatibility refactor and architecture contracts. | pull_request |
| IT-P0-0A-001 | integration | Verify compatibility refactor and architecture contracts integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-0A-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in compatibility refactor and architecture contracts. | merge |
| OBS-P0-0A-001 | observability | Emit required events, metrics, traces, and correlation identifiers for compatibility refactor and architecture contracts. | merge |
| E2E-P0-0A-001 | end_to_end | Complete the founder-visible workflow for compatibility refactor and architecture contracts with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.1
phase: 0
title: "Canonical schema and migrations"
status: drafted
dependencies: ["WP0A"]
primary_team: foundation
risk: critical
---

# WP0.1 - Canonical schema and migrations

## Objective

Implement canonical schema and migrations as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0A

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for canonical schema and migrations
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-1-REQ-001:** The system shall implement canonical schema and migrations using existing repository conventions and shared FOS contracts.
- **0-1-REQ-002:** The implementation shall expose versioned, validated interfaces for canonical schema and migrations and preserve backward compatibility or provide an explicit migration.
- **0-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to canonical schema and migrations shall be enforced deterministically.
- **0-1-REQ-004:** All consequential operations in canonical schema and migrations shall be auditable through correlation-aware events and immutable or versioned records.
- **0-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for canonical schema and migrations.
- **0-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for canonical schema and migrations.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-01-001 | unit | Validate core rules and schemas for canonical schema and migrations. | pull_request |
| IT-P0-01-001 | integration | Verify canonical schema and migrations integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-01-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in canonical schema and migrations. | merge |
| OBS-P0-01-001 | observability | Emit required events, metrics, traces, and correlation identifiers for canonical schema and migrations. | merge |
| E2E-P0-01-001 | end_to_end | Complete the founder-visible workflow for canonical schema and migrations with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.2
phase: 0
title: "Domain services and event system"
status: drafted
dependencies: ["WP0.1"]
primary_team: foundation
risk: critical
---

# WP0.2 - Domain services and event system

## Objective

Implement domain services and event system as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.1

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for domain services and event system
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-2-REQ-001:** The system shall implement domain services and event system using existing repository conventions and shared FOS contracts.
- **0-2-REQ-002:** The implementation shall expose versioned, validated interfaces for domain services and event system and preserve backward compatibility or provide an explicit migration.
- **0-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to domain services and event system shall be enforced deterministically.
- **0-2-REQ-004:** All consequential operations in domain services and event system shall be auditable through correlation-aware events and immutable or versioned records.
- **0-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for domain services and event system.
- **0-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for domain services and event system.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-02-001 | unit | Validate core rules and schemas for domain services and event system. | pull_request |
| IT-P0-02-001 | integration | Verify domain services and event system integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-02-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in domain services and event system. | merge |
| OBS-P0-02-001 | observability | Emit required events, metrics, traces, and correlation identifiers for domain services and event system. | merge |
| E2E-P0-02-001 | end_to_end | Complete the founder-visible workflow for domain services and event system with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.3
phase: 0
title: "Workspace provider interface and Notion adapter"
status: drafted
dependencies: ["WP0A", "WP0.2"]
primary_team: foundation
risk: medium
---

# WP0.3 - Workspace provider interface and Notion adapter

## Objective

Implement workspace provider interface and notion adapter as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0A
- WP0.2

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for workspace provider interface and notion adapter
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-3-REQ-001:** The system shall implement workspace provider interface and notion adapter using existing repository conventions and shared FOS contracts.
- **0-3-REQ-002:** The implementation shall expose versioned, validated interfaces for workspace provider interface and notion adapter and preserve backward compatibility or provide an explicit migration.
- **0-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to workspace provider interface and notion adapter shall be enforced deterministically.
- **0-3-REQ-004:** All consequential operations in workspace provider interface and notion adapter shall be auditable through correlation-aware events and immutable or versioned records.
- **0-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for workspace provider interface and notion adapter.
- **0-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for workspace provider interface and notion adapter.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-03-001 | unit | Validate core rules and schemas for workspace provider interface and notion adapter. | pull_request |
| IT-P0-03-001 | integration | Verify workspace provider interface and notion adapter integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-03-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in workspace provider interface and notion adapter. | merge |
| OBS-P0-03-001 | observability | Emit required events, metrics, traces, and correlation identifiers for workspace provider interface and notion adapter. | merge |
| E2E-P0-03-001 | end_to_end | Complete the founder-visible workflow for workspace provider interface and notion adapter with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.4
phase: 0
title: "Collection bootstrap and mappings"
status: drafted
dependencies: ["WP0.3"]
primary_team: foundation
risk: medium
---

# WP0.4 - Collection bootstrap and mappings

## Objective

Implement collection bootstrap and mappings as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.3

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for collection bootstrap and mappings
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-4-REQ-001:** The system shall implement collection bootstrap and mappings using existing repository conventions and shared FOS contracts.
- **0-4-REQ-002:** The implementation shall expose versioned, validated interfaces for collection bootstrap and mappings and preserve backward compatibility or provide an explicit migration.
- **0-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to collection bootstrap and mappings shall be enforced deterministically.
- **0-4-REQ-004:** All consequential operations in collection bootstrap and mappings shall be auditable through correlation-aware events and immutable or versioned records.
- **0-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for collection bootstrap and mappings.
- **0-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for collection bootstrap and mappings.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-04-001 | unit | Validate core rules and schemas for collection bootstrap and mappings. | pull_request |
| IT-P0-04-001 | integration | Verify collection bootstrap and mappings integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-04-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in collection bootstrap and mappings. | merge |
| OBS-P0-04-001 | observability | Emit required events, metrics, traces, and correlation identifiers for collection bootstrap and mappings. | merge |
| E2E-P0-04-001 | end_to_end | Complete the founder-visible workflow for collection bootstrap and mappings with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.5
phase: 0
title: "Read-only projections"
status: drafted
dependencies: ["WP0.2", "WP0.4"]
primary_team: foundation
risk: medium
---

# WP0.5 - Read-only projections

## Objective

Implement read-only projections as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.2
- WP0.4

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for read-only projections
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-5-REQ-001:** The system shall implement read-only projections using existing repository conventions and shared FOS contracts.
- **0-5-REQ-002:** The implementation shall expose versioned, validated interfaces for read-only projections and preserve backward compatibility or provide an explicit migration.
- **0-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to read-only projections shall be enforced deterministically.
- **0-5-REQ-004:** All consequential operations in read-only projections shall be auditable through correlation-aware events and immutable or versioned records.
- **0-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for read-only projections.
- **0-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for read-only projections.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-05-001 | unit | Validate core rules and schemas for read-only projections. | pull_request |
| IT-P0-05-001 | integration | Verify read-only projections integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-05-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in read-only projections. | merge |
| OBS-P0-05-001 | observability | Emit required events, metrics, traces, and correlation identifiers for read-only projections. | merge |
| E2E-P0-05-001 | end_to_end | Complete the founder-visible workflow for read-only projections with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.6
phase: 0
title: "Webhooks, edit capture, and controlled commands"
status: drafted
dependencies: ["WP0.2", "WP0.5"]
primary_team: foundation
risk: high
---

# WP0.6 - Webhooks, edit capture, and controlled commands

## Objective

Implement webhooks, edit capture, and controlled commands as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.2
- WP0.5

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for webhooks, edit capture, and controlled commands
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-6-REQ-001:** The system shall implement webhooks, edit capture, and controlled commands using existing repository conventions and shared FOS contracts.
- **0-6-REQ-002:** The implementation shall expose versioned, validated interfaces for webhooks, edit capture, and controlled commands and preserve backward compatibility or provide an explicit migration.
- **0-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to webhooks, edit capture, and controlled commands shall be enforced deterministically.
- **0-6-REQ-004:** All consequential operations in webhooks, edit capture, and controlled commands shall be auditable through correlation-aware events and immutable or versioned records.
- **0-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for webhooks, edit capture, and controlled commands.
- **0-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for webhooks, edit capture, and controlled commands.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-06-001 | unit | Validate core rules and schemas for webhooks, edit capture, and controlled commands. | pull_request |
| IT-P0-06-001 | integration | Verify webhooks, edit capture, and controlled commands integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-06-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in webhooks, edit capture, and controlled commands. | merge |
| OBS-P0-06-001 | observability | Emit required events, metrics, traces, and correlation identifiers for webhooks, edit capture, and controlled commands. | merge |
| E2E-P0-06-001 | end_to_end | Complete the founder-visible workflow for webhooks, edit capture, and controlled commands with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.7
phase: 0
title: "Approval bridge and action boundaries"
status: drafted
dependencies: ["WP0.2", "WP0.6"]
primary_team: foundation
risk: critical
---

# WP0.7 - Approval bridge and action boundaries

## Objective

Implement approval bridge and action boundaries as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.2
- WP0.6

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for approval bridge and action boundaries
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-7-REQ-001:** The system shall implement approval bridge and action boundaries using existing repository conventions and shared FOS contracts.
- **0-7-REQ-002:** The implementation shall expose versioned, validated interfaces for approval bridge and action boundaries and preserve backward compatibility or provide an explicit migration.
- **0-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to approval bridge and action boundaries shall be enforced deterministically.
- **0-7-REQ-004:** All consequential operations in approval bridge and action boundaries shall be auditable through correlation-aware events and immutable or versioned records.
- **0-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for approval bridge and action boundaries.
- **0-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for approval bridge and action boundaries.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-07-001 | unit | Validate core rules and schemas for approval bridge and action boundaries. | pull_request |
| IT-P0-07-001 | integration | Verify approval bridge and action boundaries integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-07-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in approval bridge and action boundaries. | merge |
| OBS-P0-07-001 | observability | Emit required events, metrics, traces, and correlation identifiers for approval bridge and action boundaries. | merge |
| E2E-P0-07-001 | end_to_end | Complete the founder-visible workflow for approval bridge and action boundaries with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.8
phase: 0
title: "Communications and campaign foundation"
status: drafted
dependencies: ["WP0.1", "WP0.2", "WP0.7"]
primary_team: foundation
risk: medium
---

# WP0.8 - Communications and campaign foundation

## Objective

Implement communications and campaign foundation as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.1
- WP0.2
- WP0.7

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for communications and campaign foundation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-8-REQ-001:** The system shall implement communications and campaign foundation using existing repository conventions and shared FOS contracts.
- **0-8-REQ-002:** The implementation shall expose versioned, validated interfaces for communications and campaign foundation and preserve backward compatibility or provide an explicit migration.
- **0-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to communications and campaign foundation shall be enforced deterministically.
- **0-8-REQ-004:** All consequential operations in communications and campaign foundation shall be auditable through correlation-aware events and immutable or versioned records.
- **0-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for communications and campaign foundation.
- **0-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for communications and campaign foundation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-08-001 | unit | Validate core rules and schemas for communications and campaign foundation. | pull_request |
| IT-P0-08-001 | integration | Verify communications and campaign foundation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-08-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in communications and campaign foundation. | merge |
| OBS-P0-08-001 | observability | Emit required events, metrics, traces, and correlation identifiers for communications and campaign foundation. | merge |
| E2E-P0-08-001 | end_to_end | Complete the founder-visible workflow for communications and campaign foundation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.9
phase: 0
title: "Integration health, reconciliation, and metrics"
status: drafted
dependencies: ["WP0.3", "WP0.4", "WP0.5", "WP0.6", "WP0.7", "WP0.8"]
primary_team: foundation
risk: high
---

# WP0.9 - Integration health, reconciliation, and metrics

## Objective

Implement integration health, reconciliation, and metrics as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.3
- WP0.4
- WP0.5
- WP0.6
- WP0.7
- WP0.8

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for integration health, reconciliation, and metrics
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-9-REQ-001:** The system shall implement integration health, reconciliation, and metrics using existing repository conventions and shared FOS contracts.
- **0-9-REQ-002:** The implementation shall expose versioned, validated interfaces for integration health, reconciliation, and metrics and preserve backward compatibility or provide an explicit migration.
- **0-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to integration health, reconciliation, and metrics shall be enforced deterministically.
- **0-9-REQ-004:** All consequential operations in integration health, reconciliation, and metrics shall be auditable through correlation-aware events and immutable or versioned records.
- **0-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for integration health, reconciliation, and metrics.
- **0-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for integration health, reconciliation, and metrics.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-09-001 | unit | Validate core rules and schemas for integration health, reconciliation, and metrics. | pull_request |
| IT-P0-09-001 | integration | Verify integration health, reconciliation, and metrics integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-09-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in integration health, reconciliation, and metrics. | merge |
| OBS-P0-09-001 | observability | Emit required events, metrics, traces, and correlation identifiers for integration health, reconciliation, and metrics. | merge |
| E2E-P0-09-001 | end_to_end | Complete the founder-visible workflow for integration health, reconciliation, and metrics with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP0.10
phase: 0
title: "Test suite, deployment, and handoff"
status: drafted
dependencies: ["WP0.1", "WP0.2", "WP0.3", "WP0.4", "WP0.5", "WP0.6", "WP0.7", "WP0.8", "WP0.9"]
primary_team: foundation
risk: medium
---

# WP0.10 - Test suite, deployment, and handoff

## Objective

Implement test suite, deployment, and handoff as a bounded, testable vertical slice that conforms to the revised Phase 0 specification and shared FOS contracts.

## Business value

This packet advances **Phase 0: Founder Workspace and Operating Foundation** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.1
- WP0.2
- WP0.3
- WP0.4
- WP0.5
- WP0.6
- WP0.7
- WP0.8
- WP0.9

## Required inputs

- Revised Phase 0 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for test suite, deployment, and handoff
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **0-10-REQ-001:** The system shall implement test suite, deployment, and handoff using existing repository conventions and shared FOS contracts.
- **0-10-REQ-002:** The implementation shall expose versioned, validated interfaces for test suite, deployment, and handoff and preserve backward compatibility or provide an explicit migration.
- **0-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to test suite, deployment, and handoff shall be enforced deterministically.
- **0-10-REQ-004:** All consequential operations in test suite, deployment, and handoff shall be auditable through correlation-aware events and immutable or versioned records.
- **0-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for test suite, deployment, and handoff.
- **0-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for test suite, deployment, and handoff.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P0-010-001 | unit | Validate core rules and schemas for test suite, deployment, and handoff. | pull_request |
| IT-P0-010-001 | integration | Verify test suite, deployment, and handoff integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P0-010-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in test suite, deployment, and handoff. | merge |
| OBS-P0-010-001 | observability | Emit required events, metrics, traces, and correlation identifiers for test suite, deployment, and handoff. | merge |
| E2E-P0-010-001 | end_to_end | Complete the founder-visible workflow for test suite, deployment, and handoff with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.0
phase: 1
title: "Phase 0 contract verification and migration"
status: drafted
dependencies: ["WP0.10"]
primary_team: enrollment
risk: critical
---

# WP1.0 - Phase 0 contract verification and migration

## Objective

Implement phase 0 contract verification and migration as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.10

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for phase 0 contract verification and migration
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-0-REQ-001:** The system shall implement phase 0 contract verification and migration using existing repository conventions and shared FOS contracts.
- **1-0-REQ-002:** The implementation shall expose versioned, validated interfaces for phase 0 contract verification and migration and preserve backward compatibility or provide an explicit migration.
- **1-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to phase 0 contract verification and migration shall be enforced deterministically.
- **1-0-REQ-004:** All consequential operations in phase 0 contract verification and migration shall be auditable through correlation-aware events and immutable or versioned records.
- **1-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for phase 0 contract verification and migration.
- **1-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for phase 0 contract verification and migration.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-10-001 | unit | Validate core rules and schemas for phase 0 contract verification and migration. | pull_request |
| IT-P1-10-001 | integration | Verify phase 0 contract verification and migration integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-10-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in phase 0 contract verification and migration. | merge |
| OBS-P1-10-001 | observability | Emit required events, metrics, traces, and correlation identifiers for phase 0 contract verification and migration. | merge |
| E2E-P1-10-001 | end_to_end | Complete the founder-visible workflow for phase 0 contract verification and migration with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.1
phase: 1
title: "Opportunity and attribution extensions"
status: drafted
dependencies: ["WP1.0"]
primary_team: enrollment
risk: high
---

# WP1.1 - Opportunity and attribution extensions

## Objective

Implement opportunity and attribution extensions as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.0

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for opportunity and attribution extensions
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-1-REQ-001:** The system shall implement opportunity and attribution extensions using existing repository conventions and shared FOS contracts.
- **1-1-REQ-002:** The implementation shall expose versioned, validated interfaces for opportunity and attribution extensions and preserve backward compatibility or provide an explicit migration.
- **1-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to opportunity and attribution extensions shall be enforced deterministically.
- **1-1-REQ-004:** All consequential operations in opportunity and attribution extensions shall be auditable through correlation-aware events and immutable or versioned records.
- **1-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for opportunity and attribution extensions.
- **1-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for opportunity and attribution extensions.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-11-001 | unit | Validate core rules and schemas for opportunity and attribution extensions. | pull_request |
| IT-P1-11-001 | integration | Verify opportunity and attribution extensions integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-11-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in opportunity and attribution extensions. | merge |
| OBS-P1-11-001 | observability | Emit required events, metrics, traces, and correlation identifiers for opportunity and attribution extensions. | merge |
| E2E-P1-11-001 | end_to_end | Complete the founder-visible workflow for opportunity and attribution extensions with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.2
phase: 1
title: "Enrollment agent runtime and assessments"
status: drafted
dependencies: ["WP1.0", "WP1.1"]
primary_team: enrollment
risk: high
---

# WP1.2 - Enrollment agent runtime and assessments

## Objective

Implement enrollment agent runtime and assessments as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.0
- WP1.1

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for enrollment agent runtime and assessments
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-2-REQ-001:** The system shall implement enrollment agent runtime and assessments using existing repository conventions and shared FOS contracts.
- **1-2-REQ-002:** The implementation shall expose versioned, validated interfaces for enrollment agent runtime and assessments and preserve backward compatibility or provide an explicit migration.
- **1-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to enrollment agent runtime and assessments shall be enforced deterministically.
- **1-2-REQ-004:** All consequential operations in enrollment agent runtime and assessments shall be auditable through correlation-aware events and immutable or versioned records.
- **1-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for enrollment agent runtime and assessments.
- **1-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for enrollment agent runtime and assessments.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-12-001 | unit | Validate core rules and schemas for enrollment agent runtime and assessments. | pull_request |
| IT-P1-12-001 | integration | Verify enrollment agent runtime and assessments integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-12-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in enrollment agent runtime and assessments. | merge |
| OBS-P1-12-001 | observability | Emit required events, metrics, traces, and correlation identifiers for enrollment agent runtime and assessments. | merge |
| E2E-P1-12-001 | end_to_end | Complete the founder-visible workflow for enrollment agent runtime and assessments with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.3
phase: 1
title: "Call and post-call workflows"
status: drafted
dependencies: ["WP1.2"]
primary_team: enrollment
risk: medium
---

# WP1.3 - Call and post-call workflows

## Objective

Implement call and post-call workflows as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.2

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for call and post-call workflows
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-3-REQ-001:** The system shall implement call and post-call workflows using existing repository conventions and shared FOS contracts.
- **1-3-REQ-002:** The implementation shall expose versioned, validated interfaces for call and post-call workflows and preserve backward compatibility or provide an explicit migration.
- **1-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to call and post-call workflows shall be enforced deterministically.
- **1-3-REQ-004:** All consequential operations in call and post-call workflows shall be auditable through correlation-aware events and immutable or versioned records.
- **1-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for call and post-call workflows.
- **1-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for call and post-call workflows.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-13-001 | unit | Validate core rules and schemas for call and post-call workflows. | pull_request |
| IT-P1-13-001 | integration | Verify call and post-call workflows integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-13-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in call and post-call workflows. | merge |
| OBS-P1-13-001 | observability | Emit required events, metrics, traces, and correlation identifiers for call and post-call workflows. | merge |
| E2E-P1-13-001 | end_to_end | Complete the founder-visible workflow for call and post-call workflows with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.4
phase: 1
title: "Follow-up, objections, and next actions"
status: drafted
dependencies: ["WP1.2", "WP1.3"]
primary_team: enrollment
risk: medium
---

# WP1.4 - Follow-up, objections, and next actions

## Objective

Implement follow-up, objections, and next actions as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.2
- WP1.3

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for follow-up, objections, and next actions
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-4-REQ-001:** The system shall implement follow-up, objections, and next actions using existing repository conventions and shared FOS contracts.
- **1-4-REQ-002:** The implementation shall expose versioned, validated interfaces for follow-up, objections, and next actions and preserve backward compatibility or provide an explicit migration.
- **1-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to follow-up, objections, and next actions shall be enforced deterministically.
- **1-4-REQ-004:** All consequential operations in follow-up, objections, and next actions shall be auditable through correlation-aware events and immutable or versioned records.
- **1-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for follow-up, objections, and next actions.
- **1-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for follow-up, objections, and next actions.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-14-001 | unit | Validate core rules and schemas for follow-up, objections, and next actions. | pull_request |
| IT-P1-14-001 | integration | Verify follow-up, objections, and next actions integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-14-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in follow-up, objections, and next actions. | merge |
| OBS-P1-14-001 | observability | Emit required events, metrics, traces, and correlation identifiers for follow-up, objections, and next actions. | merge |
| E2E-P1-14-001 | end_to_end | Complete the founder-visible workflow for follow-up, objections, and next actions with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.5
phase: 1
title: "Enrollment Pipeline and Founder Inbox projections"
status: drafted
dependencies: ["WP1.1", "WP1.4"]
primary_team: enrollment
risk: medium
---

# WP1.5 - Enrollment Pipeline and Founder Inbox projections

## Objective

Implement enrollment pipeline and founder inbox projections as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.1
- WP1.4

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for enrollment pipeline and founder inbox projections
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-5-REQ-001:** The system shall implement enrollment pipeline and founder inbox projections using existing repository conventions and shared FOS contracts.
- **1-5-REQ-002:** The implementation shall expose versioned, validated interfaces for enrollment pipeline and founder inbox projections and preserve backward compatibility or provide an explicit migration.
- **1-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to enrollment pipeline and founder inbox projections shall be enforced deterministically.
- **1-5-REQ-004:** All consequential operations in enrollment pipeline and founder inbox projections shall be auditable through correlation-aware events and immutable or versioned records.
- **1-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for enrollment pipeline and founder inbox projections.
- **1-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for enrollment pipeline and founder inbox projections.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-15-001 | unit | Validate core rules and schemas for enrollment pipeline and founder inbox projections. | pull_request |
| IT-P1-15-001 | integration | Verify enrollment pipeline and founder inbox projections integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-15-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in enrollment pipeline and founder inbox projections. | merge |
| OBS-P1-15-001 | observability | Emit required events, metrics, traces, and correlation identifiers for enrollment pipeline and founder inbox projections. | merge |
| E2E-P1-15-001 | end_to_end | Complete the founder-visible workflow for enrollment pipeline and founder inbox projections with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.6
phase: 1
title: "Beta launch campaign model and source brief"
status: drafted
dependencies: ["WP1.0", "WP0.8"]
primary_team: enrollment
risk: medium
---

# WP1.6 - Beta launch campaign model and source brief

## Objective

Implement beta launch campaign model and source brief as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.0
- WP0.8

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for beta launch campaign model and source brief
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-6-REQ-001:** The system shall implement beta launch campaign model and source brief using existing repository conventions and shared FOS contracts.
- **1-6-REQ-002:** The implementation shall expose versioned, validated interfaces for beta launch campaign model and source brief and preserve backward compatibility or provide an explicit migration.
- **1-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to beta launch campaign model and source brief shall be enforced deterministically.
- **1-6-REQ-004:** All consequential operations in beta launch campaign model and source brief shall be auditable through correlation-aware events and immutable or versioned records.
- **1-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for beta launch campaign model and source brief.
- **1-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for beta launch campaign model and source brief.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-16-001 | unit | Validate core rules and schemas for beta launch campaign model and source brief. | pull_request |
| IT-P1-16-001 | integration | Verify beta launch campaign model and source brief integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-16-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in beta launch campaign model and source brief. | merge |
| OBS-P1-16-001 | observability | Emit required events, metrics, traces, and correlation identifiers for beta launch campaign model and source brief. | merge |
| E2E-P1-16-001 | end_to_end | Complete the founder-visible workflow for beta launch campaign model and source brief with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.7
phase: 1
title: "LinkedIn, Substack, email, webinar, and landing-page artifacts"
status: drafted
dependencies: ["WP1.6"]
primary_team: enrollment
risk: medium
---

# WP1.7 - LinkedIn, Substack, email, webinar, and landing-page artifacts

## Objective

Implement linkedin, substack, email, webinar, and landing-page artifacts as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.6

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for linkedin, substack, email, webinar, and landing-page artifacts
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-7-REQ-001:** The system shall implement linkedin, substack, email, webinar, and landing-page artifacts using existing repository conventions and shared FOS contracts.
- **1-7-REQ-002:** The implementation shall expose versioned, validated interfaces for linkedin, substack, email, webinar, and landing-page artifacts and preserve backward compatibility or provide an explicit migration.
- **1-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to linkedin, substack, email, webinar, and landing-page artifacts shall be enforced deterministically.
- **1-7-REQ-004:** All consequential operations in linkedin, substack, email, webinar, and landing-page artifacts shall be auditable through correlation-aware events and immutable or versioned records.
- **1-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for linkedin, substack, email, webinar, and landing-page artifacts.
- **1-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for linkedin, substack, email, webinar, and landing-page artifacts.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-17-001 | unit | Validate core rules and schemas for linkedin, substack, email, webinar, and landing-page artifacts. | pull_request |
| IT-P1-17-001 | integration | Verify linkedin, substack, email, webinar, and landing-page artifacts integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-17-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in linkedin, substack, email, webinar, and landing-page artifacts. | merge |
| OBS-P1-17-001 | observability | Emit required events, metrics, traces, and correlation identifiers for linkedin, substack, email, webinar, and landing-page artifacts. | merge |
| E2E-P1-17-001 | end_to_end | Complete the founder-visible workflow for linkedin, substack, email, webinar, and landing-page artifacts with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.8
phase: 1
title: "Claims, consent, and platform-draft gates"
status: drafted
dependencies: ["WP1.7", "WP0.7", "WP0.8"]
primary_team: enrollment
risk: critical
---

# WP1.8 - Claims, consent, and platform-draft gates

## Objective

Implement claims, consent, and platform-draft gates as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.7
- WP0.7
- WP0.8

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for claims, consent, and platform-draft gates
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-8-REQ-001:** The system shall implement claims, consent, and platform-draft gates using existing repository conventions and shared FOS contracts.
- **1-8-REQ-002:** The implementation shall expose versioned, validated interfaces for claims, consent, and platform-draft gates and preserve backward compatibility or provide an explicit migration.
- **1-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to claims, consent, and platform-draft gates shall be enforced deterministically.
- **1-8-REQ-004:** All consequential operations in claims, consent, and platform-draft gates shall be auditable through correlation-aware events and immutable or versioned records.
- **1-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for claims, consent, and platform-draft gates.
- **1-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for claims, consent, and platform-draft gates.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-18-001 | unit | Validate core rules and schemas for claims, consent, and platform-draft gates. | pull_request |
| IT-P1-18-001 | integration | Verify claims, consent, and platform-draft gates integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-18-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in claims, consent, and platform-draft gates. | merge |
| OBS-P1-18-001 | observability | Emit required events, metrics, traces, and correlation identifiers for claims, consent, and platform-draft gates. | merge |
| E2E-P1-18-001 | end_to_end | Complete the founder-visible workflow for claims, consent, and platform-draft gates with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.9
phase: 1
title: "Funnel, campaign attribution, founder-time dashboards"
status: drafted
dependencies: ["WP1.1", "WP1.5", "WP1.6", "WP1.7"]
primary_team: enrollment
risk: high
---

# WP1.9 - Funnel, campaign attribution, founder-time dashboards

## Objective

Implement funnel, campaign attribution, founder-time dashboards as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.1
- WP1.5
- WP1.6
- WP1.7

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for funnel, campaign attribution, founder-time dashboards
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-9-REQ-001:** The system shall implement funnel, campaign attribution, founder-time dashboards using existing repository conventions and shared FOS contracts.
- **1-9-REQ-002:** The implementation shall expose versioned, validated interfaces for funnel, campaign attribution, founder-time dashboards and preserve backward compatibility or provide an explicit migration.
- **1-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to funnel, campaign attribution, founder-time dashboards shall be enforced deterministically.
- **1-9-REQ-004:** All consequential operations in funnel, campaign attribution, founder-time dashboards shall be auditable through correlation-aware events and immutable or versioned records.
- **1-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for funnel, campaign attribution, founder-time dashboards.
- **1-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for funnel, campaign attribution, founder-time dashboards.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-19-001 | unit | Validate core rules and schemas for funnel, campaign attribution, founder-time dashboards. | pull_request |
| IT-P1-19-001 | integration | Verify funnel, campaign attribution, founder-time dashboards integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-19-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in funnel, campaign attribution, founder-time dashboards. | merge |
| OBS-P1-19-001 | observability | Emit required events, metrics, traces, and correlation identifiers for funnel, campaign attribution, founder-time dashboards. | merge |
| E2E-P1-19-001 | end_to_end | Complete the founder-visible workflow for funnel, campaign attribution, founder-time dashboards with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP1.10
phase: 1
title: "Evaluation, shadow mode, and production activation"
status: drafted
dependencies: ["WP1.2", "WP1.3", "WP1.4", "WP1.5", "WP1.6", "WP1.7", "WP1.8", "WP1.9"]
primary_team: enrollment
risk: medium
---

# WP1.10 - Evaluation, shadow mode, and production activation

## Objective

Implement evaluation, shadow mode, and production activation as a bounded, testable vertical slice that conforms to the revised Phase 1 specification and shared FOS contracts.

## Business value

This packet advances **Phase 1: Enrollment Revenue and Beta Launch Communications** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.2
- WP1.3
- WP1.4
- WP1.5
- WP1.6
- WP1.7
- WP1.8
- WP1.9

## Required inputs

- Revised Phase 1 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for evaluation, shadow mode, and production activation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **1-10-REQ-001:** The system shall implement evaluation, shadow mode, and production activation using existing repository conventions and shared FOS contracts.
- **1-10-REQ-002:** The implementation shall expose versioned, validated interfaces for evaluation, shadow mode, and production activation and preserve backward compatibility or provide an explicit migration.
- **1-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to evaluation, shadow mode, and production activation shall be enforced deterministically.
- **1-10-REQ-004:** All consequential operations in evaluation, shadow mode, and production activation shall be auditable through correlation-aware events and immutable or versioned records.
- **1-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for evaluation, shadow mode, and production activation.
- **1-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for evaluation, shadow mode, and production activation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P1-110-001 | unit | Validate core rules and schemas for evaluation, shadow mode, and production activation. | pull_request |
| IT-P1-110-001 | integration | Verify evaluation, shadow mode, and production activation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P1-110-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in evaluation, shadow mode, and production activation. | merge |
| OBS-P1-110-001 | observability | Emit required events, metrics, traces, and correlation identifiers for evaluation, shadow mode, and production activation. | merge |
| E2E-P1-110-001 | end_to_end | Complete the founder-visible workflow for evaluation, shadow mode, and production activation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.0
phase: 2
title: "Phase 1 enrollment-to-beta handoff"
status: drafted
dependencies: ["WP1.10"]
primary_team: beta_operations
risk: medium
---

# WP2.0 - Phase 1 enrollment-to-beta handoff

## Objective

Implement phase 1 enrollment-to-beta handoff as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.10

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for phase 1 enrollment-to-beta handoff
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-0-REQ-001:** The system shall implement phase 1 enrollment-to-beta handoff using existing repository conventions and shared FOS contracts.
- **2-0-REQ-002:** The implementation shall expose versioned, validated interfaces for phase 1 enrollment-to-beta handoff and preserve backward compatibility or provide an explicit migration.
- **2-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to phase 1 enrollment-to-beta handoff shall be enforced deterministically.
- **2-0-REQ-004:** All consequential operations in phase 1 enrollment-to-beta handoff shall be auditable through correlation-aware events and immutable or versioned records.
- **2-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for phase 1 enrollment-to-beta handoff.
- **2-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for phase 1 enrollment-to-beta handoff.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-20-001 | unit | Validate core rules and schemas for phase 1 enrollment-to-beta handoff. | pull_request |
| IT-P2-20-001 | integration | Verify phase 1 enrollment-to-beta handoff integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-20-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in phase 1 enrollment-to-beta handoff. | merge |
| OBS-P2-20-001 | observability | Emit required events, metrics, traces, and correlation identifiers for phase 1 enrollment-to-beta handoff. | merge |
| E2E-P2-20-001 | end_to_end | Complete the founder-visible workflow for phase 1 enrollment-to-beta handoff with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.1
phase: 2
title: "Beta domain schema and migration"
status: drafted
dependencies: ["WP2.0"]
primary_team: beta_operations
risk: critical
---

# WP2.1 - Beta domain schema and migration

## Objective

Implement beta domain schema and migration as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.0

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for beta domain schema and migration
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-1-REQ-001:** The system shall implement beta domain schema and migration using existing repository conventions and shared FOS contracts.
- **2-1-REQ-002:** The implementation shall expose versioned, validated interfaces for beta domain schema and migration and preserve backward compatibility or provide an explicit migration.
- **2-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to beta domain schema and migration shall be enforced deterministically.
- **2-1-REQ-004:** All consequential operations in beta domain schema and migration shall be auditable through correlation-aware events and immutable or versioned records.
- **2-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for beta domain schema and migration.
- **2-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for beta domain schema and migration.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-21-001 | unit | Validate core rules and schemas for beta domain schema and migration. | pull_request |
| IT-P2-21-001 | integration | Verify beta domain schema and migration integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-21-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in beta domain schema and migration. | merge |
| OBS-P2-21-001 | observability | Emit required events, metrics, traces, and correlation identifiers for beta domain schema and migration. | merge |
| E2E-P2-21-001 | end_to_end | Complete the founder-visible workflow for beta domain schema and migration with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.2
phase: 2
title: "Onboarding artifacts and milestones"
status: drafted
dependencies: ["WP2.1"]
primary_team: beta_operations
risk: medium
---

# WP2.2 - Onboarding artifacts and milestones

## Objective

Implement onboarding artifacts and milestones as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.1

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for onboarding artifacts and milestones
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-2-REQ-001:** The system shall implement onboarding artifacts and milestones using existing repository conventions and shared FOS contracts.
- **2-2-REQ-002:** The implementation shall expose versioned, validated interfaces for onboarding artifacts and milestones and preserve backward compatibility or provide an explicit migration.
- **2-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to onboarding artifacts and milestones shall be enforced deterministically.
- **2-2-REQ-004:** All consequential operations in onboarding artifacts and milestones shall be auditable through correlation-aware events and immutable or versioned records.
- **2-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for onboarding artifacts and milestones.
- **2-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for onboarding artifacts and milestones.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-22-001 | unit | Validate core rules and schemas for onboarding artifacts and milestones. | pull_request |
| IT-P2-22-001 | integration | Verify onboarding artifacts and milestones integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-22-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in onboarding artifacts and milestones. | merge |
| OBS-P2-22-001 | observability | Emit required events, metrics, traces, and correlation identifiers for onboarding artifacts and milestones. | merge |
| E2E-P2-22-001 | end_to_end | Complete the founder-visible workflow for onboarding artifacts and milestones with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.3
phase: 2
title: "Product activity and first-value instrumentation"
status: drafted
dependencies: ["WP2.1"]
primary_team: beta_operations
risk: medium
---

# WP2.3 - Product activity and first-value instrumentation

## Objective

Implement product activity and first-value instrumentation as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.1

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for product activity and first-value instrumentation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-3-REQ-001:** The system shall implement product activity and first-value instrumentation using existing repository conventions and shared FOS contracts.
- **2-3-REQ-002:** The implementation shall expose versioned, validated interfaces for product activity and first-value instrumentation and preserve backward compatibility or provide an explicit migration.
- **2-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to product activity and first-value instrumentation shall be enforced deterministically.
- **2-3-REQ-004:** All consequential operations in product activity and first-value instrumentation shall be auditable through correlation-aware events and immutable or versioned records.
- **2-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for product activity and first-value instrumentation.
- **2-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for product activity and first-value instrumentation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-23-001 | unit | Validate core rules and schemas for product activity and first-value instrumentation. | pull_request |
| IT-P2-23-001 | integration | Verify product activity and first-value instrumentation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-23-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in product activity and first-value instrumentation. | merge |
| OBS-P2-23-001 | observability | Emit required events, metrics, traces, and correlation identifiers for product activity and first-value instrumentation. | merge |
| E2E-P2-23-001 | end_to_end | Complete the founder-visible workflow for product activity and first-value instrumentation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.4
phase: 2
title: "Explainable health engine"
status: drafted
dependencies: ["WP2.3"]
primary_team: beta_operations
risk: high
---

# WP2.4 - Explainable health engine

## Objective

Implement explainable health engine as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.3

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for explainable health engine
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-4-REQ-001:** The system shall implement explainable health engine using existing repository conventions and shared FOS contracts.
- **2-4-REQ-002:** The implementation shall expose versioned, validated interfaces for explainable health engine and preserve backward compatibility or provide an explicit migration.
- **2-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to explainable health engine shall be enforced deterministically.
- **2-4-REQ-004:** All consequential operations in explainable health engine shall be auditable through correlation-aware events and immutable or versioned records.
- **2-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for explainable health engine.
- **2-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for explainable health engine.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-24-001 | unit | Validate core rules and schemas for explainable health engine. | pull_request |
| IT-P2-24-001 | integration | Verify explainable health engine integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-24-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in explainable health engine. | merge |
| OBS-P2-24-001 | observability | Emit required events, metrics, traces, and correlation identifiers for explainable health engine. | merge |
| E2E-P2-24-001 | end_to_end | Complete the founder-visible workflow for explainable health engine with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.5
phase: 2
title: "Support queue and triage"
status: drafted
dependencies: ["WP2.1"]
primary_team: beta_operations
risk: medium
---

# WP2.5 - Support queue and triage

## Objective

Implement support queue and triage as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.1

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for support queue and triage
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-5-REQ-001:** The system shall implement support queue and triage using existing repository conventions and shared FOS contracts.
- **2-5-REQ-002:** The implementation shall expose versioned, validated interfaces for support queue and triage and preserve backward compatibility or provide an explicit migration.
- **2-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to support queue and triage shall be enforced deterministically.
- **2-5-REQ-004:** All consequential operations in support queue and triage shall be auditable through correlation-aware events and immutable or versioned records.
- **2-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for support queue and triage.
- **2-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for support queue and triage.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-25-001 | unit | Validate core rules and schemas for support queue and triage. | pull_request |
| IT-P2-25-001 | integration | Verify support queue and triage integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-25-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in support queue and triage. | merge |
| OBS-P2-25-001 | observability | Emit required events, metrics, traces, and correlation identifiers for support queue and triage. | merge |
| E2E-P2-25-001 | end_to_end | Complete the founder-visible workflow for support queue and triage with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.6
phase: 2
title: "Outcome, consent, testimonial, and referral workflows"
status: drafted
dependencies: ["WP2.2", "WP2.5"]
primary_team: beta_operations
risk: critical
---

# WP2.6 - Outcome, consent, testimonial, and referral workflows

## Objective

Implement outcome, consent, testimonial, and referral workflows as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.2
- WP2.5

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for outcome, consent, testimonial, and referral workflows
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-6-REQ-001:** The system shall implement outcome, consent, testimonial, and referral workflows using existing repository conventions and shared FOS contracts.
- **2-6-REQ-002:** The implementation shall expose versioned, validated interfaces for outcome, consent, testimonial, and referral workflows and preserve backward compatibility or provide an explicit migration.
- **2-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to outcome, consent, testimonial, and referral workflows shall be enforced deterministically.
- **2-6-REQ-004:** All consequential operations in outcome, consent, testimonial, and referral workflows shall be auditable through correlation-aware events and immutable or versioned records.
- **2-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for outcome, consent, testimonial, and referral workflows.
- **2-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for outcome, consent, testimonial, and referral workflows.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-26-001 | unit | Validate core rules and schemas for outcome, consent, testimonial, and referral workflows. | pull_request |
| IT-P2-26-001 | integration | Verify outcome, consent, testimonial, and referral workflows integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-26-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in outcome, consent, testimonial, and referral workflows. | merge |
| OBS-P2-26-001 | observability | Emit required events, metrics, traces, and correlation identifiers for outcome, consent, testimonial, and referral workflows. | merge |
| E2E-P2-26-001 | end_to_end | Complete the founder-visible workflow for outcome, consent, testimonial, and referral workflows with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.7
phase: 2
title: "Weekly editorial-cycle model"
status: drafted
dependencies: ["WP2.0", "WP0.8"]
primary_team: beta_operations
risk: medium
---

# WP2.7 - Weekly editorial-cycle model

## Objective

Implement weekly editorial-cycle model as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.0
- WP0.8

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for weekly editorial-cycle model
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-7-REQ-001:** The system shall implement weekly editorial-cycle model using existing repository conventions and shared FOS contracts.
- **2-7-REQ-002:** The implementation shall expose versioned, validated interfaces for weekly editorial-cycle model and preserve backward compatibility or provide an explicit migration.
- **2-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to weekly editorial-cycle model shall be enforced deterministically.
- **2-7-REQ-004:** All consequential operations in weekly editorial-cycle model shall be auditable through correlation-aware events and immutable or versioned records.
- **2-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for weekly editorial-cycle model.
- **2-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for weekly editorial-cycle model.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-27-001 | unit | Validate core rules and schemas for weekly editorial-cycle model. | pull_request |
| IT-P2-27-001 | integration | Verify weekly editorial-cycle model integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-27-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in weekly editorial-cycle model. | merge |
| OBS-P2-27-001 | observability | Emit required events, metrics, traces, and correlation identifiers for weekly editorial-cycle model. | merge |
| E2E-P2-27-001 | end_to_end | Complete the founder-visible workflow for weekly editorial-cycle model with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.8
phase: 2
title: "LinkedIn and Substack agents and workspaces"
status: drafted
dependencies: ["WP2.7"]
primary_team: beta_operations
risk: high
---

# WP2.8 - LinkedIn and Substack agents and workspaces

## Objective

Implement linkedin and substack agents and workspaces as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.7

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for linkedin and substack agents and workspaces
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-8-REQ-001:** The system shall implement linkedin and substack agents and workspaces using existing repository conventions and shared FOS contracts.
- **2-8-REQ-002:** The implementation shall expose versioned, validated interfaces for linkedin and substack agents and workspaces and preserve backward compatibility or provide an explicit migration.
- **2-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to linkedin and substack agents and workspaces shall be enforced deterministically.
- **2-8-REQ-004:** All consequential operations in linkedin and substack agents and workspaces shall be auditable through correlation-aware events and immutable or versioned records.
- **2-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for linkedin and substack agents and workspaces.
- **2-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for linkedin and substack agents and workspaces.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-28-001 | unit | Validate core rules and schemas for linkedin and substack agents and workspaces. | pull_request |
| IT-P2-28-001 | integration | Verify linkedin and substack agents and workspaces integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-28-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in linkedin and substack agents and workspaces. | merge |
| OBS-P2-28-001 | observability | Emit required events, metrics, traces, and correlation identifiers for linkedin and substack agents and workspaces. | merge |
| E2E-P2-28-001 | end_to_end | Complete the founder-visible workflow for linkedin and substack agents and workspaces with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.9
phase: 2
title: "Engagement intelligence and question clustering"
status: drafted
dependencies: ["WP2.8"]
primary_team: beta_operations
risk: medium
---

# WP2.9 - Engagement intelligence and question clustering

## Objective

Implement engagement intelligence and question clustering as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.8

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for engagement intelligence and question clustering
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-9-REQ-001:** The system shall implement engagement intelligence and question clustering using existing repository conventions and shared FOS contracts.
- **2-9-REQ-002:** The implementation shall expose versioned, validated interfaces for engagement intelligence and question clustering and preserve backward compatibility or provide an explicit migration.
- **2-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to engagement intelligence and question clustering shall be enforced deterministically.
- **2-9-REQ-004:** All consequential operations in engagement intelligence and question clustering shall be auditable through correlation-aware events and immutable or versioned records.
- **2-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for engagement intelligence and question clustering.
- **2-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for engagement intelligence and question clustering.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-29-001 | unit | Validate core rules and schemas for engagement intelligence and question clustering. | pull_request |
| IT-P2-29-001 | integration | Verify engagement intelligence and question clustering integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-29-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in engagement intelligence and question clustering. | merge |
| OBS-P2-29-001 | observability | Emit required events, metrics, traces, and correlation identifiers for engagement intelligence and question clustering. | merge |
| E2E-P2-29-001 | end_to_end | Complete the founder-visible workflow for engagement intelligence and question clustering with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP2.10
phase: 2
title: "Metrics, evaluation, and activation"
status: drafted
dependencies: ["WP2.2", "WP2.3", "WP2.4", "WP2.5", "WP2.6", "WP2.7", "WP2.8", "WP2.9"]
primary_team: beta_operations
risk: medium
---

# WP2.10 - Metrics, evaluation, and activation

## Objective

Implement metrics, evaluation, and activation as a bounded, testable vertical slice that conforms to the revised Phase 2 specification and shared FOS contracts.

## Business value

This packet advances **Phase 2: Beta Activation, Retention, Support, and Founder Editorial Cadence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.2
- WP2.3
- WP2.4
- WP2.5
- WP2.6
- WP2.7
- WP2.8
- WP2.9

## Required inputs

- Revised Phase 2 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for metrics, evaluation, and activation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **2-10-REQ-001:** The system shall implement metrics, evaluation, and activation using existing repository conventions and shared FOS contracts.
- **2-10-REQ-002:** The implementation shall expose versioned, validated interfaces for metrics, evaluation, and activation and preserve backward compatibility or provide an explicit migration.
- **2-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to metrics, evaluation, and activation shall be enforced deterministically.
- **2-10-REQ-004:** All consequential operations in metrics, evaluation, and activation shall be auditable through correlation-aware events and immutable or versioned records.
- **2-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for metrics, evaluation, and activation.
- **2-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for metrics, evaluation, and activation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P2-210-001 | unit | Validate core rules and schemas for metrics, evaluation, and activation. | pull_request |
| IT-P2-210-001 | integration | Verify metrics, evaluation, and activation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P2-210-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in metrics, evaluation, and activation. | merge |
| OBS-P2-210-001 | observability | Emit required events, metrics, traces, and correlation identifiers for metrics, evaluation, and activation. | merge |
| E2E-P2-210-001 | end_to_end | Complete the founder-visible workflow for metrics, evaluation, and activation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.0
phase: 3
title: "Phase 2 signal and outcome handoff"
status: drafted
dependencies: ["WP2.10"]
primary_team: product_quality
risk: medium
---

# WP3.0 - Phase 2 signal and outcome handoff

## Objective

Implement phase 2 signal and outcome handoff as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP2.10

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for phase 2 signal and outcome handoff
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-0-REQ-001:** The system shall implement phase 2 signal and outcome handoff using existing repository conventions and shared FOS contracts.
- **3-0-REQ-002:** The implementation shall expose versioned, validated interfaces for phase 2 signal and outcome handoff and preserve backward compatibility or provide an explicit migration.
- **3-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to phase 2 signal and outcome handoff shall be enforced deterministically.
- **3-0-REQ-004:** All consequential operations in phase 2 signal and outcome handoff shall be auditable through correlation-aware events and immutable or versioned records.
- **3-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for phase 2 signal and outcome handoff.
- **3-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for phase 2 signal and outcome handoff.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-30-001 | unit | Validate core rules and schemas for phase 2 signal and outcome handoff. | pull_request |
| IT-P3-30-001 | integration | Verify phase 2 signal and outcome handoff integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-30-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in phase 2 signal and outcome handoff. | merge |
| OBS-P3-30-001 | observability | Emit required events, metrics, traces, and correlation identifiers for phase 2 signal and outcome handoff. | merge |
| E2E-P3-30-001 | end_to_end | Complete the founder-visible workflow for phase 2 signal and outcome handoff with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.1
phase: 3
title: "Signal and cluster registry"
status: drafted
dependencies: ["WP3.0"]
primary_team: product_quality
risk: medium
---

# WP3.1 - Signal and cluster registry

## Objective

Implement signal and cluster registry as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.0

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for signal and cluster registry
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-1-REQ-001:** The system shall implement signal and cluster registry using existing repository conventions and shared FOS contracts.
- **3-1-REQ-002:** The implementation shall expose versioned, validated interfaces for signal and cluster registry and preserve backward compatibility or provide an explicit migration.
- **3-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to signal and cluster registry shall be enforced deterministically.
- **3-1-REQ-004:** All consequential operations in signal and cluster registry shall be auditable through correlation-aware events and immutable or versioned records.
- **3-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for signal and cluster registry.
- **3-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for signal and cluster registry.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-31-001 | unit | Validate core rules and schemas for signal and cluster registry. | pull_request |
| IT-P3-31-001 | integration | Verify signal and cluster registry integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-31-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in signal and cluster registry. | merge |
| OBS-P3-31-001 | observability | Emit required events, metrics, traces, and correlation identifiers for signal and cluster registry. | merge |
| E2E-P3-31-001 | end_to_end | Complete the founder-visible workflow for signal and cluster registry with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.2
phase: 3
title: "Change proposals and decisions"
status: drafted
dependencies: ["WP3.1"]
primary_team: product_quality
risk: medium
---

# WP3.2 - Change proposals and decisions

## Objective

Implement change proposals and decisions as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.1

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for change proposals and decisions
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-2-REQ-001:** The system shall implement change proposals and decisions using existing repository conventions and shared FOS contracts.
- **3-2-REQ-002:** The implementation shall expose versioned, validated interfaces for change proposals and decisions and preserve backward compatibility or provide an explicit migration.
- **3-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to change proposals and decisions shall be enforced deterministically.
- **3-2-REQ-004:** All consequential operations in change proposals and decisions shall be auditable through correlation-aware events and immutable or versioned records.
- **3-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for change proposals and decisions.
- **3-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for change proposals and decisions.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-32-001 | unit | Validate core rules and schemas for change proposals and decisions. | pull_request |
| IT-P3-32-001 | integration | Verify change proposals and decisions integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-32-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in change proposals and decisions. | merge |
| OBS-P3-32-001 | observability | Emit required events, metrics, traces, and correlation identifiers for change proposals and decisions. | merge |
| E2E-P3-32-001 | end_to_end | Complete the founder-visible workflow for change proposals and decisions with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.3
phase: 3
title: "Specification artifacts and canonical requirements"
status: drafted
dependencies: ["WP3.2"]
primary_team: product_quality
risk: medium
---

# WP3.3 - Specification artifacts and canonical requirements

## Objective

Implement specification artifacts and canonical requirements as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.2

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for specification artifacts and canonical requirements
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-3-REQ-001:** The system shall implement specification artifacts and canonical requirements using existing repository conventions and shared FOS contracts.
- **3-3-REQ-002:** The implementation shall expose versioned, validated interfaces for specification artifacts and canonical requirements and preserve backward compatibility or provide an explicit migration.
- **3-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to specification artifacts and canonical requirements shall be enforced deterministically.
- **3-3-REQ-004:** All consequential operations in specification artifacts and canonical requirements shall be auditable through correlation-aware events and immutable or versioned records.
- **3-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for specification artifacts and canonical requirements.
- **3-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for specification artifacts and canonical requirements.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-33-001 | unit | Validate core rules and schemas for specification artifacts and canonical requirements. | pull_request |
| IT-P3-33-001 | integration | Verify specification artifacts and canonical requirements integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-33-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in specification artifacts and canonical requirements. | merge |
| OBS-P3-33-001 | observability | Emit required events, metrics, traces, and correlation identifiers for specification artifacts and canonical requirements. | merge |
| E2E-P3-33-001 | end_to_end | Complete the founder-visible workflow for specification artifacts and canonical requirements with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.4
phase: 3
title: "Synthetic personas and test registry"
status: drafted
dependencies: ["WP3.3"]
primary_team: product_quality
risk: medium
---

# WP3.4 - Synthetic personas and test registry

## Objective

Implement synthetic personas and test registry as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.3

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for synthetic personas and test registry
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-4-REQ-001:** The system shall implement synthetic personas and test registry using existing repository conventions and shared FOS contracts.
- **3-4-REQ-002:** The implementation shall expose versioned, validated interfaces for synthetic personas and test registry and preserve backward compatibility or provide an explicit migration.
- **3-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to synthetic personas and test registry shall be enforced deterministically.
- **3-4-REQ-004:** All consequential operations in synthetic personas and test registry shall be auditable through correlation-aware events and immutable or versioned records.
- **3-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for synthetic personas and test registry.
- **3-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for synthetic personas and test registry.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-34-001 | unit | Validate core rules and schemas for synthetic personas and test registry. | pull_request |
| IT-P3-34-001 | integration | Verify synthetic personas and test registry integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-34-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in synthetic personas and test registry. | merge |
| OBS-P3-34-001 | observability | Emit required events, metrics, traces, and correlation identifiers for synthetic personas and test registry. | merge |
| E2E-P3-34-001 | end_to_end | Complete the founder-visible workflow for synthetic personas and test registry with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.5
phase: 3
title: "Test execution and evidence"
status: drafted
dependencies: ["WP3.4"]
primary_team: product_quality
risk: medium
---

# WP3.5 - Test execution and evidence

## Objective

Implement test execution and evidence as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.4

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for test execution and evidence
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-5-REQ-001:** The system shall implement test execution and evidence using existing repository conventions and shared FOS contracts.
- **3-5-REQ-002:** The implementation shall expose versioned, validated interfaces for test execution and evidence and preserve backward compatibility or provide an explicit migration.
- **3-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to test execution and evidence shall be enforced deterministically.
- **3-5-REQ-004:** All consequential operations in test execution and evidence shall be auditable through correlation-aware events and immutable or versioned records.
- **3-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for test execution and evidence.
- **3-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for test execution and evidence.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-35-001 | unit | Validate core rules and schemas for test execution and evidence. | pull_request |
| IT-P3-35-001 | integration | Verify test execution and evidence integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-35-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in test execution and evidence. | merge |
| OBS-P3-35-001 | observability | Emit required events, metrics, traces, and correlation identifiers for test execution and evidence. | merge |
| E2E-P3-35-001 | end_to_end | Complete the founder-visible workflow for test execution and evidence with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.6
phase: 3
title: "Security, memory, and injection suites"
status: drafted
dependencies: ["WP3.5"]
primary_team: product_quality
risk: critical
---

# WP3.6 - Security, memory, and injection suites

## Objective

Implement security, memory, and injection suites as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.5

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for security, memory, and injection suites
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-6-REQ-001:** The system shall implement security, memory, and injection suites using existing repository conventions and shared FOS contracts.
- **3-6-REQ-002:** The implementation shall expose versioned, validated interfaces for security, memory, and injection suites and preserve backward compatibility or provide an explicit migration.
- **3-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to security, memory, and injection suites shall be enforced deterministically.
- **3-6-REQ-004:** All consequential operations in security, memory, and injection suites shall be auditable through correlation-aware events and immutable or versioned records.
- **3-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for security, memory, and injection suites.
- **3-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for security, memory, and injection suites.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-36-001 | unit | Validate core rules and schemas for security, memory, and injection suites. | pull_request |
| IT-P3-36-001 | integration | Verify security, memory, and injection suites integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-36-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in security, memory, and injection suites. | merge |
| OBS-P3-36-001 | observability | Emit required events, metrics, traces, and correlation identifiers for security, memory, and injection suites. | merge |
| E2E-P3-36-001 | end_to_end | Complete the founder-visible workflow for security, memory, and injection suites with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.7
phase: 3
title: "Defects and regression investigation"
status: drafted
dependencies: ["WP3.5", "WP3.6"]
primary_team: product_quality
risk: medium
---

# WP3.7 - Defects and regression investigation

## Objective

Implement defects and regression investigation as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.5
- WP3.6

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for defects and regression investigation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-7-REQ-001:** The system shall implement defects and regression investigation using existing repository conventions and shared FOS contracts.
- **3-7-REQ-002:** The implementation shall expose versioned, validated interfaces for defects and regression investigation and preserve backward compatibility or provide an explicit migration.
- **3-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to defects and regression investigation shall be enforced deterministically.
- **3-7-REQ-004:** All consequential operations in defects and regression investigation shall be auditable through correlation-aware events and immutable or versioned records.
- **3-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for defects and regression investigation.
- **3-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for defects and regression investigation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-37-001 | unit | Validate core rules and schemas for defects and regression investigation. | pull_request |
| IT-P3-37-001 | integration | Verify defects and regression investigation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-37-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in defects and regression investigation. | merge |
| OBS-P3-37-001 | observability | Emit required events, metrics, traces, and correlation identifiers for defects and regression investigation. | merge |
| E2E-P3-37-001 | end_to_end | Complete the founder-visible workflow for defects and regression investigation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.8
phase: 3
title: "Release candidates and readiness"
status: drafted
dependencies: ["WP3.3", "WP3.5", "WP3.7"]
primary_team: product_quality
risk: critical
---

# WP3.8 - Release candidates and readiness

## Objective

Implement release candidates and readiness as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.3
- WP3.5
- WP3.7

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for release candidates and readiness
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-8-REQ-001:** The system shall implement release candidates and readiness using existing repository conventions and shared FOS contracts.
- **3-8-REQ-002:** The implementation shall expose versioned, validated interfaces for release candidates and readiness and preserve backward compatibility or provide an explicit migration.
- **3-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to release candidates and readiness shall be enforced deterministically.
- **3-8-REQ-004:** All consequential operations in release candidates and readiness shall be auditable through correlation-aware events and immutable or versioned records.
- **3-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for release candidates and readiness.
- **3-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for release candidates and readiness.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-38-001 | unit | Validate core rules and schemas for release candidates and readiness. | pull_request |
| IT-P3-38-001 | integration | Verify release candidates and readiness integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-38-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in release candidates and readiness. | merge |
| OBS-P3-38-001 | observability | Emit required events, metrics, traces, and correlation identifiers for release candidates and readiness. | merge |
| E2E-P3-38-001 | end_to_end | Complete the founder-visible workflow for release candidates and readiness with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.9
phase: 3
title: "Claim impact and revalidation"
status: drafted
dependencies: ["WP3.8"]
primary_team: product_quality
risk: medium
---

# WP3.9 - Claim impact and revalidation

## Objective

Implement claim impact and revalidation as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.8

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for claim impact and revalidation
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-9-REQ-001:** The system shall implement claim impact and revalidation using existing repository conventions and shared FOS contracts.
- **3-9-REQ-002:** The implementation shall expose versioned, validated interfaces for claim impact and revalidation and preserve backward compatibility or provide an explicit migration.
- **3-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to claim impact and revalidation shall be enforced deterministically.
- **3-9-REQ-004:** All consequential operations in claim impact and revalidation shall be auditable through correlation-aware events and immutable or versioned records.
- **3-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for claim impact and revalidation.
- **3-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for claim impact and revalidation.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-39-001 | unit | Validate core rules and schemas for claim impact and revalidation. | pull_request |
| IT-P3-39-001 | integration | Verify claim impact and revalidation integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-39-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in claim impact and revalidation. | merge |
| OBS-P3-39-001 | observability | Emit required events, metrics, traces, and correlation identifiers for claim impact and revalidation. | merge |
| E2E-P3-39-001 | end_to_end | Complete the founder-visible workflow for claim impact and revalidation with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.10
phase: 3
title: "Release communications and customer proof"
status: drafted
dependencies: ["WP3.8", "WP3.9"]
primary_team: product_quality
risk: critical
---

# WP3.10 - Release communications and customer proof

## Objective

Implement release communications and customer proof as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.8
- WP3.9

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for release communications and customer proof
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-10-REQ-001:** The system shall implement release communications and customer proof using existing repository conventions and shared FOS contracts.
- **3-10-REQ-002:** The implementation shall expose versioned, validated interfaces for release communications and customer proof and preserve backward compatibility or provide an explicit migration.
- **3-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to release communications and customer proof shall be enforced deterministically.
- **3-10-REQ-004:** All consequential operations in release communications and customer proof shall be auditable through correlation-aware events and immutable or versioned records.
- **3-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for release communications and customer proof.
- **3-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for release communications and customer proof.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-310-001 | unit | Validate core rules and schemas for release communications and customer proof. | pull_request |
| IT-P3-310-001 | integration | Verify release communications and customer proof integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-310-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in release communications and customer proof. | merge |
| OBS-P3-310-001 | observability | Emit required events, metrics, traces, and correlation identifiers for release communications and customer proof. | merge |
| E2E-P3-310-001 | end_to_end | Complete the founder-visible workflow for release communications and customer proof with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP3.11
phase: 3
title: "Product, QA, and Release Notion workspaces"
status: drafted
dependencies: ["WP3.1", "WP3.3", "WP3.5", "WP3.8", "WP3.10"]
primary_team: product_quality
risk: critical
---

# WP3.11 - Product, QA, and Release Notion workspaces

## Objective

Implement product, qa, and release notion workspaces as a bounded, testable vertical slice that conforms to the revised Phase 3 specification and shared FOS contracts.

## Business value

This packet advances **Phase 3: Product Learning, QA, Release, and Customer Proof** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.1
- WP3.3
- WP3.5
- WP3.8
- WP3.10

## Required inputs

- Revised Phase 3 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for product, qa, and release notion workspaces
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **3-11-REQ-001:** The system shall implement product, qa, and release notion workspaces using existing repository conventions and shared FOS contracts.
- **3-11-REQ-002:** The implementation shall expose versioned, validated interfaces for product, qa, and release notion workspaces and preserve backward compatibility or provide an explicit migration.
- **3-11-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to product, qa, and release notion workspaces shall be enforced deterministically.
- **3-11-REQ-004:** All consequential operations in product, qa, and release notion workspaces shall be auditable through correlation-aware events and immutable or versioned records.
- **3-11-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for product, qa, and release notion workspaces.
- **3-11-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for product, qa, and release notion workspaces.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P3-311-001 | unit | Validate core rules and schemas for product, qa, and release notion workspaces. | pull_request |
| IT-P3-311-001 | integration | Verify product, qa, and release notion workspaces integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P3-311-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in product, qa, and release notion workspaces. | merge |
| OBS-P3-311-001 | observability | Emit required events, metrics, traces, and correlation identifiers for product, qa, and release notion workspaces. | merge |
| E2E-P3-311-001 | end_to_end | Complete the founder-visible workflow for product, qa, and release notion workspaces with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.0
phase: 4
title: "Phase 1-3 source and attribution migration"
status: drafted
dependencies: ["WP1.10", "WP2.10", "WP3.10"]
primary_team: communications
risk: critical
---

# WP4.0 - Phase 1-3 source and attribution migration

## Objective

Implement phase 1-3 source and attribution migration as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.10
- WP2.10
- WP3.10

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for phase 1-3 source and attribution migration
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-0-REQ-001:** The system shall implement phase 1-3 source and attribution migration using existing repository conventions and shared FOS contracts.
- **4-0-REQ-002:** The implementation shall expose versioned, validated interfaces for phase 1-3 source and attribution migration and preserve backward compatibility or provide an explicit migration.
- **4-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to phase 1-3 source and attribution migration shall be enforced deterministically.
- **4-0-REQ-004:** All consequential operations in phase 1-3 source and attribution migration shall be auditable through correlation-aware events and immutable or versioned records.
- **4-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for phase 1-3 source and attribution migration.
- **4-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for phase 1-3 source and attribution migration.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-40-001 | unit | Validate core rules and schemas for phase 1-3 source and attribution migration. | pull_request |
| IT-P4-40-001 | integration | Verify phase 1-3 source and attribution migration integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-40-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in phase 1-3 source and attribution migration. | merge |
| OBS-P4-40-001 | observability | Emit required events, metrics, traces, and correlation identifiers for phase 1-3 source and attribution migration. | merge |
| E2E-P4-40-001 | end_to_end | Complete the founder-visible workflow for phase 1-3 source and attribution migration with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.1
phase: 4
title: "Source brief and evidence eligibility"
status: drafted
dependencies: ["WP4.0"]
primary_team: communications
risk: medium
---

# WP4.1 - Source brief and evidence eligibility

## Objective

Implement source brief and evidence eligibility as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.0

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for source brief and evidence eligibility
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-1-REQ-001:** The system shall implement source brief and evidence eligibility using existing repository conventions and shared FOS contracts.
- **4-1-REQ-002:** The implementation shall expose versioned, validated interfaces for source brief and evidence eligibility and preserve backward compatibility or provide an explicit migration.
- **4-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to source brief and evidence eligibility shall be enforced deterministically.
- **4-1-REQ-004:** All consequential operations in source brief and evidence eligibility shall be auditable through correlation-aware events and immutable or versioned records.
- **4-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for source brief and evidence eligibility.
- **4-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for source brief and evidence eligibility.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-41-001 | unit | Validate core rules and schemas for source brief and evidence eligibility. | pull_request |
| IT-P4-41-001 | integration | Verify source brief and evidence eligibility integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-41-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in source brief and evidence eligibility. | merge |
| OBS-P4-41-001 | observability | Emit required events, metrics, traces, and correlation identifiers for source brief and evidence eligibility. | merge |
| E2E-P4-41-001 | end_to_end | Complete the founder-visible workflow for source brief and evidence eligibility with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.2
phase: 4
title: "Positioning and campaign planning"
status: drafted
dependencies: ["WP4.1"]
primary_team: communications
risk: medium
---

# WP4.2 - Positioning and campaign planning

## Objective

Implement positioning and campaign planning as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.1

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for positioning and campaign planning
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-2-REQ-001:** The system shall implement positioning and campaign planning using existing repository conventions and shared FOS contracts.
- **4-2-REQ-002:** The implementation shall expose versioned, validated interfaces for positioning and campaign planning and preserve backward compatibility or provide an explicit migration.
- **4-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to positioning and campaign planning shall be enforced deterministically.
- **4-2-REQ-004:** All consequential operations in positioning and campaign planning shall be auditable through correlation-aware events and immutable or versioned records.
- **4-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for positioning and campaign planning.
- **4-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for positioning and campaign planning.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-42-001 | unit | Validate core rules and schemas for positioning and campaign planning. | pull_request |
| IT-P4-42-001 | integration | Verify positioning and campaign planning integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-42-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in positioning and campaign planning. | merge |
| OBS-P4-42-001 | observability | Emit required events, metrics, traces, and correlation identifiers for positioning and campaign planning. | merge |
| E2E-P4-42-001 | end_to_end | Complete the founder-visible workflow for positioning and campaign planning with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.3
phase: 4
title: "LinkedIn production and carousel workflow"
status: drafted
dependencies: ["WP4.2"]
primary_team: communications
risk: medium
---

# WP4.3 - LinkedIn production and carousel workflow

## Objective

Implement linkedin production and carousel workflow as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.2

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for linkedin production and carousel workflow
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-3-REQ-001:** The system shall implement linkedin production and carousel workflow using existing repository conventions and shared FOS contracts.
- **4-3-REQ-002:** The implementation shall expose versioned, validated interfaces for linkedin production and carousel workflow and preserve backward compatibility or provide an explicit migration.
- **4-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to linkedin production and carousel workflow shall be enforced deterministically.
- **4-3-REQ-004:** All consequential operations in linkedin production and carousel workflow shall be auditable through correlation-aware events and immutable or versioned records.
- **4-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for linkedin production and carousel workflow.
- **4-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for linkedin production and carousel workflow.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-43-001 | unit | Validate core rules and schemas for linkedin production and carousel workflow. | pull_request |
| IT-P4-43-001 | integration | Verify linkedin production and carousel workflow integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-43-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in linkedin production and carousel workflow. | merge |
| OBS-P4-43-001 | observability | Emit required events, metrics, traces, and correlation identifiers for linkedin production and carousel workflow. | merge |
| E2E-P4-43-001 | end_to_end | Complete the founder-visible workflow for linkedin production and carousel workflow with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.4
phase: 4
title: "Substack research and publishing workflow"
status: drafted
dependencies: ["WP4.2"]
primary_team: communications
risk: medium
---

# WP4.4 - Substack research and publishing workflow

## Objective

Implement substack research and publishing workflow as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.2

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for substack research and publishing workflow
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-4-REQ-001:** The system shall implement substack research and publishing workflow using existing repository conventions and shared FOS contracts.
- **4-4-REQ-002:** The implementation shall expose versioned, validated interfaces for substack research and publishing workflow and preserve backward compatibility or provide an explicit migration.
- **4-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to substack research and publishing workflow shall be enforced deterministically.
- **4-4-REQ-004:** All consequential operations in substack research and publishing workflow shall be auditable through correlation-aware events and immutable or versioned records.
- **4-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for substack research and publishing workflow.
- **4-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for substack research and publishing workflow.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-44-001 | unit | Validate core rules and schemas for substack research and publishing workflow. | pull_request |
| IT-P4-44-001 | integration | Verify substack research and publishing workflow integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-44-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in substack research and publishing workflow. | merge |
| OBS-P4-44-001 | observability | Emit required events, metrics, traces, and correlation identifiers for substack research and publishing workflow. | merge |
| E2E-P4-44-001 | end_to_end | Complete the founder-visible workflow for substack research and publishing workflow with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.5
phase: 4
title: "Email, webinar, landing page, and release packages"
status: drafted
dependencies: ["WP4.2"]
primary_team: communications
risk: critical
---

# WP4.5 - Email, webinar, landing page, and release packages

## Objective

Implement email, webinar, landing page, and release packages as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.2

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for email, webinar, landing page, and release packages
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-5-REQ-001:** The system shall implement email, webinar, landing page, and release packages using existing repository conventions and shared FOS contracts.
- **4-5-REQ-002:** The implementation shall expose versioned, validated interfaces for email, webinar, landing page, and release packages and preserve backward compatibility or provide an explicit migration.
- **4-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to email, webinar, landing page, and release packages shall be enforced deterministically.
- **4-5-REQ-004:** All consequential operations in email, webinar, landing page, and release packages shall be auditable through correlation-aware events and immutable or versioned records.
- **4-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for email, webinar, landing page, and release packages.
- **4-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for email, webinar, landing page, and release packages.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-45-001 | unit | Validate core rules and schemas for email, webinar, landing page, and release packages. | pull_request |
| IT-P4-45-001 | integration | Verify email, webinar, landing page, and release packages integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-45-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in email, webinar, landing page, and release packages. | merge |
| OBS-P4-45-001 | observability | Emit required events, metrics, traces, and correlation identifiers for email, webinar, landing page, and release packages. | merge |
| E2E-P4-45-001 | end_to_end | Complete the founder-visible workflow for email, webinar, landing page, and release packages with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.6
phase: 4
title: "Multi-channel repurposing"
status: drafted
dependencies: ["WP4.3", "WP4.4", "WP4.5"]
primary_team: communications
risk: medium
---

# WP4.6 - Multi-channel repurposing

## Objective

Implement multi-channel repurposing as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.3
- WP4.4
- WP4.5

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for multi-channel repurposing
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-6-REQ-001:** The system shall implement multi-channel repurposing using existing repository conventions and shared FOS contracts.
- **4-6-REQ-002:** The implementation shall expose versioned, validated interfaces for multi-channel repurposing and preserve backward compatibility or provide an explicit migration.
- **4-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to multi-channel repurposing shall be enforced deterministically.
- **4-6-REQ-004:** All consequential operations in multi-channel repurposing shall be auditable through correlation-aware events and immutable or versioned records.
- **4-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for multi-channel repurposing.
- **4-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for multi-channel repurposing.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-46-001 | unit | Validate core rules and schemas for multi-channel repurposing. | pull_request |
| IT-P4-46-001 | integration | Verify multi-channel repurposing integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-46-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in multi-channel repurposing. | merge |
| OBS-P4-46-001 | observability | Emit required events, metrics, traces, and correlation identifiers for multi-channel repurposing. | merge |
| E2E-P4-46-001 | end_to_end | Complete the founder-visible workflow for multi-channel repurposing with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.7
phase: 4
title: "Claims, consent, and pricing verification"
status: drafted
dependencies: ["WP4.1", "WP4.3", "WP4.4", "WP4.5", "WP4.6"]
primary_team: communications
risk: critical
---

# WP4.7 - Claims, consent, and pricing verification

## Objective

Implement claims, consent, and pricing verification as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.1
- WP4.3
- WP4.4
- WP4.5
- WP4.6

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for claims, consent, and pricing verification
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-7-REQ-001:** The system shall implement claims, consent, and pricing verification using existing repository conventions and shared FOS contracts.
- **4-7-REQ-002:** The implementation shall expose versioned, validated interfaces for claims, consent, and pricing verification and preserve backward compatibility or provide an explicit migration.
- **4-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to claims, consent, and pricing verification shall be enforced deterministically.
- **4-7-REQ-004:** All consequential operations in claims, consent, and pricing verification shall be auditable through correlation-aware events and immutable or versioned records.
- **4-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for claims, consent, and pricing verification.
- **4-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for claims, consent, and pricing verification.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-47-001 | unit | Validate core rules and schemas for claims, consent, and pricing verification. | pull_request |
| IT-P4-47-001 | integration | Verify claims, consent, and pricing verification integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-47-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in claims, consent, and pricing verification. | merge |
| OBS-P4-47-001 | observability | Emit required events, metrics, traces, and correlation identifiers for claims, consent, and pricing verification. | merge |
| E2E-P4-47-001 | end_to_end | Complete the founder-visible workflow for claims, consent, and pricing verification with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.8
phase: 4
title: "Platform draft adapters and publication records"
status: drafted
dependencies: ["WP4.7"]
primary_team: communications
risk: medium
---

# WP4.8 - Platform draft adapters and publication records

## Objective

Implement platform draft adapters and publication records as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.7

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for platform draft adapters and publication records
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-8-REQ-001:** The system shall implement platform draft adapters and publication records using existing repository conventions and shared FOS contracts.
- **4-8-REQ-002:** The implementation shall expose versioned, validated interfaces for platform draft adapters and publication records and preserve backward compatibility or provide an explicit migration.
- **4-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to platform draft adapters and publication records shall be enforced deterministically.
- **4-8-REQ-004:** All consequential operations in platform draft adapters and publication records shall be auditable through correlation-aware events and immutable or versioned records.
- **4-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for platform draft adapters and publication records.
- **4-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for platform draft adapters and publication records.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-48-001 | unit | Validate core rules and schemas for platform draft adapters and publication records. | pull_request |
| IT-P4-48-001 | integration | Verify platform draft adapters and publication records integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-48-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in platform draft adapters and publication records. | merge |
| OBS-P4-48-001 | observability | Emit required events, metrics, traces, and correlation identifiers for platform draft adapters and publication records. | merge |
| E2E-P4-48-001 | end_to_end | Complete the founder-visible workflow for platform draft adapters and publication records with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.9
phase: 4
title: "Performance ingestion and attribution"
status: drafted
dependencies: ["WP4.8"]
primary_team: communications
risk: high
---

# WP4.9 - Performance ingestion and attribution

## Objective

Implement performance ingestion and attribution as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.8

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for performance ingestion and attribution
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-9-REQ-001:** The system shall implement performance ingestion and attribution using existing repository conventions and shared FOS contracts.
- **4-9-REQ-002:** The implementation shall expose versioned, validated interfaces for performance ingestion and attribution and preserve backward compatibility or provide an explicit migration.
- **4-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to performance ingestion and attribution shall be enforced deterministically.
- **4-9-REQ-004:** All consequential operations in performance ingestion and attribution shall be auditable through correlation-aware events and immutable or versioned records.
- **4-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for performance ingestion and attribution.
- **4-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for performance ingestion and attribution.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-49-001 | unit | Validate core rules and schemas for performance ingestion and attribution. | pull_request |
| IT-P4-49-001 | integration | Verify performance ingestion and attribution integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-49-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in performance ingestion and attribution. | merge |
| OBS-P4-49-001 | observability | Emit required events, metrics, traces, and correlation identifiers for performance ingestion and attribution. | merge |
| E2E-P4-49-001 | end_to_end | Complete the founder-visible workflow for performance ingestion and attribution with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.10
phase: 4
title: "Founder voice learning and experiments"
status: drafted
dependencies: ["WP4.9"]
primary_team: communications
risk: medium
---

# WP4.10 - Founder voice learning and experiments

## Objective

Implement founder voice learning and experiments as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.9

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for founder voice learning and experiments
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-10-REQ-001:** The system shall implement founder voice learning and experiments using existing repository conventions and shared FOS contracts.
- **4-10-REQ-002:** The implementation shall expose versioned, validated interfaces for founder voice learning and experiments and preserve backward compatibility or provide an explicit migration.
- **4-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to founder voice learning and experiments shall be enforced deterministically.
- **4-10-REQ-004:** All consequential operations in founder voice learning and experiments shall be auditable through correlation-aware events and immutable or versioned records.
- **4-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for founder voice learning and experiments.
- **4-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for founder voice learning and experiments.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-410-001 | unit | Validate core rules and schemas for founder voice learning and experiments. | pull_request |
| IT-P4-410-001 | integration | Verify founder voice learning and experiments integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-410-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in founder voice learning and experiments. | merge |
| OBS-P4-410-001 | observability | Emit required events, metrics, traces, and correlation identifiers for founder voice learning and experiments. | merge |
| E2E-P4-410-001 | end_to_end | Complete the founder-visible workflow for founder voice learning and experiments with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP4.11
phase: 4
title: "Communications Calendar and Campaign Center"
status: drafted
dependencies: ["WP4.1", "WP4.2", "WP4.3", "WP4.4", "WP4.5", "WP4.6", "WP4.7", "WP4.8", "WP4.9", "WP4.10"]
primary_team: communications
risk: medium
---

# WP4.11 - Communications Calendar and Campaign Center

## Objective

Implement communications calendar and campaign center as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.1
- WP4.2
- WP4.3
- WP4.4
- WP4.5
- WP4.6
- WP4.7
- WP4.8
- WP4.9
- WP4.10

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for communications calendar and campaign center
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-11-REQ-001:** The system shall implement communications calendar and campaign center using existing repository conventions and shared FOS contracts.
- **4-11-REQ-002:** The implementation shall expose versioned, validated interfaces for communications calendar and campaign center and preserve backward compatibility or provide an explicit migration.
- **4-11-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to communications calendar and campaign center shall be enforced deterministically.
- **4-11-REQ-004:** All consequential operations in communications calendar and campaign center shall be auditable through correlation-aware events and immutable or versioned records.
- **4-11-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for communications calendar and campaign center.
- **4-11-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for communications calendar and campaign center.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-411-001 | unit | Validate core rules and schemas for communications calendar and campaign center. | pull_request |
| IT-P4-411-001 | integration | Verify communications calendar and campaign center integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-411-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in communications calendar and campaign center. | merge |
| OBS-P4-411-001 | observability | Emit required events, metrics, traces, and correlation identifiers for communications calendar and campaign center. | merge |
| E2E-P4-411-001 | end_to_end | Complete the founder-visible workflow for communications calendar and campaign center with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.0
phase: 5
title: "Competitor taxonomy and approved-source policy"
status: drafted
dependencies: ["WP0.10"]
primary_team: market_intelligence
risk: medium
---

# WP5.0 - Competitor taxonomy and approved-source policy

## Objective

Implement competitor taxonomy and approved-source policy as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP0.10

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for competitor taxonomy and approved-source policy
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-0-REQ-001:** The system shall implement competitor taxonomy and approved-source policy using existing repository conventions and shared FOS contracts.
- **5-0-REQ-002:** The implementation shall expose versioned, validated interfaces for competitor taxonomy and approved-source policy and preserve backward compatibility or provide an explicit migration.
- **5-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to competitor taxonomy and approved-source policy shall be enforced deterministically.
- **5-0-REQ-004:** All consequential operations in competitor taxonomy and approved-source policy shall be auditable through correlation-aware events and immutable or versioned records.
- **5-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for competitor taxonomy and approved-source policy.
- **5-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for competitor taxonomy and approved-source policy.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-50-001 | unit | Validate core rules and schemas for competitor taxonomy and approved-source policy. | pull_request |
| IT-P5-50-001 | integration | Verify competitor taxonomy and approved-source policy integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-50-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in competitor taxonomy and approved-source policy. | merge |
| OBS-P5-50-001 | observability | Emit required events, metrics, traces, and correlation identifiers for competitor taxonomy and approved-source policy. | merge |
| E2E-P5-50-001 | end_to_end | Complete the founder-visible workflow for competitor taxonomy and approved-source policy with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.1
phase: 5
title: "Competitor, offering, and source registry"
status: drafted
dependencies: ["WP5.0"]
primary_team: market_intelligence
risk: medium
---

# WP5.1 - Competitor, offering, and source registry

## Objective

Implement competitor, offering, and source registry as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.0

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for competitor, offering, and source registry
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-1-REQ-001:** The system shall implement competitor, offering, and source registry using existing repository conventions and shared FOS contracts.
- **5-1-REQ-002:** The implementation shall expose versioned, validated interfaces for competitor, offering, and source registry and preserve backward compatibility or provide an explicit migration.
- **5-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to competitor, offering, and source registry shall be enforced deterministically.
- **5-1-REQ-004:** All consequential operations in competitor, offering, and source registry shall be auditable through correlation-aware events and immutable or versioned records.
- **5-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for competitor, offering, and source registry.
- **5-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for competitor, offering, and source registry.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-51-001 | unit | Validate core rules and schemas for competitor, offering, and source registry. | pull_request |
| IT-P5-51-001 | integration | Verify competitor, offering, and source registry integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-51-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in competitor, offering, and source registry. | merge |
| OBS-P5-51-001 | observability | Emit required events, metrics, traces, and correlation identifiers for competitor, offering, and source registry. | merge |
| E2E-P5-51-001 | end_to_end | Complete the founder-visible workflow for competitor, offering, and source registry with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.2
phase: 5
title: "Retrieval, hashing, and snapshots"
status: drafted
dependencies: ["WP5.1"]
primary_team: market_intelligence
risk: medium
---

# WP5.2 - Retrieval, hashing, and snapshots

## Objective

Implement retrieval, hashing, and snapshots as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.1

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for retrieval, hashing, and snapshots
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-2-REQ-001:** The system shall implement retrieval, hashing, and snapshots using existing repository conventions and shared FOS contracts.
- **5-2-REQ-002:** The implementation shall expose versioned, validated interfaces for retrieval, hashing, and snapshots and preserve backward compatibility or provide an explicit migration.
- **5-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to retrieval, hashing, and snapshots shall be enforced deterministically.
- **5-2-REQ-004:** All consequential operations in retrieval, hashing, and snapshots shall be auditable through correlation-aware events and immutable or versioned records.
- **5-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for retrieval, hashing, and snapshots.
- **5-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for retrieval, hashing, and snapshots.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-52-001 | unit | Validate core rules and schemas for retrieval, hashing, and snapshots. | pull_request |
| IT-P5-52-001 | integration | Verify retrieval, hashing, and snapshots integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-52-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in retrieval, hashing, and snapshots. | merge |
| OBS-P5-52-001 | observability | Emit required events, metrics, traces, and correlation identifiers for retrieval, hashing, and snapshots. | merge |
| E2E-P5-52-001 | end_to_end | Complete the founder-visible workflow for retrieval, hashing, and snapshots with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.3
phase: 5
title: "Observation extraction and verification"
status: drafted
dependencies: ["WP5.2"]
primary_team: market_intelligence
risk: medium
---

# WP5.3 - Observation extraction and verification

## Objective

Implement observation extraction and verification as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.2

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for observation extraction and verification
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-3-REQ-001:** The system shall implement observation extraction and verification using existing repository conventions and shared FOS contracts.
- **5-3-REQ-002:** The implementation shall expose versioned, validated interfaces for observation extraction and verification and preserve backward compatibility or provide an explicit migration.
- **5-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to observation extraction and verification shall be enforced deterministically.
- **5-3-REQ-004:** All consequential operations in observation extraction and verification shall be auditable through correlation-aware events and immutable or versioned records.
- **5-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for observation extraction and verification.
- **5-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for observation extraction and verification.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-53-001 | unit | Validate core rules and schemas for observation extraction and verification. | pull_request |
| IT-P5-53-001 | integration | Verify observation extraction and verification integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-53-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in observation extraction and verification. | merge |
| OBS-P5-53-001 | observability | Emit required events, metrics, traces, and correlation identifiers for observation extraction and verification. | merge |
| E2E-P5-53-001 | end_to_end | Complete the founder-visible workflow for observation extraction and verification with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.4
phase: 5
title: "Material change detection"
status: drafted
dependencies: ["WP5.3"]
primary_team: market_intelligence
risk: medium
---

# WP5.4 - Material change detection

## Objective

Implement material change detection as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.3

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for material change detection
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-4-REQ-001:** The system shall implement material change detection using existing repository conventions and shared FOS contracts.
- **5-4-REQ-002:** The implementation shall expose versioned, validated interfaces for material change detection and preserve backward compatibility or provide an explicit migration.
- **5-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to material change detection shall be enforced deterministically.
- **5-4-REQ-004:** All consequential operations in material change detection shall be auditable through correlation-aware events and immutable or versioned records.
- **5-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for material change detection.
- **5-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for material change detection.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-54-001 | unit | Validate core rules and schemas for material change detection. | pull_request |
| IT-P5-54-001 | integration | Verify material change detection integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-54-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in material change detection. | merge |
| OBS-P5-54-001 | observability | Emit required events, metrics, traces, and correlation identifiers for material change detection. | merge |
| E2E-P5-54-001 | end_to_end | Complete the founder-visible workflow for material change detection with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.5
phase: 5
title: "Pricing and offer intelligence"
status: drafted
dependencies: ["WP5.3"]
primary_team: market_intelligence
risk: high
---

# WP5.5 - Pricing and offer intelligence

## Objective

Implement pricing and offer intelligence as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.3

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for pricing and offer intelligence
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-5-REQ-001:** The system shall implement pricing and offer intelligence using existing repository conventions and shared FOS contracts.
- **5-5-REQ-002:** The implementation shall expose versioned, validated interfaces for pricing and offer intelligence and preserve backward compatibility or provide an explicit migration.
- **5-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to pricing and offer intelligence shall be enforced deterministically.
- **5-5-REQ-004:** All consequential operations in pricing and offer intelligence shall be auditable through correlation-aware events and immutable or versioned records.
- **5-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for pricing and offer intelligence.
- **5-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for pricing and offer intelligence.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-55-001 | unit | Validate core rules and schemas for pricing and offer intelligence. | pull_request |
| IT-P5-55-001 | integration | Verify pricing and offer intelligence integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-55-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in pricing and offer intelligence. | merge |
| OBS-P5-55-001 | observability | Emit required events, metrics, traces, and correlation identifiers for pricing and offer intelligence. | merge |
| E2E-P5-55-001 | end_to_end | Complete the founder-visible workflow for pricing and offer intelligence with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.6
phase: 5
title: "Job-based comparison"
status: drafted
dependencies: ["WP5.3", "WP5.5"]
primary_team: market_intelligence
risk: medium
---

# WP5.6 - Job-based comparison

## Objective

Implement job-based comparison as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.3
- WP5.5

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for job-based comparison
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-6-REQ-001:** The system shall implement job-based comparison using existing repository conventions and shared FOS contracts.
- **5-6-REQ-002:** The implementation shall expose versioned, validated interfaces for job-based comparison and preserve backward compatibility or provide an explicit migration.
- **5-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to job-based comparison shall be enforced deterministically.
- **5-6-REQ-004:** All consequential operations in job-based comparison shall be auditable through correlation-aware events and immutable or versioned records.
- **5-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for job-based comparison.
- **5-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for job-based comparison.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-56-001 | unit | Validate core rules and schemas for job-based comparison. | pull_request |
| IT-P5-56-001 | integration | Verify job-based comparison integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-56-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in job-based comparison. | merge |
| OBS-P5-56-001 | observability | Emit required events, metrics, traces, and correlation identifiers for job-based comparison. | merge |
| E2E-P5-56-001 | end_to_end | Complete the founder-visible workflow for job-based comparison with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.7
phase: 5
title: "Strategic alerts and market briefs"
status: drafted
dependencies: ["WP5.4", "WP5.5", "WP5.6"]
primary_team: market_intelligence
risk: medium
---

# WP5.7 - Strategic alerts and market briefs

## Objective

Implement strategic alerts and market briefs as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.4
- WP5.5
- WP5.6

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for strategic alerts and market briefs
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-7-REQ-001:** The system shall implement strategic alerts and market briefs using existing repository conventions and shared FOS contracts.
- **5-7-REQ-002:** The implementation shall expose versioned, validated interfaces for strategic alerts and market briefs and preserve backward compatibility or provide an explicit migration.
- **5-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to strategic alerts and market briefs shall be enforced deterministically.
- **5-7-REQ-004:** All consequential operations in strategic alerts and market briefs shall be auditable through correlation-aware events and immutable or versioned records.
- **5-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for strategic alerts and market briefs.
- **5-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for strategic alerts and market briefs.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-57-001 | unit | Validate core rules and schemas for strategic alerts and market briefs. | pull_request |
| IT-P5-57-001 | integration | Verify strategic alerts and market briefs integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-57-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in strategic alerts and market briefs. | merge |
| OBS-P5-57-001 | observability | Emit required events, metrics, traces, and correlation identifiers for strategic alerts and market briefs. | merge |
| E2E-P5-57-001 | end_to_end | Complete the founder-visible workflow for strategic alerts and market briefs with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.8
phase: 5
title: "Notion intelligence workspace and decision commands"
status: drafted
dependencies: ["WP5.7"]
primary_team: market_intelligence
risk: high
---

# WP5.8 - Notion intelligence workspace and decision commands

## Objective

Implement notion intelligence workspace and decision commands as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.7

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for notion intelligence workspace and decision commands
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-8-REQ-001:** The system shall implement notion intelligence workspace and decision commands using existing repository conventions and shared FOS contracts.
- **5-8-REQ-002:** The implementation shall expose versioned, validated interfaces for notion intelligence workspace and decision commands and preserve backward compatibility or provide an explicit migration.
- **5-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to notion intelligence workspace and decision commands shall be enforced deterministically.
- **5-8-REQ-004:** All consequential operations in notion intelligence workspace and decision commands shall be auditable through correlation-aware events and immutable or versioned records.
- **5-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for notion intelligence workspace and decision commands.
- **5-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for notion intelligence workspace and decision commands.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-58-001 | unit | Validate core rules and schemas for notion intelligence workspace and decision commands. | pull_request |
| IT-P5-58-001 | integration | Verify notion intelligence workspace and decision commands integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-58-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in notion intelligence workspace and decision commands. | merge |
| OBS-P5-58-001 | observability | Emit required events, metrics, traces, and correlation identifiers for notion intelligence workspace and decision commands. | merge |
| E2E-P5-58-001 | end_to_end | Complete the founder-visible workflow for notion intelligence workspace and decision commands with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP5.9
phase: 5
title: "Evaluation, freshness, and noise tuning"
status: drafted
dependencies: ["WP5.2", "WP5.3", "WP5.4", "WP5.5", "WP5.6", "WP5.7", "WP5.8"]
primary_team: market_intelligence
risk: medium
---

# WP5.9 - Evaluation, freshness, and noise tuning

## Objective

Implement evaluation, freshness, and noise tuning as a bounded, testable vertical slice that conforms to the revised Phase 5 specification and shared FOS contracts.

## Business value

This packet advances **Phase 5: Competitive, Pricing, and Market Intelligence** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP5.2
- WP5.3
- WP5.4
- WP5.5
- WP5.6
- WP5.7
- WP5.8

## Required inputs

- Revised Phase 5 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for evaluation, freshness, and noise tuning
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **5-9-REQ-001:** The system shall implement evaluation, freshness, and noise tuning using existing repository conventions and shared FOS contracts.
- **5-9-REQ-002:** The implementation shall expose versioned, validated interfaces for evaluation, freshness, and noise tuning and preserve backward compatibility or provide an explicit migration.
- **5-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to evaluation, freshness, and noise tuning shall be enforced deterministically.
- **5-9-REQ-004:** All consequential operations in evaluation, freshness, and noise tuning shall be auditable through correlation-aware events and immutable or versioned records.
- **5-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for evaluation, freshness, and noise tuning.
- **5-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for evaluation, freshness, and noise tuning.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P5-59-001 | unit | Validate core rules and schemas for evaluation, freshness, and noise tuning. | pull_request |
| IT-P5-59-001 | integration | Verify evaluation, freshness, and noise tuning integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P5-59-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in evaluation, freshness, and noise tuning. | merge |
| OBS-P5-59-001 | observability | Emit required events, metrics, traces, and correlation identifiers for evaluation, freshness, and noise tuning. | merge |
| E2E-P5-59-001 | end_to_end | Complete the founder-visible workflow for evaluation, freshness, and noise tuning with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.0
phase: 6
title: "Cross-phase data quality and metric readiness audit"
status: drafted
dependencies: ["WP1.10", "WP2.10", "WP3.10", "WP4.10", "WP5.9"]
primary_team: founder_coordination
risk: medium
---

# WP6.0 - Cross-phase data quality and metric readiness audit

## Objective

Implement cross-phase data quality and metric readiness audit as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP1.10
- WP2.10
- WP3.10
- WP4.10
- WP5.9

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for cross-phase data quality and metric readiness audit
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-0-REQ-001:** The system shall implement cross-phase data quality and metric readiness audit using existing repository conventions and shared FOS contracts.
- **6-0-REQ-002:** The implementation shall expose versioned, validated interfaces for cross-phase data quality and metric readiness audit and preserve backward compatibility or provide an explicit migration.
- **6-0-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to cross-phase data quality and metric readiness audit shall be enforced deterministically.
- **6-0-REQ-004:** All consequential operations in cross-phase data quality and metric readiness audit shall be auditable through correlation-aware events and immutable or versioned records.
- **6-0-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for cross-phase data quality and metric readiness audit.
- **6-0-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for cross-phase data quality and metric readiness audit.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-60-001 | unit | Validate core rules and schemas for cross-phase data quality and metric readiness audit. | pull_request |
| IT-P6-60-001 | integration | Verify cross-phase data quality and metric readiness audit integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-60-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in cross-phase data quality and metric readiness audit. | merge |
| OBS-P6-60-001 | observability | Emit required events, metrics, traces, and correlation identifiers for cross-phase data quality and metric readiness audit. | merge |
| E2E-P6-60-001 | end_to_end | Complete the founder-visible workflow for cross-phase data quality and metric readiness audit with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.1
phase: 6
title: "Strategic priority registry"
status: drafted
dependencies: ["WP6.0"]
primary_team: founder_coordination
risk: medium
---

# WP6.1 - Strategic priority registry

## Objective

Implement strategic priority registry as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.0

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for strategic priority registry
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-1-REQ-001:** The system shall implement strategic priority registry using existing repository conventions and shared FOS contracts.
- **6-1-REQ-002:** The implementation shall expose versioned, validated interfaces for strategic priority registry and preserve backward compatibility or provide an explicit migration.
- **6-1-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to strategic priority registry shall be enforced deterministically.
- **6-1-REQ-004:** All consequential operations in strategic priority registry shall be auditable through correlation-aware events and immutable or versioned records.
- **6-1-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for strategic priority registry.
- **6-1-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for strategic priority registry.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-61-001 | unit | Validate core rules and schemas for strategic priority registry. | pull_request |
| IT-P6-61-001 | integration | Verify strategic priority registry integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-61-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in strategic priority registry. | merge |
| OBS-P6-61-001 | observability | Emit required events, metrics, traces, and correlation identifiers for strategic priority registry. | merge |
| E2E-P6-61-001 | end_to_end | Complete the founder-visible workflow for strategic priority registry with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.2
phase: 6
title: "Unified canonical decision queue"
status: drafted
dependencies: ["WP6.0", "WP6.1"]
primary_team: founder_coordination
risk: medium
---

# WP6.2 - Unified canonical decision queue

## Objective

Implement unified canonical decision queue as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.0
- WP6.1

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for unified canonical decision queue
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-2-REQ-001:** The system shall implement unified canonical decision queue using existing repository conventions and shared FOS contracts.
- **6-2-REQ-002:** The implementation shall expose versioned, validated interfaces for unified canonical decision queue and preserve backward compatibility or provide an explicit migration.
- **6-2-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to unified canonical decision queue shall be enforced deterministically.
- **6-2-REQ-004:** All consequential operations in unified canonical decision queue shall be auditable through correlation-aware events and immutable or versioned records.
- **6-2-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for unified canonical decision queue.
- **6-2-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for unified canonical decision queue.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-62-001 | unit | Validate core rules and schemas for unified canonical decision queue. | pull_request |
| IT-P6-62-001 | integration | Verify unified canonical decision queue integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-62-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in unified canonical decision queue. | merge |
| OBS-P6-62-001 | observability | Emit required events, metrics, traces, and correlation identifiers for unified canonical decision queue. | merge |
| E2E-P6-62-001 | end_to_end | Complete the founder-visible workflow for unified canonical decision queue with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.3
phase: 6
title: "Notion Founder Command Center"
status: drafted
dependencies: ["WP6.2"]
primary_team: founder_coordination
risk: high
---

# WP6.3 - Notion Founder Command Center

## Objective

Implement notion founder command center as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.2

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for notion founder command center
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-3-REQ-001:** The system shall implement notion founder command center using existing repository conventions and shared FOS contracts.
- **6-3-REQ-002:** The implementation shall expose versioned, validated interfaces for notion founder command center and preserve backward compatibility or provide an explicit migration.
- **6-3-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to notion founder command center shall be enforced deterministically.
- **6-3-REQ-004:** All consequential operations in notion founder command center shall be auditable through correlation-aware events and immutable or versioned records.
- **6-3-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for notion founder command center.
- **6-3-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for notion founder command center.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-63-001 | unit | Validate core rules and schemas for notion founder command center. | pull_request |
| IT-P6-63-001 | integration | Verify notion founder command center integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-63-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in notion founder command center. | merge |
| OBS-P6-63-001 | observability | Emit required events, metrics, traces, and correlation identifiers for notion founder command center. | merge |
| E2E-P6-63-001 | end_to_end | Complete the founder-visible workflow for notion founder command center with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.4
phase: 6
title: "Cross-domain conflict detection"
status: drafted
dependencies: ["WP6.2"]
primary_team: founder_coordination
risk: medium
---

# WP6.4 - Cross-domain conflict detection

## Objective

Implement cross-domain conflict detection as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.2

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for cross-domain conflict detection
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-4-REQ-001:** The system shall implement cross-domain conflict detection using existing repository conventions and shared FOS contracts.
- **6-4-REQ-002:** The implementation shall expose versioned, validated interfaces for cross-domain conflict detection and preserve backward compatibility or provide an explicit migration.
- **6-4-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to cross-domain conflict detection shall be enforced deterministically.
- **6-4-REQ-004:** All consequential operations in cross-domain conflict detection shall be auditable through correlation-aware events and immutable or versioned records.
- **6-4-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for cross-domain conflict detection.
- **6-4-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for cross-domain conflict detection.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-64-001 | unit | Validate core rules and schemas for cross-domain conflict detection. | pull_request |
| IT-P6-64-001 | integration | Verify cross-domain conflict detection integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-64-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in cross-domain conflict detection. | merge |
| OBS-P6-64-001 | observability | Emit required events, metrics, traces, and correlation identifiers for cross-domain conflict detection. | merge |
| E2E-P6-64-001 | end_to_end | Complete the founder-visible workflow for cross-domain conflict detection with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.5
phase: 6
title: "Daily founder brief"
status: drafted
dependencies: ["WP6.2", "WP6.4"]
primary_team: founder_coordination
risk: medium
---

# WP6.5 - Daily founder brief

## Objective

Implement daily founder brief as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.2
- WP6.4

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for daily founder brief
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-5-REQ-001:** The system shall implement daily founder brief using existing repository conventions and shared FOS contracts.
- **6-5-REQ-002:** The implementation shall expose versioned, validated interfaces for daily founder brief and preserve backward compatibility or provide an explicit migration.
- **6-5-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to daily founder brief shall be enforced deterministically.
- **6-5-REQ-004:** All consequential operations in daily founder brief shall be auditable through correlation-aware events and immutable or versioned records.
- **6-5-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for daily founder brief.
- **6-5-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for daily founder brief.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-65-001 | unit | Validate core rules and schemas for daily founder brief. | pull_request |
| IT-P6-65-001 | integration | Verify daily founder brief integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-65-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in daily founder brief. | merge |
| OBS-P6-65-001 | observability | Emit required events, metrics, traces, and correlation identifiers for daily founder brief. | merge |
| E2E-P6-65-001 | end_to_end | Complete the founder-visible workflow for daily founder brief with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.6
phase: 6
title: "Weekly and monthly operating reviews"
status: drafted
dependencies: ["WP6.5"]
primary_team: founder_coordination
risk: medium
---

# WP6.6 - Weekly and monthly operating reviews

## Objective

Implement weekly and monthly operating reviews as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.5

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for weekly and monthly operating reviews
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-6-REQ-001:** The system shall implement weekly and monthly operating reviews using existing repository conventions and shared FOS contracts.
- **6-6-REQ-002:** The implementation shall expose versioned, validated interfaces for weekly and monthly operating reviews and preserve backward compatibility or provide an explicit migration.
- **6-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to weekly and monthly operating reviews shall be enforced deterministically.
- **6-6-REQ-004:** All consequential operations in weekly and monthly operating reviews shall be auditable through correlation-aware events and immutable or versioned records.
- **6-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for weekly and monthly operating reviews.
- **6-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for weekly and monthly operating reviews.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-66-001 | unit | Validate core rules and schemas for weekly and monthly operating reviews. | pull_request |
| IT-P6-66-001 | integration | Verify weekly and monthly operating reviews integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-66-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in weekly and monthly operating reviews. | merge |
| OBS-P6-66-001 | observability | Emit required events, metrics, traces, and correlation identifiers for weekly and monthly operating reviews. | merge |
| E2E-P6-66-001 | end_to_end | Complete the founder-visible workflow for weekly and monthly operating reviews with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.7
phase: 6
title: "Full specification compiler and critic"
status: drafted
dependencies: ["WP3.3", "WP6.1"]
primary_team: founder_coordination
risk: medium
---

# WP6.7 - Full specification compiler and critic

## Objective

Implement full specification compiler and critic as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP3.3
- WP6.1

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for full specification compiler and critic
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-7-REQ-001:** The system shall implement full specification compiler and critic using existing repository conventions and shared FOS contracts.
- **6-7-REQ-002:** The implementation shall expose versioned, validated interfaces for full specification compiler and critic and preserve backward compatibility or provide an explicit migration.
- **6-7-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to full specification compiler and critic shall be enforced deterministically.
- **6-7-REQ-004:** All consequential operations in full specification compiler and critic shall be auditable through correlation-aware events and immutable or versioned records.
- **6-7-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for full specification compiler and critic.
- **6-7-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for full specification compiler and critic.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-67-001 | unit | Validate core rules and schemas for full specification compiler and critic. | pull_request |
| IT-P6-67-001 | integration | Verify full specification compiler and critic integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-67-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in full specification compiler and critic. | merge |
| OBS-P6-67-001 | observability | Emit required events, metrics, traces, and correlation identifiers for full specification compiler and critic. | merge |
| E2E-P6-67-001 | end_to_end | Complete the founder-visible workflow for full specification compiler and critic with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.8
phase: 6
title: "Automation opportunity detection"
status: drafted
dependencies: ["WP6.6"]
primary_team: founder_coordination
risk: medium
---

# WP6.8 - Automation opportunity detection

## Objective

Implement automation opportunity detection as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.6

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for automation opportunity detection
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-8-REQ-001:** The system shall implement automation opportunity detection using existing repository conventions and shared FOS contracts.
- **6-8-REQ-002:** The implementation shall expose versioned, validated interfaces for automation opportunity detection and preserve backward compatibility or provide an explicit migration.
- **6-8-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to automation opportunity detection shall be enforced deterministically.
- **6-8-REQ-004:** All consequential operations in automation opportunity detection shall be auditable through correlation-aware events and immutable or versioned records.
- **6-8-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for automation opportunity detection.
- **6-8-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for automation opportunity detection.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-68-001 | unit | Validate core rules and schemas for automation opportunity detection. | pull_request |
| IT-P6-68-001 | integration | Verify automation opportunity detection integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-68-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in automation opportunity detection. | merge |
| OBS-P6-68-001 | observability | Emit required events, metrics, traces, and correlation identifiers for automation opportunity detection. | merge |
| E2E-P6-68-001 | end_to_end | Complete the founder-visible workflow for automation opportunity detection with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.9
phase: 6
title: "Autonomy governance and rollback"
status: drafted
dependencies: ["WP6.8"]
primary_team: founder_coordination
risk: critical
---

# WP6.9 - Autonomy governance and rollback

## Objective

Implement autonomy governance and rollback as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.8

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for autonomy governance and rollback
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-9-REQ-001:** The system shall implement autonomy governance and rollback using existing repository conventions and shared FOS contracts.
- **6-9-REQ-002:** The implementation shall expose versioned, validated interfaces for autonomy governance and rollback and preserve backward compatibility or provide an explicit migration.
- **6-9-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to autonomy governance and rollback shall be enforced deterministically.
- **6-9-REQ-004:** All consequential operations in autonomy governance and rollback shall be auditable through correlation-aware events and immutable or versioned records.
- **6-9-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for autonomy governance and rollback.
- **6-9-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for autonomy governance and rollback.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-69-001 | unit | Validate core rules and schemas for autonomy governance and rollback. | pull_request |
| IT-P6-69-001 | integration | Verify autonomy governance and rollback integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-69-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in autonomy governance and rollback. | merge |
| OBS-P6-69-001 | observability | Emit required events, metrics, traces, and correlation identifiers for autonomy governance and rollback. | merge |
| E2E-P6-69-001 | end_to_end | Complete the founder-visible workflow for autonomy governance and rollback with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.


---

---
work_package: WP6.10
phase: 6
title: "Evaluation, tuning, and native-UI decision gate"
status: drafted
dependencies: ["WP6.3", "WP6.4", "WP6.5", "WP6.6", "WP6.7", "WP6.8", "WP6.9"]
primary_team: founder_coordination
risk: medium
---

# WP6.10 - Evaluation, tuning, and native-UI decision gate

## Objective

Implement evaluation, tuning, and native-ui decision gate as a bounded, testable vertical slice that conforms to the revised Phase 6 specification and shared FOS contracts.

## Business value

This packet advances **Phase 6: Founder Chief of Staff, Command Center, and Automation Governance** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP6.3
- WP6.4
- WP6.5
- WP6.6
- WP6.7
- WP6.8
- WP6.9

## Required inputs

- Revised Phase 6 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for evaluation, tuning, and native-ui decision gate
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **6-10-REQ-001:** The system shall implement evaluation, tuning, and native-ui decision gate using existing repository conventions and shared FOS contracts.
- **6-10-REQ-002:** The implementation shall expose versioned, validated interfaces for evaluation, tuning, and native-ui decision gate and preserve backward compatibility or provide an explicit migration.
- **6-10-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to evaluation, tuning, and native-ui decision gate shall be enforced deterministically.
- **6-10-REQ-004:** All consequential operations in evaluation, tuning, and native-ui decision gate shall be auditable through correlation-aware events and immutable or versioned records.
- **6-10-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for evaluation, tuning, and native-ui decision gate.
- **6-10-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for evaluation, tuning, and native-ui decision gate.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P6-610-001 | unit | Validate core rules and schemas for evaluation, tuning, and native-ui decision gate. | pull_request |
| IT-P6-610-001 | integration | Verify evaluation, tuning, and native-ui decision gate integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P6-610-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in evaluation, tuning, and native-ui decision gate. | merge |
| OBS-P6-610-001 | observability | Emit required events, metrics, traces, and correlation identifiers for evaluation, tuning, and native-ui decision gate. | merge |
| E2E-P6-610-001 | end_to_end | Complete the founder-visible workflow for evaluation, tuning, and native-ui decision gate with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.
