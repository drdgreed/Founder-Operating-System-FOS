---
work_package: WP4.6
phase: 4
title: "Multi-channel repurposing"
status: drafted
dependencies: ["WP4.3", "WP4.4", "WP4.5"]
primary_team: communications
risk: medium
---

# WP4.6 - Multi-channel repurposing

## Objective

Implement multi-channel repurposing as a bounded, testable vertical slice that conforms to the revised Phase 4 specification and shared FOS contracts.

## Business value

This packet advances **Phase 4: Scaled Marketing and Communications Operations** while preserving founder control, canonical data ownership, evidence provenance, and safe parallel development.

## Dependencies

- WP4.3
- WP4.4
- WP4.5

## Required inputs

- Revised Phase 4 source specification
- Repository architecture map and file-ownership overlay
- Frozen shared contracts under `contracts/`
- Relevant fixture IDs from `fixtures/`
- Feature-flag and environment conventions
- Accepted upstream work-package evidence

## Deliverables

- Production implementation for multi-channel repurposing
- Additive or explicitly migrated schemas where required
- Typed interfaces and validation
- Events, metrics, logs, and traces
- Feature flags with safe defaults
- Automated tests named below
- Updated requirement-to-test traceability
- Deployment and rollback notes
- Completion report and independent-review evidence

## Interfaces

### Consumes

- Canonical workspace, identity, artifact, approval, event, evidence, consent, claims, and agent-runtime contracts as applicable
- Accepted upstream events and APIs

### Produces

- Versioned phase-owned APIs, events, records, artifacts, commands, or projections required by this work package
- No incompatible shared-contract change without an approved contract-change proposal

## Allowed changes

The repository overlay must assign explicit file globs. By default, the agent may change only phase-owned modules, tests, migrations, fixtures, documentation, and generated clients directly necessary for this packet.

## Prohibited changes

- Authentication, tenancy, or workspace semantics
- Shared event envelope or canonical primitive meaning
- Approval, consent, claims, release, pricing, or external-action gates
- New ORM, queue, model gateway, or integration framework
- Unrelated phase modules
- Autonomous publishing, sending, deployment, purchasing, or pricing

## Functional requirements

- **4-6-REQ-001:** The system shall implement multi-channel repurposing using existing repository conventions and shared FOS contracts.
- **4-6-REQ-002:** The implementation shall expose versioned, validated interfaces for multi-channel repurposing and preserve backward compatibility or provide an explicit migration.
- **4-6-REQ-003:** Authorization, workspace isolation, consent, claims, approval, and autonomy policies applicable to multi-channel repurposing shall be enforced deterministically.
- **4-6-REQ-004:** All consequential operations in multi-channel repurposing shall be auditable through correlation-aware events and immutable or versioned records.
- **4-6-REQ-005:** The implementation shall include automated unit, integration, negative, observability, and end-to-end verification for multi-channel repurposing.
- **4-6-REQ-006:** The implementation shall support feature-flagged activation, safe retry, idempotency, and rollback or compensating action for multi-channel repurposing.

## Security and governance

- Enforce least privilege and workspace isolation server-side.
- Treat user, Notion, file, model, tool, and web content as untrusted data.
- Preserve observed, inferred, user-confirmed, and founder-approved distinctions.
- Require founder approval for consequential actions.
- Avoid raw sensitive data in logs and projections.

## Required verification

| Test ID | Type | Description | Gate |
|---|---|---|---|
| UT-P4-46-001 | unit | Validate core rules and schemas for multi-channel repurposing. | pull_request |
| IT-P4-46-001 | integration | Verify multi-channel repurposing integrates with canonical services, events, authorization, and audit. | pull_request |
| NEG-P4-46-001 | negative_security | Reject unauthorized, stale, malformed, duplicate, or policy-violating operations in multi-channel repurposing. | merge |
| OBS-P4-46-001 | observability | Emit required events, metrics, traces, and correlation identifiers for multi-channel repurposing. | merge |
| E2E-P4-46-001 | end_to_end | Complete the founder-visible workflow for multi-channel repurposing with rollback or safe failure. | release |

## Observability

Record correlation ID, workspace ID, work-package or agent version, latency, outcome, retry count, cost where applicable, and typed failure classification. Required events must be asserted in integration tests.

## Rollout

1. Apply additive migrations or compatibility adapters.
2. Enable in test environment.
3. Run packet, shared-contract, security, and affected E2E suites.
4. Activate in shadow or founder-only mode.
5. Compare outputs and metrics to the prior path.
6. Promote only after phase gate approval.

## Definition of done

- All deliverables are present.
- Required tests pass.
- No unresolved critical security, privacy, consent, claims, or isolation issue exists.
- Feature flags default safely.
- Rollback or compensating action is tested.
- Traceability and documentation are updated.
- Independent reviewer approves the packet.

## Completion evidence

- Commit or pull-request reference
- Diff summary and file list
- Migration output
- Test commands and results
- Telemetry sample
- Feature-flag state
- Rollback command or procedure
- Known limitations
- Reviewer decision

## Escalation conditions

Stop and escalate if implementation requires a shared-contract change, destructive migration, new external dependency, reduced policy enforcement, cross-packet file modification, or founder decision about strategy, pricing, public claims, deployment, or autonomy.
