# Merge Conflict Policy

- Shared schema, event, authorization, consent, claim, artifact, approval, and workspace-adapter conflicts require the contract owner.
- Generated files are regenerated from the accepted source, not manually merged.
- Migration-number conflicts are resolved by creating a new ordered migration.
- Prompt conflicts require evaluation comparison, not line-level compromise.
- Notion mapping conflicts preserve canonical ownership and least privilege.
- No conflict resolution may weaken a deterministic gate.
