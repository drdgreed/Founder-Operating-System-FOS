# Orchestrator Runbook

1. Validate the pack.
2. Complete repository assessment and freeze contracts.
3. Update packet overlays with file globs and commands.
4. Select the next dependency-ready packet.
5. Assign implementation and review agents.
6. Create isolated branch or worktree and locks.
7. Monitor heartbeat, scope, tests, and contract-change requests.
8. Require self-check evidence.
9. Route to independent review.
10. Integrate through merge queue and shared suites.
11. Update traceability and packet status.
12. Activate only through phase gates and feature flags.

## Escalate to founder when

- Strategy, pricing, product promise, or public positioning changes
- A critical security or privacy risk is accepted rather than removed
- A release gate override is proposed
- A new external service creates cost or lock-in
- A user-facing outcome claim lacks adequate evidence
- An autonomy increase moves an agent toward consequential execution
