# Pack Tools

`validate_pack.py` validates work-package IDs, dependencies, packet sections, test references, fixture references, and JSON contracts. Run it before distribution and in CI.

`generate_work_orders.py` can create an orchestrator queue from the registry after the repository overlay supplies actual file paths and commands.
