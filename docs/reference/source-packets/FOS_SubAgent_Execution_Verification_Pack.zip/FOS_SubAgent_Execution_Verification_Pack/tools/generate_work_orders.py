#!/usr/bin/env python3
from pathlib import Path
import csv, json
root=Path(__file__).resolve().parents[1]
with (root/'matrices/work_package_registry.csv').open() as f:
    rows=list(csv.DictReader(f))
ready=[r for r in rows if not r['dependencies']]
print(json.dumps({"initial_ready_work_packages":[r['work_package'] for r in ready]},indent=2))
