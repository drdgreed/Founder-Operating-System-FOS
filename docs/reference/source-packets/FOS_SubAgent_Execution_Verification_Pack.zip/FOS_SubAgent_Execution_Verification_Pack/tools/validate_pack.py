#!/usr/bin/env python3
from pathlib import Path
import csv, json, sys, re
ROOT=Path(__file__).resolve().parents[1]
errors=[]

def csv_rows(name):
    with (ROOT/name).open(encoding='utf-8') as f: return list(csv.DictReader(f))

wps=csv_rows('matrices/work_package_registry.csv')
wp_ids=[r['work_package'] for r in wps]
if len(wp_ids)!=len(set(wp_ids)): errors.append('Duplicate work-package IDs')
for r in wps:
    if not (ROOT/r['packet_path']).exists(): errors.append(f"Missing packet {r['packet_path']}")
    for d in filter(None,r['dependencies'].split(';')):
        if d not in wp_ids: errors.append(f"Unknown dependency {d} for {r['work_package']}")

tests=csv_rows('matrices/test_registry.csv')
test_ids=[r['test_id'] for r in tests]
if len(test_ids)!=len(set(test_ids)): errors.append('Duplicate test IDs')
fixture_ids={json.loads(p.read_text())['fixture_id'] for p in (ROOT/'fixtures').rglob('*.json')}
for r in tests:
    for f in filter(None,r['fixture_ids'].split(';')):
        if f not in fixture_ids: errors.append(f"Unknown fixture {f} in {r['test_id']}")

reqs=csv_rows('matrices/requirement_to_test_matrix.csv')
for r in reqs:
    for t in filter(None,r['test_ids'].split(';')):
        if t not in test_ids: errors.append(f"Unknown test {t} for {r['requirement_id']}")

required_sections=['## Objective','## Dependencies','## Deliverables','## Functional requirements','## Required verification','## Definition of done','## Completion evidence','## Escalation conditions']
for p in (ROOT/'execution-packets').rglob('*.md'):
    txt=p.read_text()
    for s in required_sections:
        if s not in txt: errors.append(f'{p.relative_to(ROOT)} missing {s}')

for p in (ROOT/'contracts').glob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'Invalid JSON {p.name}: {e}')

if errors:
    print('PACK VALIDATION FAILED')
    for e in errors: print('-',e)
    sys.exit(1)
print(f'PACK VALIDATION PASSED: {len(wp_ids)} work packages, {len(reqs)} requirements, {len(test_ids)} tests, {len(fixture_ids)} fixtures')
